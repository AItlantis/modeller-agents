# 04 — Build Architecture v3

## 1. Objectives and principles

The architecture must keep four concerns distinct:

1. **Product authority:** Testudo owns project context, identities, permissions, responsibilities, conversations, tasks, findings and publications.
2. **Orchestration authority:** `modeller-agents` owns mission state, role dispatch, gates, receipts, checkpoints and provider control.
3. **Domain execution authority:** Aimsun and other backends own the operations and native outputs they perform.
4. **Knowledge authority:** `modelling-knowledge` owns accepted knowledge; memory may retrieve or propose but not promote.

Core principles are one visible agent, one executable runtime, explicit context, least privilege, typed boundaries, independent review, disk-first recovery, product/analytics data separation and evidence-linked publication.

## 2. System context

```mermaid
flowchart TB
    U[Transport Modeller / Project Manager / Client] --> WEB[Testudo Web App]
    WEB --> BFF[Testudo API / BFF]
    BFF --> PG[(PostgreSQL\nUsers Projects Permissions Tasks Conversations Findings Publications)]
    BFF --> OG[Orchestration Gateway]
    OG --> MA[modeller-agents Runtime]
    MA --> LED[Mission Ledger & Checkpoints\nContent-addressed files / object storage]
    MA --> PROV[Agent & Backend Providers]
    PROV --> AIM[Aimsun / Modelling Backends]
    PROV --> GIS[GeoLibre / GIS / Rendering]
    PROV --> DOC[Document Services]
    PROV --> EXT[External Agent Providers]
    AIM --> DDB[(DuckDB / Parquet\nSimulation datasets)]
    GIS --> DDB
    MA --> MEM[modeller-memory]
    MA --> KNOW[modelling-knowledge]
    MA --> EV[Typed Product Events]
    EV --> BFF
    BFF --> WEB
```

## 3. Target repository structure

```text
modeller-agents/
├── contracts/
│   ├── orchestration/          # mission, dispatch, gate, checkpoint, decision
│   ├── testudo/                # context, task, approval, evidence, finding, UI action
│   ├── datasets/               # DuckDB dataset manifests and result references
│   └── generated/              # JSON Schema and host projections
├── src/modeller/
│   ├── engine/                 # deterministic mission state
│   ├── ledger/                 # events, artifacts, checkpoints, invalidation
│   ├── roles/                  # decider, manager, recon, worker, reviewer policies
│   ├── providers/              # native, external, backend, manual adapters
│   ├── gates/                  # consent, result, review and transition gates
│   ├── subsystems/             # approved reusable features behind project interfaces
│   │   ├── code_graph/
│   │   ├── reflection/
│   │   ├── loop_control/
│   │   └── reuse_policy/
│   ├── integrations/
│   │   ├── testudo/
│   │   ├── postgres/
│   │   ├── duckdb/
│   │   ├── memory/
│   │   └── knowledge/
│   └── diagnostics/
├── generated/dmw-plugin/       # compatibility projection, never state authority
├── profiles/
├── catalogs/
├── tests/
└── docs/
```

Testudo remains a separate product repository. The integration may be deployed in-process for local development or as a service, but the contract boundary is identical.

## 4. Product and runtime domain model

| Object | Authority | Meaning |
|---|---|---|
| `Project` | Testudo/PostgreSQL | Persistent study and authorization boundary |
| `ActiveContextEnvelope` | Testudo | Authorized snapshot of user, project, model, version, period, scenario, selected SimulationRun, view and selection |
| `Conversation` | Testudo/PostgreSQL | Private Project × User visible-agent thread |
| `WorkflowDefinition` | Testudo + modeller-agents contract | Business goal and controlled execution pattern |
| `Mission` | modeller-agents | One orchestration instance created to satisfy an objective |
| `Task` | Testudo/PostgreSQL | User-visible persistent unit representing mission/backend progress |
| `SimulationRun` | Testudo domain/backend | Identifiable simulation execution of a scenario |
| `DispatchAttempt` | modeller-agents | One Worker/Reviewer/provider invocation |
| `ResultSet` | Backend/DuckDB | Dataset produced by a SimulationRun or analytical task |
| `EvidenceArtifact` | modeller-agents/object store | Immutable logs, receipts, reports, screenshots, diffs and checkpoints |
| `FindingCandidate` | Testudo | AI or human-proposed interpretation linked to evidence |
| `ReviewedFinding` | Testudo | Finding with technical review status |
| `PublicationVersion` | Testudo | Frozen/versioned content with approver and complete provenance |

The term `run` SHALL NOT be used alone in cross-system contracts.

## 5. One visible agent, internal role graph

```mermaid
flowchart LR
    CHAT[Testudo Visible Agent] --> IG[Interaction Gateway]
    IG --> DEC[Decider Policy]
    DEC --> MGR[Manager]
    MGR --> REC[Recon]
    MGR --> WRK[Workers]
    MGR --> REV[Independent Reviewer]
    REC --> MGR
    WRK --> GATE[Gate Engine]
    REV --> GATE
    GATE --> IG
    IG --> CHAT
```

- The visible agent owns conversational continuity and presentation.
- The Decider converts the request and project context into objective, options and exact decisions.
- The Manager creates and surgically revises the mission plan.
- Recon supplies evidence only.
- Workers execute bounded tasks.
- Reviewer independently verifies assertions.
- Only the orchestration engine changes mission state.
- Internal role/provider names appear only in diagnostics for authorized technical users.

## 6. Active context contract

`ActiveContextEnvelope` includes:

```text
schema_version
context_id and digest
user_id, organization_id, project_id
project_responsibilities[]
permission_snapshot_digest
model_id, model_version_id
period_id, scenario_id
simulation_run_id? and active_run_status
view_id?, selection[], filters?
conversation_id
requested_action
data_classification and external-transmission policy
issued_at, expires_at
```

Material actions fail closed when the context is missing, stale, incompatible or unauthorized. A mission stores the digest, not an implicit copy silently refreshed during execution. Context changes create a new envelope and may invalidate plan review or approval.

## 7. Interaction and API boundary

| Operation | Purpose |
|---|---|
| `prepare_interaction(context, message)` | Classify intent, explain context and prepare a workflow |
| `create_mission(context_digest, workflow, objective)` | Create mission and linked Testudo task |
| `request_approval(mission_id, action)` | Produce exact project-responsibility decision request |
| `execute_mission(mission_id, approval_receipt)` | Start provider/backend work |
| `stream_task_events(task_id)` | Update status, progress, warnings, partial results and interventions |
| `cancel_or_retry(task_id, scope)` | Apply supported recovery policy |
| `register_result(task_id, result_manifest)` | Register DuckDB/artifact references and quality state |
| `propose_finding(evidence_refs)` | Create a governed finding candidate |
| `prepare_publication(finding_ids, views)` | Create a versioned draft for Project Manager approval |

The API must be idempotent by request ID and correlation ID.

## 8. Runtime domain objects

The approved v1 objects remain: `MissionManifest`, `ContextReceipt`, `DecisionRequest`, `DecisionReceipt`, `DispatchRequest`, `RoleReceipt`, `GateReceipt`, `VerificationClaim`, `CheckpointReceipt`, `BackendSmokeReceipt` and `ImprovementEvent`.

v2 adds:

| Object | Purpose |
|---|---|
| `TestudoTaskBinding` | Links project/task/mission/workflow/correlation IDs |
| `ProductEvent` | Versioned projection of runtime state into Testudo |
| `ResultDatasetManifest` | DuckDB/Parquet location, schema, quality, run and lineage |
| `FindingHandoff` | Evidence and interpretation payload submitted to Testudo review |
| `UiActionRequest/Receipt` | Visible, authorized, reversible map/chart/table action |
| `PublicationHandoff` | Frozen context and source references for publication drafting |

## 9. Mission state and product task state

The mission state machine remains authoritative for orchestration. Testudo task state is a projection:

| Mission state | Testudo task state |
|---|---|
| Draft / ReconReady / Planned | Preparing |
| Reviewed, awaiting decision | Approval required |
| Authorized / Executing | Running |
| Integrating | Processing results |
| Partial evidence available | Partial result |
| Verified / Accepted | Completed |
| Blocked | Intervention required |
| Failed | Failed |
| Cancelled | Cancelled |
| Resuming after checkpoint | Recovering |

Projection is monotonic per event sequence and idempotent. A product task SHALL NOT infer completion from provider messages.

## 10. Provider interface and subsystem integration

```python
class Provider(Protocol):
    def capabilities(self) -> ProviderCapabilities: ...
    def dispatch(self, request: DispatchRequest) -> DispatchHandle: ...
    def poll(self, handle: DispatchHandle) -> ProviderStatus: ...
    def cancel(self, handle: DispatchHandle, reason: str) -> CancelReceipt: ...
    def collect(self, handle: DispatchHandle) -> RoleReceipt: ...
```

Approved third-party-inspired functionality is implemented under `subsystems/`, behind project-owned protocols. Every subsystem requires:

- exact source/version and attribution record;
- security and license verification;
- no authority to mutate mission state;
- no direct Testudo database access except through an integration adapter;
- contract and regression tests;
- disable/replace capability.

## 11. Evidence, ledger and recovery

Mission events are append-only JSONL or content-addressed records. Artifacts are immutable by digest. Before every external dispatch and material transition the runtime persists:

- mission state;
- context and policy digests;
- decision receipts;
- dispatch requests;
- artifact dependency graph;
- targeted recovery checks.

Resume performs schema, hash, path, scope and targeted-test verification. PostgreSQL stores product references and task/audit projections, not the only copy of recovery evidence.

## 12. Persistence architecture

### PostgreSQL — product system of record

Stores:

- organizations, users, roles and project responsibilities;
- projects, model/version/scenario/SimulationRun metadata;
- task and mission bindings;
- conversations and visibility;
- findings, reviews, publications and approvals;
- result and artifact catalog references;
- notification state;
- audit projections and, in future, append-only product events.

### DuckDB — simulation analytical store

Stores or queries:

- network sections/nodes and derived geometry tables;
- interval and aggregate simulation outputs;
- observed/reference datasets used for comparison;
- trajectories and time-series where appropriate;
- KPI, validation and comparison tables;
- analytical snapshots, with Parquet as an optional exchange/storage format.

DuckDB does not authorize users or own product workflow state. Dataset manifests carry project, model, scenario, SimulationRun, schema, source, quality and checksum.

### File/object storage — immutable evidence

Stores:

- mission checkpoints and receipts;
- logs and command outputs;
- screenshots and report assets;
- generated publications and exports;
- large binary artifacts and Parquet files;
- DMW compatibility projections.

## 13. Event architecture

v1 uses two coordinated event classes:

1. **Mission events:** local, append-only, content-addressed, optimized for deterministic recovery.
2. **Product events:** typed, idempotent events sent to Testudo for task state, audit, findings and notifications.

Future work may persist product events as a PostgreSQL event store. The runtime contract therefore uses an `EventPublisher` interface and stable event IDs from the start.

Core product events include:

```text
context_validated
mission_created
plan_prepared
approval_requested
approval_recorded
task_started
task_progressed
partial_result_registered
intervention_required
task_recovering
result_registered
finding_proposed
technical_review_recorded
publication_ready
publication_approved
mission_closed
```

## 14. Approval and responsibility policy

| Action | Required human authority | Machine preconditions |
|---|---|---|
| Use client-owned model/data beyond existing scope | Data/Model Owner or project Decider | Context, purpose, assets and transmission policy |
| Launch simulation | Run Owner / Transport Modeller | Configuration, resource, cost, plan and context digests |
| Accept technical finding | Technical Reviewer / Transport Modeller | Evidence lineage, validation, uncertainty and Reviewer receipt |
| Publish client content | Publication Approver / Project Manager | Reviewed finding, frozen context, recipients and version |
| Change permissions | Administrator/project authority | Server-side authorization and audit |
| External data transmission | Authorized user plus policy-defined consent | Destination, fields, classification, redaction and purpose |

No internal agent may fabricate or substitute these receipts.

## 15. Security boundaries

- Testudo authenticates users and resolves project permissions.
- The Orchestration Gateway receives a short-lived signed capability envelope.
- Providers receive only task-specific tools, paths, data references and network scopes.
- Raw PostgreSQL credentials are never sent to agents.
- DuckDB access uses scoped dataset references or service operations.
- External provider payloads pass classification and consent checks.
- Conversations are private per Project × User unless explicitly published.
- Sensitive action logs retain actor, context, request, result and correlation ID.

## 16. Memory and knowledge

Memory and knowledge remain separate adapters:

```text
Conversation / mission evidence
  → memory candidate and retrieval
  → project companion memory
  → optional knowledge-candidate handoff
  → human governance
  → accepted modelling knowledge
```

Testudo may display a project finding before it becomes cross-project accepted knowledge. Publication, project finding and knowledge promotion are separate states and reviews.

## 17. Deployment topology

Recommended topology:

- Testudo web frontend and API/BFF.
- PostgreSQL shared product database.
- Orchestration Gateway as a Testudo backend module.
- `modeller-agents` worker service/process with project-owned API.
- Backend adapters deployed near Aimsun or other licensed tools.
- DuckDB datasets on controlled local/shared storage or object storage.
- Event and artifact correlation across all services.

Local development may run Gateway and runtime in one process. Production should preserve process isolation and cancellation/restart boundaries.

## 18. Architecture decisions

| ID | Decision | Ruling | Status |
|---|---|---|---|
| ADR-001–ADR-012 | v1 runtime, governance, evidence, provider, consent and recovery decisions | Retained unchanged from audit v1 | Accepted |
| ADR-013 | Testudo product boundary | Testudo SHALL own the user experience and product domain; `modeller-agents` SHALL be embedded as an orchestration subsystem. | Accepted |
| ADR-014 | Visible-agent model | Testudo SHALL expose one contextual agent. DMW roles SHALL remain internal, independently governed subsystems. | Accepted |
| ADR-015 | Active context authority | Every material mission and approval SHALL bind to a versioned Testudo `ActiveContextEnvelope` digest. | Accepted |
| ADR-016 | Persistence ownership | PostgreSQL SHALL own product authority; DuckDB SHALL own simulation analytics; immutable artifacts SHALL use file/object storage. | Accepted |
| ADR-017 | Identity vocabulary | `Mission`, `Task`, `SimulationRun`, `DispatchAttempt` and `ResultSet` SHALL be distinct objects and identifiers. | Accepted |
| ADR-018 | Event bridge | Mission recovery events SHALL remain locally authoritative in v1 and SHALL publish typed product events through an interface compatible with a future PostgreSQL event store. | Accepted |
| ADR-019 | Approved subsystem integration | Approved external features MAY be integrated within `modeller-agents/subsystems` behind stable protocols, attribution, tests and kill switches. | Accepted |
| ADR-020 | Human responsibility mapping | Run, finding, publication, asset-use and permission approvals SHALL require the corresponding Testudo project responsibility. | Accepted |
| ADR-021 | Product completion boundary | Technical mission acceptance SHALL NOT equal finding acceptance or publication approval. | Accepted |
| ADR-022 | Deployment seam | Testudo and `modeller-agents` MAY run together locally but SHALL communicate through versioned contracts suitable for process separation. | Accepted |

## 19. Rejected alternatives

| Alternative | Reason |
|---|---|
| Expose Decider, Manager and Workers as separate Testudo chats | Violates one-agent product model and fragments context. |
| Put full simulation datasets in PostgreSQL | Mixes transactional authority with high-volume analytics and weakens portability. |
| Put user/project authority in DuckDB | Inadequate for shared transactional permissions and product state. |
| Replace checkpoint files immediately with a database event store | Removes a proven failure-recovery mechanism before the product event platform exists. |
| Treat a successful mission as an approved publication | Collapses technical evidence, human review and client authority. |
| Let providers query product databases directly | Bypasses least privilege and context controls. |

## 20. Component traceability

The v2 Testudo components map to REC-013–REC-020, ADR-013–ADR-022, PLAN-031–PLAN-045 and the v2 requirements appended to `06-build-specification.md`.

## 21. Pipeline control plane

`modeller-agents` SHALL own pipeline lifecycle policy, definition validation, dispatch, evidence, version registration, run preparation and result acceptance. It SHALL NOT own backend extraction or rendering code.

```mermaid
flowchart LR
 T[Testudo Gateway] --> PC[Pipeline Control Plane]
 PC --> REG[Pipeline Registry]
 PC --> P[PLAN]
 PC --> B[BUILD]
 PC --> O[OPERATE]
 B --> REPO[Pipeline Repository]
 O --> EX[Registered Entrypoint]
 EX --> SRC[Source Adapters]
 SRC --> CAN[DuckDB / Parquet]
 CAN --> ART[HTML / PNG / XLSX / Report / GeoLibre]
 ART --> CAT[Testudo Registry]
 PC --> LED[Mission Ledger]
```

### 21.1 Core objects

| Object | Purpose | Authority |
|---|---|---|
| `PipelineDefinition` | Identity, owner, stages, contracts, modes and outputs | Pipeline owner + registry |
| `PipelineCapabilityProfile` | Roles, tools, environments, write scopes and evidence | Runtime policy |
| `PipelinePlan` | Approved design and backlog | Manager + human approval |
| `PipelineImplementationBaseline` | Protected repository state | Orchestrator |
| `PipelineImplementationReceipt` | Changes, tests, residuals and rollback | Orchestrator after re-gate |
| `PipelineVersion` | Immutable executable reference | Pipeline owner/registry |
| `PipelineRunRequest` | Context, version, sources, stages, resources and outputs | Run Owner |
| `PipelineRunReceipt` | State, outputs, errors and evidence | Runtime |
| `CanonicalDatasetManifest` | DuckDB/Parquet schemas, sources, quality and queries | Dataset producer/reviewer |
| `ArtifactManifest` | Derived artifacts, digests, lineage and parity | Artifact producer/reviewer |
| `ProductRegistrationReceipt` | Accepted Testudo registry transaction | Testudo API |

### 21.2 Modes

| Mode | Repository writes | Execution | Human gate | Output |
|---|---:|---:|---|---|
| `plan` | Mission artifacts only | Probes only | Plan approval | `PipelinePlan` |
| `build` | Bounded paths | Tests/smoke/live if approved | Implementation authorization + acceptance | Receipt + candidate version |
| `operate` | None | Active registered version | Run/source approval | Run, dataset and artifact receipts |

An Operator cannot transition directly to Builder after an error. It creates a defect/change request and stops.

## 22. Rendering-modelling profile

| Adapter | Authority | Runtime profile | Canonical output |
|---|---|---|---|
| Model geometry | Aimsun model/API | Licensed; stable IDs and CRS | network tables |
| SQLite results | Aimsun result DB | Interval extraction and quality | result tables |
| APA paths | Aimsun API preferred | API glue in `aimsun_psf` | path tables |
| FZP trajectories | trajectory file | streaming, Parquet, decimation | trip/index + Parquet views |

```text
Source references
→ canonical DuckDB/Parquet
→ semantic KPI/validation/comparison
→ HTML/PNG/XLSX/report/GeoLibre
→ PostgreSQL registry references
→ reviewed finding/publication
```

Presentation may not bypass canonical data after activation except a declared compatibility path with parity evidence.

## 23. Pipeline ADRs

| ID | Decision | Status |
|---|---|---|
| ADR-023 | `modeller-agents` owns a generic pipeline control plane, not implementation code. | Accepted |
| ADR-024 | Pipeline lifecycle distinguishes `plan`, `build` and `operate`. | Accepted |
| ADR-025 | Executable pipelines require versioned definitions and immutable active versions. | Accepted |
| ADR-026 | DuckDB is the structured result package; Parquet holds large partitions. | Accepted |
| ADR-027 | PostgreSQL stores registry/product records and references, not bulk results. | Accepted |
| ADR-028 | HTML, screenshots, Excel, reports and GeoLibre derive from canonical data and pass parity. | Accepted |
| ADR-029 | Source adapters preserve identity, method, quality and environment evidence. | Accepted |
| ADR-030 | GeoLibre is the initial Testudo visualization adapter, not a data authority. | Accepted |
| ADR-031 | Operator mode prohibits repository writes and unregistered entrypoints. | Accepted |
| ADR-032 | Source, contract, integration and live-model proof are separate dimensions. | Accepted |
| ADR-033 | Capability substitutes require a catalog-gap receipt and follow-up. | Accepted |
| ADR-034 | Rollback is baseline-relative and preserves unrelated work. | Accepted |

## 24. Repository extension

```text
modeller-agents/
  src/modeller/pipelines/
    models.py
    registry.py
    planner.py
    builder.py
    operator.py
    policy.py
    parity.py
    lineage.py
    residuals.py
  src/modeller/subsystems/
    rendering_automation/
  schemas/
    pipeline-definition.schema.json
    pipeline-plan.schema.json
    pipeline-run-request.schema.json
    pipeline-run-receipt.schema.json
    canonical-dataset-manifest.schema.json
    artifact-manifest.schema.json
```

Source repositories expose implementation definitions and entrypoints. The central registry validates and projects them.
