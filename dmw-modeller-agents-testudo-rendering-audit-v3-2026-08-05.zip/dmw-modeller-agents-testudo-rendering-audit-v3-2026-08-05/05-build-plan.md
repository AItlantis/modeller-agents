# 05 — Build Plan

## 1. Strategy

The plan is contract-first and migration-safe. Feature work stops until the runtime can prove identity, consent, result correctness, gate execution, and resume. Delivery uses vertical slices and two real mission pilots.

## 2. Phases and milestones

| Phase | Scope | Milestone / exit criterion | Complexity |
|---|---|---|---|
| 0 — Freeze and decide | Baseline, ADR approval, compatibility | Canonical runtime and contract version decisions approved | S |
| 1 — Contract foundation | Models, schemas, templates, catalog source | All canonical contracts and projections validate | L |
| 2 — Runtime kernel | Ledger, state engine, checkpoint, gate, consent | Deterministic lifecycle passes interruption/tamper tests | XL |
| 3 — Role and provider bridge | Native/external adapters, policies, lenses | Full DMW lifecycle executes without manual relay | XL |
| 4 — Integrations | Backend, recon, memory, knowledge, improvement | Strict readiness and integration seams pass | L |
| 5 — Compatibility and generation | Generated DMW/plugin assets, docs | No duplicate authoritative catalogs or schemas | M |
| 6 — Pilots | Rendering mission + distinct mission | Both accepted with KPI evidence | L |
| 7 — Migration and release | Shadow, rollback, cleanup, activation | One canonical runtime active and monitored | L |

## 3. Workstreams

- **Contracts and schemas** — identity, role, evidence, consent, backend, compatibility.
- **Runtime and recovery** — state engine, ledger, checkpoints, invalidation.
- **Providers and roles** — native/external/manual adapters, role policies, lenses.
- **Verification and safety** — gates, assertions, review decomposition, human approvals.
- **Knowledge and memory** — retrieval, authority context, verification strength, candidate seam.
- **Backend and capabilities** — result validation, smoke proof, lifecycle, registry.
- **Migration and developer experience** — generated projections, clean tree, diagnostics, docs.

## 4. Detailed plan register

| ID | Objective | Output | Owner | Dependencies | Acceptance criteria | Validation | Risk | Priority | Status |
|---|---|---|---|---|---|---|---|---|---|
| PLAN-001 | Freeze scope and establish baselines | Capture tests, doctor, schemas, catalogs, file counts, and contract versions. | Runtime lead | None | Baseline artifacts and hashes committed; no feature work during freeze. | Re-run commands and diff. | RISK-001 | P0 | Not started |
| PLAN-002 | Approve canonical runtime decision | Ratify ADR-001/002 and migration authority. | Owner/User | PLAN-001 | One runtime owner and DMW disposition recorded. | Decision receipt. | RISK-002 | P0 | Open decision |
| PLAN-003 | Define compatibility matrix | Declare contract 1.2 current and explicit 1.1 N-1 behavior. | Contract owner | PLAN-001 | Retired 1.0 fails with actionable error. | Unit/conformance tests. | RISK-003 | P0 | Not started |
| PLAN-004 | Create canonical contract models | Implement mission, dispatch, evidence, decision, backend, checkpoint schemas. | Runtime team | PLAN-002,PLAN-003 | Schemas generate valid JSON Schema and reject unknown/unsafe fields. | Schema suite. | RISK-004 | P0 | Not started |
| PLAN-005 | Template generation and parity | Generate templates/projections from canonical models. | Runtime team | PLAN-004 | All templates pass fill-and-validate tests; duplicate IDs fail. | Regression tests. | RISK-005 | P0 | Not started |
| PLAN-006 | Implement event/artifact ledger | Append-only events, immutable artifacts, dependency graph. | Runtime team | PLAN-004 | Material change invalidates dependent evidence. | Integration tests. | RISK-006 | P0 | Not started |
| PLAN-007 | Implement checkpoint manager | Discover, verify, and resume checkpoints. | Runtime team | PLAN-006 | Resume after every major state without replaying trusted work. | Interruption matrix. | RISK-007 | P0 | Not started |
| PLAN-008 | Implement orchestrator state engine | Only engine advances state and ingests receipts. | Runtime team | PLAN-004,PLAN-006 | Provider cannot directly mutate state; illegal transitions fail. | State-machine tests. | RISK-008 | P0 | Not started |
| PLAN-009 | Implement provider registry/interface | Native, external, manual, backend descriptors and capability validation. | Integration lead | PLAN-004,PLAN-008 | Mission-scoped grants accepted/rejected deterministically. | Provider contract tests. | RISK-009 | P0 | Not started |
| PLAN-010 | Build native provider adapter | Wrap current host Agent dispatch. | Integration lead | PLAN-009 | Native Worker and Reviewer complete typed lifecycle. | Fake and live smoke. | RISK-010 | P0 | Not started |
| PLAN-011 | Build external provider adapter | Support selected external tool with provenance and cancellation. | Integration lead | PLAN-009 | No manual relay for normal dispatch; identity hard-bound. | Stub/live external smoke. | RISK-011 | P0 | Not started |
| PLAN-012 | Add role policies and lenses | Decider, Manager, Recon, Worker, Reviewer and CEO/CTO/CFO/advisor overlays. | Method owner | PLAN-004 | Role policies contain no host tool names and pass authority tests. | Policy tests/evals. | RISK-012 | P1 | Not started |
| PLAN-013 | Implement consent service | Fresh digest-bound authorization request/receipt. | Security lead | PLAN-004,PLAN-008 | Relayed/inferred/self-authored authorization rejected. | Adversarial tests. | RISK-013 | P0 | Not started |
| PLAN-014 | Implement gate engine | Command/assertion execution, requiredness, evidence levels. | QA lead | PLAN-004,PLAN-008 | Pass impossible with failed/not-run required assertion. | Semantic gate suite. | RISK-014 | P0 | Not started |
| PLAN-015 | Worker ingestion and re-gating | Treat receipt as raw evidence and rerun gates. | Runtime team | PLAN-014 | Every accepted Worker result has orchestrator GateReceipt. | Integration tests. | RISK-015 | P0 | Not started |
| PLAN-016 | Review coordinator and decomposition | Historical baselines, progress, timeout, split, aggregation. | QA lead | PLAN-009,PLAN-014 | Stalled review splits and cannot lose required assertions. | Time/decomposition tests. | RISK-016 | P1 | Not started |
| PLAN-017 | Recon coordinator and budgets | Index-first query planning, evidence threshold, fallback. | Recon lead | PLAN-009,PLAN-012 | Budget enforced and insufficient evidence explicit. | Fixture missions. | RISK-017 | P1 | Not started |
| PLAN-018 | Verification-strength memory model | Add method/scope/freshness/evidence to durable claims. | Memory lead | PLAN-004 | Mechanical/read/reported claims remain distinguishable after resume. | Round-trip tests. | RISK-018 | P0 | Not started |
| PLAN-019 | Memory and knowledge adapters | Authority-aware query and candidate transport interfaces. | Memory/knowledge owners | PLAN-018 | No direct accepted-knowledge write; stale authority context flagged. | C1-style seam test. | RISK-019 | P1 | Not started |
| PLAN-020 | Harden backend result seam | Exact result path, containment, status, write order, relative artifacts. | Backend lead | PLAN-003,PLAN-004 | Malformed or inconsistent results fail closed. | Conformance suite. | RISK-020 | P0 | Not started |
| PLAN-021 | Backend smoke receipts and lifecycle | Digest-bound proof and activation states. | Backend lead | PLAN-020 | Strict readiness requires current smoke. | Tamper tests. | RISK-021 | P0 | Not started |
| PLAN-022 | Canonical capability catalog | One registry with generated aliases, plugin indexes, and DMW projection. | Method owner | PLAN-004,PLAN-005 | No duplicate selectable ID; generated parity green. | Catalog tests. | RISK-022 | P1 | Not started |
| PLAN-023 | Improvement ledger | Incident→defect→decision→contract→test→release. | Quality owner | PLAN-006 | Promoted improvement cannot close without regression test and version. | Ledger rules tests. | RISK-023 | P1 | Not started |
| PLAN-024 | Doctor/readiness remediation plan | Dependency-ordered activation plan. | Operations lead | PLAN-003,PLAN-021,PLAN-022 | `readiness --plan` provides executable next actions. | Golden outputs. | RISK-024 | P1 | Not started |
| PLAN-025 | Generate DMW compatibility plugin | Render roles, skills, manifests, schemas from canonical source. | Method owner | PLAN-012,PLAN-022 | Generated DMW package passes parity and role-tool tests. | Package smoke. | RISK-025 | P1 | Not started |
| PLAN-026 | Pilot 1: rendering/modelling mission | Replay live-fire scope with external Reviewer. | Pilot owner | PLAN-007–PLAN-025 | No manual relay; checkpoint recovery, 3 rounds, consent and gates proven. | Mission acceptance report. | RISK-026 | P0 | Not started |
| PLAN-027 | Pilot 2: distinct mission | Run a non-rendering mission across another repository capability. | Pilot owner | PLAN-026 | Demonstrates generality and lower context/dispatch overhead. | Mission acceptance report. | RISK-027 | P0 | Not started |
| PLAN-028 | Shadow migration and compatibility | Run old/new outputs in parallel and compare. | Release lead | PLAN-026,PLAN-027 | No critical traceability regression; rollback tested. | Shadow comparison. | RISK-028 | P0 | Not started |
| PLAN-029 | Remove duplicates and deprecate aliases | Delete/relocate historical mirrors after compatibility proof. | Release lead | PLAN-028 | Clean tree; old commands emit deprecation or remain compatible. | Import/catalog tests. | RISK-029 | P1 | Not started |
| PLAN-030 | Activate v1 and monitor | Switch selected profiles, observe KPIs, keep rollback window. | Owner/Operations | PLAN-029 | All production gates green; incident response tested. | Operational review. | RISK-030 | P0 | Not started |

## 5. Approval gates

| Gate | Required evidence | Approver | Stop condition |
|---|---|---|---|
| G0 Architecture | ADR-001/002, baseline, migration scope | User/owner | Competing runtime ownership unresolved |
| G1 Contract | Schema and template tests, compatibility matrix | Contract owner + Reviewer | Any unsafe field accepted or 1.0 routable |
| G2 Kernel | Interruption, tamper, invalidation, consent tests | Independent Reviewer | Resume trusts semantic read; consent can be relayed |
| G3 Provider | Native/external lifecycle and scope tests | Security/Runtime Reviewer | Provider can exceed capabilities or spoof identity |
| G4 Integration | Backend smoke, memory/knowledge seam, readiness plan | Repository owners | Metadata-only activation or direct vault write |
| G5 Pilot | Full mission evidence and KPI comparison | User + Reviewer | Manual relay, false pass, unrecoverable failure |
| G6 Release | Shadow comparison and rollback drill | Owner | Critical traceability, safety, or compatibility regression |

## 6. Definition of Ready

A plan item is ready only when objective, owner, source evidence, dependencies, risk, acceptance criteria, validation method, affected contracts, and rollback are explicit. Required repositories and providers must be available or represented by validated fakes.

## 7. Definition of Done

- Code and generated assets match canonical contracts.
- Unit, integration, conformance, adversarial, and relevant live tests pass.
- Required evidence is persisted and digest-bound.
- Documentation and migration notes are current.
- No unresolved P0 finding or risk remains in scope.
- Human approvals are represented by valid receipts.
- Rollback is executable and tested.

## 8. Testing strategy

Use contract tests first, then state-machine/property tests, provider fakes, interruption/tamper matrices, repository integration, and two live mission pilots. Every defect from the recons and live-fire mission becomes a regression test.

## 9. Migration

1. Introduce canonical models alongside existing schemas.
2. Generate compatibility artifacts and compare byte/semantic parity.
3. Route one mission profile to the new engine in shadow mode.
4. Switch pilots after approval.
5. Deprecate old aliases/catalog copies.
6. Remove duplicates after one release window.

## 10. Rollout and rollback

Rollout is profile-based, not global. A feature flag selects old or new runtime. Rollback restores the old path and replays no new mutations; new-run artifacts remain readable. Contract migrations are additive until the rollback window closes.

## 11. Relative sequencing

The critical path is `PLAN-002 → 004 → 006/008 → 009 → 013/014 → 015 → 026 → 027 → 028 → 030`. Memory sophistication, knowledge activation, and broad provider support must not delay the P0 runtime proof.

## 12. Testudo integration phases

| Phase | Goal | Exit criterion |
|---|---|---|
| Phase 7 — Product contract alignment | Ratify vocabulary, context, task, approval and data ownership | Testudo and runtime schemas pass cross-repository contract tests |
| Phase 8 — Gateway and persistence seams | Implement Gateway, PostgreSQL references, DuckDB manifests and artifact catalog | Reference mission creates a task, persists context and registers a dataset |
| Phase 9 — One-agent vertical slice | Complete project→prepare→approve→execute→analyze→finding→publication flow | E2E accepted by Transport Modeller and Project Manager |
| Phase 10 — Operational hardening | Performance, accessibility, recovery, permission and deployment validation | v2 readiness and rollback gates pass |

## 13. Detailed Testudo plan register

| ID | Objective | Output | Owner | Dependencies | Acceptance criteria | Validation | Risk | Status |
|---|---|---|---|---|---|---|---|---|
| PLAN-031 | Ratify cross-system vocabulary | Vocabulary and ID contract | Product + Architecture | DEC-001–DEC-020 | No ambiguous use of `run`, `task`, `mission` | Schema/doc review | RISK-036 | Ready |
| PLAN-032 | Define Testudo context envelope | Versioned schema and digest rules | Testudo backend | PLAN-031 | All required context and permission fields represented | Contract tests | RISK-031, RISK-035 | Ready |
| PLAN-033 | Build Orchestration Gateway | API/service module | Testudo + modeller-agents | PLAN-032 | Idempotent create/approve/execute/cancel operations | Integration tests | RISK-038 | Planned |
| PLAN-034 | Implement one-agent interaction adapter | Conversation-to-mission interaction layer | Product AI | PLAN-033 | Internal role names hidden; action/output types explicit | UX and API tests | RISK-032 | Planned |
| PLAN-035 | Map project responsibilities to gates | Policy definitions and authorization tests | Security + Product | PLAN-032 | Correct actor required for each sensitive action | Positive/negative auth tests | RISK-035 | Planned |
| PLAN-036 | Define PostgreSQL product schema seam | Tables/migrations for bindings and references | Testudo backend | PLAN-031 | Product authority stored without analytical payload leakage | Migration tests | RISK-033 | Planned |
| PLAN-037 | Define DuckDB dataset contract | Dataset manifest, schema and lifecycle | Data/Simulation | PLAN-031 | ResultSet queryable and bound to SimulationRun | Data integrity tests | RISK-033, RISK-039 | Planned |
| PLAN-038 | Define immutable artifact store contract | URI, digest, retention and access rules | Platform | PLAN-036 | Checkpoints/evidence recoverable and permission-scoped | Recovery tests | RISK-034 | Planned |
| PLAN-039 | Build task/event projection | ProductEvent publisher and reducer | Testudo + runtime | PLAN-033 | Task state matches mission events idempotently | Replay tests | RISK-034, RISK-037 | Planned |
| PLAN-040 | Implement partial-result registration | Partial ResultSet and authorized-use rules | Data + Product | PLAN-037, PLAN-039 | Missing/available/invalid outputs visible | Failure-injection tests | RISK-037 | Planned |
| PLAN-041 | Implement finding handoff | FindingCandidate/ReviewedFinding workflow | Product + Modelling | PLAN-034, PLAN-039 | Evidence and output classification preserved | Review workflow tests | RISK-037 | Planned |
| PLAN-042 | Implement publication handoff | Frozen PublicationVersion and approval | Product + PM | PLAN-041 | Project Manager approval and lineage enforced | Versioning/E2E tests | RISK-037 | Planned |
| PLAN-043 | Package approved external features as subsystems | Isolated adapters and attribution records | Runtime owner | DEC-012, PLAN-031 | No external subsystem owns state; kill switch works | License, contract and failure tests | RISK-040 | Planned |
| PLAN-044 | Execute Testudo vertical slice | Representative project journey | Cross-functional | PLAN-033–PLAN-043 | Project→simulation→finding→publication accepted | Automated + user E2E | RISK-038 | Planned |
| PLAN-045 | Preserve future event-store seam | PostgreSQL-compatible event interface and migration note | Architecture | PLAN-039 | No v1 dependency on event-store implementation | Interface and replay test | RISK-034 | Planned |

## 14. Testudo approval gates

| Gate | Approver | Evidence | Stops when |
|---|---|---|---|
| Product contract gate | Product + Architecture | Context, vocabulary, role and data ownership schemas | Terms or authorities are ambiguous |
| Security gate | Security + Project authority | Permission inheritance, external transmission, audit tests | Provider can exceed user scope |
| Simulation launch gate | Transport Modeller / Run Owner | Context, configuration, resources, cost and plan | Context or dependencies invalid |
| Technical finding gate | Technical Reviewer | Result lineage, validation, uncertainty, independent review | Evidence incomplete or non-comparable |
| Publication gate | Project Manager | Reviewed finding, frozen context, recipients and version | Approval or provenance missing |
| Cutover gate | Product + Runtime owner | Shadow comparison, recovery, performance and rollback | Old/new states diverge materially |

## 15. Pipeline control-plane phases

| Phase | Goal | Exit criterion |
|---|---|---|
| P-A — Define | Objects, modes, contracts and registry | A rendering-modelling plan validates without code changes |
| P-B — Build | Baseline, implementation, dataset/artifact gates | Candidate immutable version accepted |
| P-C — Prove | Contract, integration and live proof | Dimensions explicit; evidence or residual recorded |
| P-D — Operate | Testudo preparation, approval and execution | Registered version runs with no code writes |
| P-E — Publish | GeoLibre, finding and publication | Lineage and approvals preserved |

## 16. Detailed pipeline plan register

| ID | Objective | Output | Owner | Dependencies | Acceptance criteria | Validation | Risk | Priority | Status |
|---|---|---|---|---|---|---|---|---|---|
| PLAN-046 | Define pipeline object vocabulary | Pipeline objects and identities | Runtime architecture | PLAN-031 | Definition, version, plan and run are distinct | Domain/schema review | RISK-041 | P0 | Planned |
| PLAN-047 | Create control-plane schemas | JSON Schema and Python models | Runtime team | PLAN-046 | Unknown fields rejected; versions declared | Schema suite | RISK-041 | P0 | Planned |
| PLAN-048 | Create pipeline registry | Definition/version/capability registry | Runtime team | PLAN-047 | Only active compatible versions operable | Registry tests | RISK-041 | P0 | Planned |
| PLAN-049 | Add planning mode | Read-only Planner workflow | Runtime team | PLAN-047 | No production writes; complete plan | Negative tests | RISK-050 | P0 | Planned |
| PLAN-050 | Add source/dependency recon | Source, repository and environment inventory | Recon owner | PLAN-049 | All candidate locations enumerated | Recon tests | RISK-042 | P0 | Planned |
| PLAN-051 | Add stage/data-flow planner | DAG, contracts, approvals, rollback | Manager | PLAN-049,PLAN-050 | Every stage has owner/input/output/gate | Plan validator | RISK-041 | P0 | Planned |
| PLAN-052 | Add catalog-gap receipt | Exact/substitute/missing resolution | Runtime owner | PLAN-048 | Substitutes explicit and time-bounded | Capability tests | RISK-047 | P1 | Planned |
| PLAN-053 | Add live-proof residual contract | Separate acceptance dimensions | Runtime + QA | PLAN-047 | Unexecuted live proof cannot pass | State tests | RISK-051 | P0 | Planned |
| PLAN-054 | Plan rendering-modelling | Machine-valid reference plan | Pilot Manager | PLAN-049–PLAN-053 | All artifacts/data/approvals covered | Independent review | RISK-041 | P0 | Planned |
| PLAN-055 | Capture implementation baseline | Patch/status/digest receipt | Orchestrator | PLAN-054 | Rollback preserves unrelated work | Rollback drill | RISK-049 | P0 | Planned |
| PLAN-056 | Implement Builder policy | Bounded writes/no-git/tool grants | Runtime team | PLAN-047,PLAN-055 | Worker cannot escape scope | Path/identity tests | RISK-050 | P0 | Planned |
| PLAN-057 | Add pipeline work-order profile | Stage/data-specific WorkerBrief | Runtime team | PLAN-056 | Mode, contracts and environment explicit | Schema tests | RISK-047 | P0 | Planned |
| PLAN-058 | Add data-adapter capabilities | DuckDB, Parquet, Aimsun API, SQLite, FZP profiles | Capability owner | PLAN-052 | Exact IDs; no silent substitution | Catalog tests | RISK-047 | P1 | Planned |
| PLAN-059 | Add artifact capabilities | HTML, screenshot, Excel, report, GeoLibre profiles | Capability owner | PLAN-052 | Dependencies/proof/failure declared | Catalog tests | RISK-044 | P1 | Planned |
| PLAN-060 | Implement dataset acceptance | Manifest, schema, quality and lineage gate | Data team | PLAN-047,PLAN-058 | Dataset requires schema/query/quality pass | Contract tests | RISK-042 | P0 | Planned |
| PLAN-061 | Implement artifact parity gate | Manifest and semantic parity runner | Data + QA | PLAN-059,PLAN-060 | Required surfaces match canonical metrics | Parity tests | RISK-043 | P0 | Planned |
| PLAN-062 | Implement baseline-relative integration | Surgical integration and invalidation | Orchestrator | PLAN-055–PLAN-061 | Only mission delta integrated | Recovery tests | RISK-049 | P0 | Planned |
| PLAN-063 | Register PipelineVersion | Immutable source/contract/test reference | Pipeline owner | PLAN-062 | Exact entrypoint and dependencies | Registry smoke | RISK-041 | P0 | Planned |
| PLAN-064 | Build reference version | Execute supplied plan through code/contract scope | Pipeline team | PLAN-058–PLAN-063 | 31 items closed or residual | Full review | RISK-051 | P0 | Planned |
| PLAN-065 | Close licensed live proof | Human Aimsun/GeoLibre execution | Transport Modeller | PLAN-064 | Literal evidence attached | Live review | RISK-051 | P0 | Planned |
| PLAN-066 | Implement Operator policy | No code writes; active versions only | Runtime team | PLAN-048,PLAN-063 | Mutation and ad-hoc entrypoints blocked | Negative tests | RISK-050 | P0 | Planned |
| PLAN-067 | Implement Testudo discovery | Business workflow projection | Product + runtime | PLAN-048,PLAN-066 | Goals/prerequisites visible | UX tests | RISK-048 | P1 | Planned |
| PLAN-068 | Implement run preparation | Context/source/resource validation | Runtime team | PLAN-066 | Request binds project and SimulationRun | Tamper tests | RISK-052 | P0 | Planned |
| PLAN-069 | Implement launch approval | Run/Data Owner confirmation | Product + security | PLAN-068 | No sensitive run without approval | Gate tests | RISK-052 | P0 | Planned |
| PLAN-070 | Implement execution adapter | Entrypoint, cancel, logs and receipt | Runtime team | PLAN-063,PLAN-069 | State/exit/result consistency | Execution tests | RISK-053 | P0 | Planned |
| PLAN-071 | Register partial/full datasets | DuckDB/Parquet manifests | Data + product | PLAN-060,PLAN-070 | Partial uses visible | Failure tests | RISK-042 | P0 | Planned |
| PLAN-072 | Implement publication bridge | PostgreSQL artifact transaction | Product + runtime | PLAN-061,PLAN-071 | References registered atomically | API tests | RISK-048 | P0 | Planned |
| PLAN-073 | Implement GeoLibre/Testudo adapter | Metric/interval/section/degraded-mode UI | GeoLibre + Product | PLAN-061,PLAN-072 | Actual UI evidence | UI E2E | RISK-045 | P1 | Planned |
| PLAN-074 | Implement finding/report handoff | Evidence-linked finding and draft | Product + Modelling | PLAN-072,PLAN-073 | Claims cite evidence | Review E2E | RISK-043 | P1 | Planned |
| PLAN-075 | Operate vertical slice | Project→run→data→artifacts→publication | Cross-functional | PLAN-065–PLAN-074 | E2E accepted with recovery | Automated + user E2E | RISK-041–RISK-055 | P0 | Planned |

## 17. Pipeline approval gates

| Gate | Mode | Approver | Evidence | Stop condition |
|---|---|---|---|---|
| Plan | plan | Pipeline Owner + Architecture | sources, DAG, contracts, risks and rollout | authority or contract ambiguous |
| Implementation authorization | build | User/Repository owner | approved plan digest and baseline | inferred consent or unsafe baseline |
| Implementation acceptance | build | Reviewer + Pipeline Owner | re-gated tests, parity, residuals, rollback | failed assertion or stale artifact |
| Version activation | build→operate | Runtime + Pipeline Owner | immutable source/dependency/test receipt | unpinned dependency or missing smoke |
| Run launch | operate | Run Owner/Data Owner | context, sources, cost and version | stale context or missing permission |
| Dataset acceptance | operate | Technical Reviewer | schema, quality, lineage and partial rules | silent truncation or invalid quality |
| Artifact acceptance | operate | Technical Reviewer | parity, render evidence and digests | mismatch or failed render |
| Publication | product | Project Manager | reviewed finding and frozen lineage | missing approval or evidence |
