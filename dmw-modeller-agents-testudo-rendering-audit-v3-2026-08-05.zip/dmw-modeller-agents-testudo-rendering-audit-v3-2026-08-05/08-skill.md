# 08 — Reusable Skill: Audit and Build an Orchestration Runtime

## Name

`audit-build-orchestration-runtime`

## Purpose

Convert a collection of agent plugins, runtime repositories, mission evidence, and enhancement ideas into a traceable audit-to-build package that preserves authority while simplifying execution.

## Triggers

Use when asked to audit, merge, simplify, harden, benchmark, or implement a Decider/Manager/Recon/Worker/Reviewer system; when two orchestration repositories overlap; or when mission evidence exposes gate, consent, provider, recovery, memory, or catalog failures.

## Exclusions

Do not use for a single-file bug, ordinary code review, pure prompt writing, or automatic code mutation. Do not promote knowledge or authorize implementation.

## Inputs

- Governing context and accepted decisions.
- Repository recons, code/tests, manifests, schemas, workflows, and runtime outputs.
- Live-fire mission evidence.
- Enhancement/benchmark candidates.
- Constraints, target repository, owners, and desired artifacts.

## Preconditions

- Identify source hierarchy and authority.
- Confirm target repository and which system is governance versus runtime.
- Record whether code execution is available.
- Establish evidence classes and confidence rules.

## Context loading

1. Read governing context and boundaries.
2. Load the target repository map and current handoff.
3. Load recons and live-fire evidence.
4. Query code graph/index when available and fresh.
5. Inspect exact source/tests for load-bearing claims.
6. Search external primary sources only for benchmark gaps.

## Repository discovery

- Enumerate canonical and duplicate manifests, role definitions, schemas, templates, catalogs, workflows, runtime modules, tests, and generated outputs.
- Distinguish intended, documented, implemented, and observed behavior.
- Identify current version, commit, contract, and test/doctor evidence.
- Classify each capability: Configure, Reuse, Extend, Refactor, Integrate, Replace, Build New, Defer, Reject.

## Evidence

Every finding includes ID, observation, exact source, evidence class, confidence, impact, root cause, and corrective action. Prefer mechanical evidence. Store missing evidence explicitly.

## Analysis

Apply capability-gap analysis, Five Whys for major defects, build-vs-buy-vs-integrate, failure-mode analysis, and process/data-flow mapping. Separate logic failures from seam failures.

## Benchmark

Evaluate external systems by pattern, not popularity. Use primary repositories. Record license and operational constraints. For each pattern state adopt, adapt, avoid, or reject. External systems never override repository governance.

## Requirements

Create uniquely identified, testable BR/FR/NFR/DATA/INT/SEC/OBS/HITL/TEST requirements using MUST/SHOULD/MAY/MUST NOT. Trace them to findings, ADRs, plan items, tests, and risks.

## Decisions

Create ADRs for runtime ownership, generated projections, provider interface, state authority, evidence model, consent, memory/knowledge authority, compatibility, and recovery. Record rejected alternatives.

## Tool selection

- Code graph for semantic/call-path discovery, with freshness validation.
- Direct source search/read for proof.
- Test/doctor commands for mechanical verification.
- Web primary sources for current external benchmarks.
- Artifact generation only after findings and target decisions stabilize.

## Ambiguity handling

Do not silently reconcile conflicting sources. Record the conflict and recommend an owner decision. When implementation detail is missing, specify the required contract and acceptance test rather than inventing current behavior.

## Human interaction

Require explicit user decisions for runtime ownership, implementation authorization, provider/data-location changes, high-risk mutation, release cutover, rollback, and knowledge promotion. Define exact evidence and stop conditions.

## Validation

- Every required file exists.
- Every required section exists or is marked not applicable.
- Every finding is traceable.
- Every P0 requirement has a test and plan item.
- Human controls name reviewer, evidence, approval, and stop condition.
- No duplicate IDs.
- Cross-file terminology is consistent.
- Package validation report is green.

## Failure behavior

If source evidence is missing, mark Unknown and do not claim verification. If external research is unavailable, keep benchmark entries unverified. If time is limited, complete current state, target architecture, P0 requirements, plan, risks, and executive synthesis first.

## Completion criteria

The package can serve as an implementation baseline: current state, benchmark, build brief, architecture, plan, specification, vigilance, skill, decisions/risks, executive audit, source register, and traceability all exist and agree.

## Outputs

`README.md`, `01-current-approach.md` through `10-executive-audit.md`, `source-register.md`, and `traceability-matrix.csv`.

## Example

Input: “Extend DMW, simplify modeller-agents, add external Worker/Reviewer and persistent Decider memory.”

Output: current-state finding that provider grants are static; ADR for provider-neutral dispatch; FR for mission-scoped grants; SEC test for identity/scope; plan item for external adapter; risk for provider capability misreporting; human control for provider/data-location change.

## 18. Testudo product-context extension

When the target architecture includes Testudo, the skill MUST load, in this order:

1. confirmed user/product decisions;
2. Testudo Business Need and Design Brief;
3. Testudo Product Requirements Document;
4. current Testudo domain and API contracts;
5. `modeller-agents` runtime and DMW governance sources;
6. backend/data contracts;
7. repository evidence and tests.

The skill MUST explicitly map:

```text
Project
→ ActiveContextEnvelope
→ Conversation
→ WorkflowDefinition
→ Mission
→ Task
→ SimulationRun
→ ResultSet
→ EvidenceArtifact
→ Finding
→ Publication
```

It MUST NOT use `run` without qualification.

For agent embedding, completion requires:

- one visible-agent design;
- internal role policy/receipt mapping;
- project-responsibility approval matrix;
- PostgreSQL/DuckDB/artifact ownership table;
- task/event projection;
- findings/publications handoff;
- permission and data-transmission controls;
- one Testudo vertical-slice acceptance test.

The skill must treat product experience, orchestration runtime, technical backends, memory and accepted knowledge as separate authorities.

## 19. Pipeline lifecycle extension

### Mode selection

```text
Architecture/change not authorized → PLAN
Approved plan requires code changes → BUILD
User wants results from active version → OPERATE
```

Never infer BUILD from an OPERATE failure.

### PLAN outputs

- PipelineDefinition candidate;
- source/authority inventory;
- stage DAG;
- capability/environment map;
- dataset/artifact contracts;
- reuse/substitution decisions;
- work items, tests and rollback;
- acceptance dimensions and live residuals;
- Testudo discovery/task/registration design.

### BUILD outputs

- baseline receipt;
- bounded work orders;
- source changes in owning repositories;
- mechanical tests/gates;
- dataset/artifact/parity contracts;
- implementation/residual receipt;
- candidate PipelineVersion;
- rollback proof.

### OPERATE outputs

- context-bound PipelineRunRequest;
- approvals;
- stage events and PipelineRunReceipt;
- dataset/artifact manifests;
- Testudo registration receipt;
- finding/publication candidates;
- no code changes.

### Rendering-modelling profile

Requires model/SQLite/APA/optional FZP adapters, DuckDB/Parquet canonicalization, KPI/validation, HTML, PNG, XLSX, report and GeoLibre artifacts, parity, and explicit live/Testudo residual handling.

### Completion

A plan is not an implementation; an implementation is not an active version; an active version is not a successful run; a successful run is not an accepted finding or publication.
