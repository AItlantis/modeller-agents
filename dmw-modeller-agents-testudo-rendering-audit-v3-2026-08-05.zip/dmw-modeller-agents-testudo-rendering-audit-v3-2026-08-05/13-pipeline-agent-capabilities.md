# 13 — Pipeline Agent Capabilities: Plan, Implement, Use

## 1. Purpose

The single visible Testudo agent uses hidden DMW roles to plan, implement and operate pipelines without authority confusion.

## 2. Capability matrix

| Concern | PLAN | BUILD | OPERATE |
|---|---|---|---|
| User goal | design/change proposal | implement approved plan | obtain results |
| Production writes | prohibited | bounded/approved | prohibited |
| Execution | probes only | tests/smoke/live if approved | registered version only |
| Git | normally none | orchestrator only after acceptance/authorization | none |
| Human gate | plan approval | mutation + acceptance | run/source approval |
| Main output | PipelinePlan | receipt + PipelineVersion | PipelineRunReceipt |
| Failure | revise/block | debug within budget/block | retry/recover/create defect; no code edit |

## 3. PLAN

Internal roles:

- Decider clarifies outcome/authority.
- Manager owns plan.
- Recon gathers repository/data/product evidence.
- Reviewer challenges scope, dependencies, acceptance and rollback.
- No implementation Worker.

Required output:

- PipelineDefinition candidate;
- source/authority inventory;
- stage and cross-repository DAG;
- canonical data and artifact contracts;
- capability/environment map and gaps;
- reuse decisions;
- work items/scopes/tests;
- acceptance dimensions/live residuals;
- deployment/migration/rollback;
- Testudo discovery/task/registration design.

Stop when source authority, ownership, parity, live proof or capability substitution is ambiguous.

## 4. BUILD

Before mutation capture repository commit/status/untracked files, baseline patch/snapshot, write-scope digests and existing gates.

WorkerBrief adds:

- pipeline definition/plan IDs;
- `mode=build`;
- stage IDs and data contracts;
- capability/substitution receipt;
- environment profile;
- read/write scope and prohibitions;
- tests and acceptance dimension;
- rollback class.

Acceptance requires exact changed files, adapter coverage, canonical query/quality tests, artifact parity, render evidence, no weakened tests, generated-artifact currency, explicit residuals and rollback proof.

## 5. OPERATE

Prepare and display:

- project/model/version/period/scenario/SimulationRun;
- pipeline profile/version;
- sources and owner authorization;
- stages and degraded options;
- outputs, cost/duration/resources;
- external services/transmissions;
- retry/cancel/recovery;
- approver.

Rules:

- active registered version only;
- no repository writes or ad-hoc scripts;
- events correlate to Testudo Task/Mission;
- process exit and result state agree;
- partial outputs preserved/classified;
- canonical data validated before artifact/publication acceptance;
- artifacts can regenerate without rerunning valid extraction.

Outputs: run receipt, source receipts, dataset/artifact manifests, registration receipt, residuals and finding/publication candidates.

## 6. Transitions

| From | To | Condition |
|---|---|---|
| PLAN | BUILD | fresh authorization referencing approved plan/baseline |
| BUILD | OPERATE | immutable version accepted and activated |
| OPERATE | PLAN | enhancement or defect needs design |
| OPERATE | BUILD | never direct |
| BUILD | PLAN | material architecture/scope change invalidates plan |

## 7. Rendering-modelling examples

**Plan:** design extraction, DuckDB/Parquet, HTML/screenshots/Excel/report/GeoLibre, Testudo seam and live residuals.

**Implement:** bounded `aimsun-psp` changes, tests, manifests, parity, candidate version.

**Use:** run selected version, produce canonical package/artifacts, open GeoLibre, register task/results and prepare reviewed report—without code changes.

## 8. Checklist

- [ ] Mode matches intent.
- [ ] Grants are mode-specific.
- [ ] Pipeline/profile/version explicit.
- [ ] Project and SimulationRun explicit for operation.
- [ ] Source authority/permissions explicit.
- [ ] Completion matches mode.
- [ ] PLAN/OPERATE cannot write repositories.
- [ ] BUILD claims mechanically reverified.
- [ ] Live residuals cannot pass.
