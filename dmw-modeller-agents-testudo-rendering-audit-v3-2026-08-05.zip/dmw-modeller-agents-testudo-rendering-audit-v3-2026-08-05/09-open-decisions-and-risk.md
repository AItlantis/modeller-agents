# 09 — Confirmed Decisions, Residual Choices and Risk Register v3

## 1. Decision status

All audit-v1 recommendations are approved. DEC-012 and DEC-014 are resolved by the user feedback dated 2026-08-05.

| ID | Decision | Confirmed ruling | Status |
|---|---|---|---|
| DEC-001 | Executable mission-state authority | `modeller-agents` is the sole executable orchestration runtime. | Approved |
| DEC-002 | DMW disposition | DMW becomes canonical governance contracts and generated compatibility assets, not a second runtime. | Approved |
| DEC-003 | Manager/Reviewer continuity | Provider sessions may be replaced; artifact and policy identity provide continuity. | Approved |
| DEC-004 | Contract version | Contract 1.2 with explicit 1.1 N-1 compatibility. | Approved |
| DEC-005 | First external provider | Current external Codex provider plus deterministic fake adapter. | Approved |
| DEC-006 | Artifact format | Typed JSON/events internally; generated Markdown for human artifacts. | Approved |
| DEC-007 | Decider persona model | Selectable policy lenses over one user/mission memory. | Approved |
| DEC-008 | Recon fan-out | One general scout and at most two specialists by default, with explicit budget exceptions. | Approved |
| DEC-009 | Review duration | Historical baseline, floor/ceiling and named decomposition points. | Approved |
| DEC-010 | Knowledge-axis timing | Activate after runtime pilots and authority-context/C1 proof. | Approved |
| DEC-011 | Git/merge | Workers do no git; orchestrator uses git only after explicit authorization; no auto-merge. | Approved |
| DEC-012 | External component legal posture | Legal review approved. Features may be integrated as isolated `modeller-agents` subsystems with exact-version attribution, tests and replaceability. | Approved |
| DEC-013 | Historical compatibility | One release/profile migration window. | Approved |
| DEC-014 | Persistence | DuckDB for simulation datasets; PostgreSQL for users/projects/product information and a future product event store; content-addressed files/object storage for mission evidence. | Approved |
| DEC-015 | Pilot 2 | Use a non-rendering, multi-repository mission with a real external provider; the Testudo vertical slice is the preferred candidate. | Approved direction; execution pending |
| DEC-016 | Testudo embedding | Testudo owns the visible agent and product domain; `modeller-agents` is embedded as a subsystem. | Confirmed by product architecture |
| DEC-017 | Visible agent | One visible Project × User agent conversation; internal DMW roles remain hidden policies/subsystems. | Confirmed by product brief |
| DEC-018 | Context authority | Material actions bind to a signed/versioned Testudo active-context digest. | Approved baseline |
| DEC-019 | Domain vocabulary | Mission, Task, SimulationRun, DispatchAttempt and ResultSet are distinct. | Approved baseline |
| DEC-020 | Human responsibility mapping | Transport Modeller approves simulation/technical findings; Project Manager approves publication; Data/Model Owner controls owned assets; Administrator controls technical access. | Approved baseline |

## 2. Residual implementation choices

| ID | Choice | Options | Recommendation | Owner | Timing |
|---|---|---|---|---|---|
| DEC-021 | DuckDB physical packaging | per SimulationRun; per project; shared catalog | Start per project with immutable/versioned result schemas and per-run manifests; benchmark before consolidation | Data owner | PLAN-037 |
| DEC-022 | Gateway deployment | in-process module; separate service | Same contract supports both; local in-process first, production process separation | Architecture | PLAN-033 |
| DEC-023 | Artifact store | governed filesystem; object store | Interface first; filesystem local, object storage production | Platform | PLAN-038 |
| DEC-024 | PostgreSQL event-store adoption | v1; later; never | Later after task-event volume and replay requirements are measured | Architecture | PLAN-045 |
| DEC-025 | Testudo pilot project | rendering mission; demand workflow; controlled Aimsun pilot | Select a representative project with launch, partial result, finding and publication evidence | Product + Modelling | Before PLAN-044 |

## 3. Assumptions

| ID | Assumption | Confidence | Validation |
|---|---|---|---|
| ASM-001 | Testudo backend can issue server-attested context/permission envelopes | Medium | Prototype PLAN-032/033 |
| ASM-002 | DMW assets can be generated/refactored without host breakage | Medium | Compatibility suite |
| ASM-003 | DuckDB can satisfy representative simulation analytics on target storage | Medium | PLAN-037 load tests |
| ASM-004 | PostgreSQL project schema can reference external artifacts/datasets without copying payloads | High | PLAN-036/038 |
| ASM-005 | One visible agent can communicate task progress without exposing internal role complexity | Medium | PLAN-034 user tests |
| ASM-006 | Existing Aimsun/backend results can be normalized into ResultDatasetManifest | Medium | Backend pilot |
| ASM-007 | Exact project responsibilities are available to authorization policy | Medium | Product permissions design |

## 4. Dependencies and blockers

| ID | Dependency | Effect | Status |
|---|---|---|---|
| DEP-001 | Contract 1.2/N-1 alignment | Blocks active backends | Required |
| DEP-002 | Testudo active-context schema | Blocks product-safe mission creation | Required |
| DEP-003 | Project responsibility/permission matrix | Blocks human approval and provider grants | Required |
| DEP-004 | ResultDatasetManifest | Blocks DuckDB result registration | Required |
| DEP-005 | Artifact store interface | Blocks production recovery and lineage | Required |
| DEP-006 | Task event projection | Blocks persistent product task experience | Required |
| DEP-007 | Representative Testudo project | Blocks vertical-slice acceptance | Required |

## 5. Risk register

The v1 risks RISK-001–RISK-030 remain active unless their mitigations are completed. New v2 risks:

| ID | Cause | Consequence | Likelihood | Impact | Severity | Mitigation | Contingency | Owner | Status |
|---|---|---|---|---|---|---|---|---|---|
| RISK-031 | Active context changes or is incorrectly mapped | Mission acts on wrong version/scenario/SimulationRun | Medium | Critical | Critical | Signed envelope, digest binding, invalidation | Stop and re-prepare mission | Product/runtime | Open |
| RISK-032 | Internal role complexity leaks into UI | Confusion, fragmented conversation, mistaken authority | Medium | High | High | One Interaction Gateway and output classification | Hide diagnostics and revert to single-agent adapter | Product/UX | Open |
| RISK-033 | Product and analytical storage boundaries blur | Performance, consistency and lineage failures | Medium | High | High | Placement policy, manifests, CI checks | Migrate payloads and retain compatibility views | Data/Architecture | Open |
| RISK-034 | Mission ledger and product events diverge | Stale task state or false completion | Medium | Critical | Critical | Idempotent publisher, replay, correlation and reconciliation | Rebuild task state from verified ledger | Runtime/Testudo | Open |
| RISK-035 | Provider or agent exceeds user/project permission | Confidentiality or unauthorized action | Medium | Critical | Critical | Signed capability envelope, least privilege, negative tests | Cancel, revoke, audit and incident response | Security | Open |
| RISK-036 | Run/task/mission vocabulary is conflated | Wrong object updated or result overwritten | Medium | High | High | Distinct schemas and IDs; ban unqualified `run` | Data repair from correlation ledger | Architecture | Open |
| RISK-037 | Technical completion is treated as business approval | Invalid finding or client publication | Medium | Critical | Critical | Separate transitions and actors | Withdraw publication, preserve audit, re-review | Product/Modelling | Open |
| RISK-038 | Product/runtime deployment coupling is too tight | Restart or scaling failure affects whole app | Medium | High | High | Versioned API, process isolation path, feature flag | Run local/legacy workflow path | Platform | Open |
| RISK-039 | DuckDB concurrency/storage assumptions are wrong | Dataset locks, slow queries or corruption | Medium | High | High | Representative load/concurrency tests, immutable writes, Parquet fallback | Partition datasets or introduce query service | Data | Open |
| RISK-040 | Approved external features create hidden coupling | License, security or maintainability exposure | Low/Medium | High | High | Subsystem isolation, attribution, SBOM, kill switches | Disable/replace subsystem | Runtime/Legal | Open |

## 6. Decision implementation order

1. Implement DEC-001–DEC-014 runtime baseline.
2. Implement DEC-016–DEC-020 product/runtime seam.
3. Resolve DEC-021–DEC-025 through the named plan items.
4. Execute the Testudo vertical slice before broad feature expansion.

## 7. Rendering-modelling decisions

| ID | Decision | Confirmed ruling | Status |
|---|---|---|---|
| DEC-026 | Pipeline family | `rendering-modelling` is a first-class reusable reference profile. | Approved |
| DEC-027 | Agent modes | Support separate `plan`, `build` and `operate` modes. | Approved |
| DEC-028 | Canonical analytics | DuckDB for structured simulation results; Parquet for bulk partitions. | Approved |
| DEC-029 | Artifact derivation | HTML, screenshots, Excel, reports and GeoLibre derive from canonical data. | Approved |
| DEC-030 | GeoLibre role | Initial Testudo visualization adapter, not data authority. | Approved |
| DEC-031 | PostgreSQL placement | Registry, tasks, permissions, summaries and references; no bulk rows. | Approved |
| DEC-032 | Source adapters | Geometry, SQLite, APA and FZP are explicit profiles. | Approved |
| DEC-033 | Code ownership | Backend implementation stays in owning repositories; control plane in `modeller-agents`. | Approved |
| DEC-034 | Proof dimensions | Implementation, contract, integration and live-pilot proof are independent. | Approved |
| DEC-035 | Catalog expansion | Add exact data/rendering/publication capabilities. | Approved direction |

## 8. Additional implementation choices

| ID | Choice | Options | Recommendation | Owner | Timing |
|---|---|---|---|---|---|
| DEC-036 | Canonical schema ownership | central; pipeline; hybrid | Pipeline-owned schema under central manifest/version rules | Data + Pipeline | PLAN-047/060 |
| DEC-037 | GeoLibre migration | retain; replace; deprecate | Additive DuckDB package, pilot, then deprecate shard format | GeoLibre + Pipeline | PLAN-073 |
| DEC-038 | Screenshot engine | browser; GeoLibre API; both | Stable interface; browser reference first | Rendering | PLAN-059 |
| DEC-039 | DuckDB packaging | per run; project; hybrid | Immutable per SimulationRun plus optional project catalog | Data | PLAN-060/071 |
| DEC-040 | Registry location | central; source; hybrid | Source-owned definition projected into central registry | Runtime + repos | PLAN-048 |

## 9. Additional risks

| ID | Cause | Consequence | Likelihood | Impact | Severity | Mitigation | Contingency | Owner | Status |
|---|---|---|---|---|---|---|---|---|---|
| RISK-041 | Definition/plan/implementation drift | Wrong version/stage executed | Medium | Critical | Critical | versioning/digests/registry | deactivate/re-plan | Runtime/Pipeline | Open |
| RISK-042 | Source/schema/quality drift | Incorrect analytical data | Medium | Critical | Critical | source receipts and quality gates | reject/partial-register | Data | Open |
| RISK-043 | Cross-surface mismatch | Misleading conclusion | Medium | Critical | Critical | blocking parity | withdraw/regenerate | Data/Modelling | Open |
| RISK-044 | Rendering nondeterminism/empty layer | Invalid evidence | Medium | High | High | render-ready/error detection | degrade/regenerate | Rendering | Open |
| RISK-045 | GeoLibre format divergence | incompatibility/double authority | Medium | High | High | compatibility manifest | old adapter feature flag | GeoLibre | Open |
| RISK-046 | Trajectory volume | OOM/storage inflation | High | High | Critical | streaming/partition/retention | disable trajectories | Data/Platform | Open |
| RISK-047 | Catalog gaps | weak skill boundaries | High | High | Critical | exact skills/gap receipts | specialist review | Runtime | Open |
| RISK-048 | Deferred/non-transactional Testudo registration | incomplete product state | Medium | Critical | Critical | dedicated API mission | reconcile later | Product/Runtime | Open |
| RISK-049 | Unsafe rollback | code/data loss | Medium | Critical | Critical | baseline-relative reversal | restore snapshot | Orchestrator | Open |
| RISK-050 | Wrong mode authority | unauthorized code change | Medium | Critical | Critical | mode grants/negative tests | cancel/revoke | Security | Open |
| RISK-051 | Fixture presented as live proof | false acceptance | Medium | Critical | Critical | separate dimensions | human pilot | QA/Modelling | Open |
| RISK-052 | Missing run/source approval | unauthorized/costly run | Medium | Critical | Critical | Run/Data Owner gates | cancel | Product/Security | Open |
| RISK-053 | State/result inconsistency | false completion/recovery failure | Medium | High | High | state/exit consistency | rebuild from receipts | Runtime | Open |
| RISK-054 | Sensitive data leak | confidentiality breach | Low/Medium | Critical | Critical | sensitivity/DLP | disable/incident response | Security | Open |
| RISK-055 | Local calibration promoted globally | incorrect knowledge | Medium | High | High | scope validator/governed inbox | reject/supersede | Knowledge | Open |
