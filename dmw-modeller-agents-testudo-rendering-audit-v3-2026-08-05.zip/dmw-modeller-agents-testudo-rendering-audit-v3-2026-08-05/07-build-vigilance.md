# 07 — Build Vigilance

## 1. Vigilance objective

Prevent probabilistic agents, stale context, infrastructure failure, provider substitution, or document drift from crossing deterministic authority boundaries.

## 2. Human review model

| Activity | Automation | Evidence | Reviewer | Approval | Stop condition |
|---|---|---|---|---|---|
| Intent clarification | Assisted | DecisionRequest + context receipts | User | Explicit answer for material ambiguity | Conflicting or missing goal |
| Recon | Bounded automation | Query plan, source/digest, findings, missing proof | Manager/Reviewer for material facts | Evidence sufficiency gate | Budget exhausted or stale index |
| Plan creation | Assisted | Versioned plan, dependencies, tests, risks | Independent Reviewer | Pass/conditional pass | Plan changes outside named findings |
| Implementation authorization | No automation of approval | Exact request + plan/review digests | User | Fresh explicit answer | Relayed, stale, agent-authored, ambiguous response |
| Provider dispatch | Automated within policy | DispatchRequest, capabilities, policy digest | Orchestrator | Capability subset valid | Identity/capability/path mismatch |
| Worker mutation | Bounded automation | Diff/artifacts, tests, Worker receipt | Orchestrator | Rerun gate pass | Out-of-scope write, git action, failed gate |
| Plan/result review | Independent automation | Assertion-level evidence and verdict | Reviewer/human on conflict | All required assertions pass | Stall, missing evidence, conflict |
| Backend run | Automated within registered capability | Smoke/runtime/result receipts | Backend owner/Orchestrator | Contract and result gate pass | Incompatible contract, stale smoke, malformed result |
| Checkpoint resume | Automated mechanical verification | CheckpointVerificationReceipt | Orchestrator; human on irreconcilable state | All hashes/schema/tests valid | Any stale/tampered dependency |
| Memory candidate | Automated classification | AuthorityContext + candidate | Memory/knowledge owner | Target is companion/inbox/flag | Stale context, restricted data, conflict |
| Knowledge promotion | No autonomous acceptance | Draft, evidence, board verdict | Knowledge board | Explicit accepted decision | Authority inflation or missing provenance |
| Improvement promotion | Assisted | Incident chain + regression test + version | Quality owner | Closure links complete | No test, no owner, no release |
| Release cutover | Assisted | Shadow comparison, rollback drill, KPI report | Release owner/User | Explicit go/no-go | Critical regression or rollback failure |

## 3. Evidence rules

1. A claim is not a gate result.
2. Semantic reading cannot replace mechanical verification where a command, schema, digest, grep, diff, or test is available.
3. Independent review must reproduce or inspect evidence, not merely restate Manager claims.
4. Context caches and memory are advisory until source/digest/freshness are verified.
5. Every override lowers, never raises, the represented verification strength unless new evidence exists.
6. Pass requires all required assertions to pass; absence is `not-run`, not implied pass.

## 4. Failure modes

| Failure mode | Detection | Immediate response | Recovery | Residual control |
|---|---|---|---|---|
| Provider stalls | No progress; historical threshold | Cancel; persist status; split or substitute | Resume from last checkpoint | Duration and decomposition metrics |
| Provider quota/error | Typed provider failure | Stop dispatch; preserve artifacts | Substitute provider/manual explicit path | No silent fallback |
| Worker overreaches | Path/tool/git audit | Reject receipt and quarantine artifacts | Re-dispatch bounded scope | Capability tests |
| False pass | Assertion/gate mismatch | Block transition | Rerun mechanical gate | Required assertion IDs |
| Stale generated artifact | Dependency digest mismatch | Mark stale | Regenerate and diff | Invalidation graph |
| Stale memory/context | Digest/freshness mismatch | Downgrade or flag | Query source/current index | Verification metadata |
| Fabricated consent | Actor/channel/request mismatch | Block and alert | Ask exact question to user | One-time authorization receipt |
| Duplicate catalog source | Catalog parity check | Block build | Remove/generate projection | Canonical source test |
| Backend drift | Descriptor/lock/runtime digest mismatch | Deactivate capability | Re-run conformance/smoke | Evidence-backed lifecycle |
| Checkpoint tamper | Hash/schema/path/test mismatch | Refuse resume | Select earlier valid checkpoint or restart | Append-only ledger |
| Review conflict | Divergent assertion results | Escalate | New independent review/human ruling | No silent averaging |
| Sensitive evidence leak | Classification/redaction/path rules | Stop and quarantine | Redact, rotate, review | Secret/restricted logging controls |

## 5. AI and automation risks

- **Authority hallucination:** mitigated by actor-bound typed receipts.
- **Context rot:** mitigated by bounded dispatch context and source digests.
- **Self-confirmation:** mitigated by independent Reviewer and orchestrator-owned gates.
- **Overengineering:** mitigated by Worker reuse ladder and write-scope limits.
- **Loop stagnation:** mitigated by progress detection, retry budget, cancellation, and decomposition.
- **Policy drift:** mitigated by generated projections and policy digests.
- **Memory poisoning:** mitigated by verification strength, authority context, and human promotion.

## 6. Data, privacy, and security controls

- Local-first storage for mission artifacts unless a provider contract explicitly declares transfer.
- Provider request records declare data categories and redactions.
- Restricted sources are referenced by secure IDs, not copied into general artifacts.
- Secrets are passed through scoped runtime mechanisms and never written to receipts.
- Retention and deletion operate on mission artifacts while preserving required audit tombstones.
- External providers receive only minimum context.

## 7. Stop conditions

Stop the current transition when:

- required evidence is missing or stale;
- provider identity/capability cannot be proven;
- user authorization is ambiguous or relayed;
- a Worker touches forbidden paths or git;
- a required assertion fails or is not run;
- review exceeds the progress threshold without decomposition;
- backend result and process status disagree;
- checkpoint verification fails;
- sensitive data classification is unknown;
- two authoritative definitions conflict.

## 8. Escalation

1. Orchestrator marks the mission blocked and records the exact failing control.
2. Manager proposes bounded recovery options and affected artifacts.
3. Reviewer evaluates any plan that changes safety, scope, or acceptance criteria.
4. User/owner decides when required by the authority table.
5. Recovery starts only from a verified checkpoint or clean baseline.

## 9. Rollback

Rollback is artifact- and profile-based. Disable the new runtime profile, reactivate the prior route, preserve new artifacts as read-only evidence, and invalidate any authorization/review that depended on new runtime-only outputs. Do not delete evidence during emergency rollback.

## 10. Monitoring and post-implementation controls

Track false-pass attempts blocked, identity/scope rejections, provider stalls, decompositions, checkpoint recoveries, stale artifact invalidations, manual relay use, user-consent re-prompts, context budget, gate duration, mission completion, and improvement closure. Review weekly during pilots and after every material incident.

## 11. Vigilance acceptance

The system is not ready for general activation until every P0 activity in the table has a typed receipt, negative tests, a named reviewer, explicit stop behavior, and a tested rollback.

## 10. Testudo embedding vigilance

| Activity | Automation | Evidence | Reviewer | Approval | Stop condition |
|---|---|---|---|---|---|
| Build active context | Automated validation | Signed envelope, permission digest, object compatibility | Testudo backend | None for read-only | Missing/stale/unauthorized field |
| Prepare workflow | AI-assisted | Objective, context, effects, prerequisites, uncertainty | Transport Modeller | Preview for medium/high risk | Ambiguous objective or incompatible context |
| Launch simulation | Automated after approval | Exact plan/config/context/resource digests | Transport Modeller / Run Owner | Fresh explicit confirmation | Approval missing/expired or configuration changed |
| Register result dataset | Automated validation | Manifest, schema, checksum, quality, SimulationRun | Runtime gate | None | Dataset invalid, orphaned or incomplete without qualification |
| Accept finding | AI-assisted, human decision | Evidence lineage, validation, uncertainty, independent review | Technical Reviewer | Accept/correct/reject | Evidence insufficient or non-comparable |
| Publish to client | AI-prepared, human approved | Frozen version, recipients, reviewed findings, provenance | Project Manager | Explicit publication approval | Missing reviewer, approver, context or recipient control |
| External provider transmission | Automated policy + human where required | Destination, purpose, fields, classification, redaction | Security/Data Owner | Policy-defined consent | Prohibited or unapproved data |
| Recover task | Automated verification | Checkpoint verification, event replay, dataset state | Runtime + user when material | Resume confirmation where effects changed | Hash/scope/gate mismatch |

### Additional stop conditions

- Testudo task state and mission state disagree after replay.
- A provider returns a result for another project/context digest.
- PostgreSQL contains unbounded analytical rows outside an approved exception.
- DuckDB contains user credentials, permissions or approval authority.
- Internal role content is shown as a human decision.
- Technical mission completion is used to auto-accept a finding or publication.
- Event delivery gaps cannot be reconciled from the mission ledger.
- A third-party subsystem cannot be disabled without corrupting mission state.

### Rollback

The Testudo integration must be feature-flagged by workflow profile. Rollback disables the Gateway path, leaves PostgreSQL product records intact, marks affected tasks paused/rolled back, and continues to preserve mission artifacts for forensic review. DuckDB datasets are immutable or versioned; rollback changes references, not historical data.

## 11. Rendering-modelling vigilance

| Activity | Automation | Evidence | Reviewer | Approval | Stop condition |
|---|---|---|---|---|---|
| Planning | Assisted; no production writes | sources, plan, contracts, DAG | Pipeline Owner + Architecture | Plan approval | authority/source/contract ambiguous |
| Baseline | Mechanical | patch/status/digests | Orchestrator | Required | baseline absent or unsafe |
| Implementation | Bounded Workers | diffs, tests, gates | Manager + Reviewer | mutation + acceptance | scope escape or failed assertion |
| Activation | Automated validation + gate | immutable source/dependencies/tests | Runtime + Pipeline Owner | activation | mutable dependency or missing proof |
| Operation | Registered version | context, approvals, events, receipt | Run Owner | launch | stale context or missing permission |
| Dataset | Automated + expert | schema, quality, lineage | Technical Reviewer | accept/partial/reject | truncation, invalid quality or missing source |
| Artifacts | Automated | manifest, render evidence, parity | Technical Reviewer | artifact acceptance | mismatch, empty render or uncited claim |
| Testudo registration | Transactional | receipt/correlation IDs | Product/runtime | policy-based | partial authoritative state |
| Publication | Assisted | frozen digests and reviewed finding | Project Manager | explicit approval | missing evidence/reviewer/recipient |
| Learning | Assisted | candidate event/evidence | Knowledge reviewer | external promotion | automatic promotion attempt |

### Stop conditions

- An Operator requests repository write tools.
- Presentation reads raw data after canonical activation without compatibility exception.
- A shared KPI differs across surfaces.
- Screenshot lacks render-ready evidence or contains empty/error state.
- Dataset manifest omits source, quality or partial status.
- Live Aimsun, GeoLibre UI or Testudo-write pass is claimed from fixtures only.
- Capability substitute lacks a gap receipt.
- Rollback would overwrite pre-existing work.
- Bulk simulation rows are sent to PostgreSQL.

### Pipeline rollback

1. Stop new requests for the version.
2. Preserve failed run, logs and manifests.
3. Deactivate rather than mutate the version.
4. Reverse only mission delta relative to baseline.
5. Restore last accepted version.
6. Reconcile Testudo Task/registry from receipts.
7. Regenerate derived artifacts only after data/parity pass.
8. Create defect and regression-test candidate.
