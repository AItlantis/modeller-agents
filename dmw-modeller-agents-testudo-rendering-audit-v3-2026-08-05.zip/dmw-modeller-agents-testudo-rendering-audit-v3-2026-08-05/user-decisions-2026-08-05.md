# Confirmed Decisions — Audit v3

**Date:** 2026-08-05  
**Authority:** User / product owner  
**Applies to:** DMW-Orchestration, `modeller-agents`, and Testudo integration architecture.

## Confirmed rulings

1. All recommendations attached to the open decisions in audit v1 are approved.
2. **DEC-012:** legal review is approved. Features inspired by or reused from the reviewed repositories may be integrated within `modeller-agents` as isolated subsystems, subject to exact-version attribution and repository license compliance during implementation.
3. **DEC-014:** DuckDB is the analytical store for simulation datasets. PostgreSQL is the system of record for users, projects, permissions, project metadata, conversations, tasks, findings, publications, and related product information.
4. PostgreSQL may be extended in later Testudo work to implement the product event store.
5. Audit v3 must incorporate the future Testudo architecture and define how the orchestration roles are embedded behind Testudo's single visible contextual AI agent.

## Interpretation used by this package

- Approval of a recommendation establishes the architectural direction; it does not waive implementation acceptance tests.
- Third-party feature integration means an internal subsystem behind a stable interface, not wholesale adoption of an external orchestration runtime.
- The mission-local append-only checkpoint ledger remains file/object based for deterministic recovery in v1. It is distinct from the future PostgreSQL-backed Testudo product event store.
- DuckDB does not own identity, permissions, workflow authority, approvals, conversations, or publications.

## Rendering-modelling direction confirmed in v3

- `rendering-modelling` extracts simulation data, structures it and presents HTML, screenshots, Excel and GeoLibre packages/plugins.
- GeoLibre is the starting point for Testudo visualization.
- `modeller-agents` must plan, implement and use this class of pipeline.
- This package interprets those as separate governed modes, not one unrestricted agent.
