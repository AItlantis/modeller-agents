# Source Register

## Uploaded and governing sources

| ID | Title | Path | Role | SHA-256 |
|---|---|---|---|---|
| SRC-001 | DMW reconnaissance | /mnt/data/dmw-recon-05-08-2026.md | Primary repository reconnaissance | fa9991eceaa9063a3a80c562ecfb72328e996472496d033791c60454d9c89187 |
| SRC-002 | Enhancement brief and live-fire findings | /mnt/data/enhancement.md | Primary enhancement scope | 2ae77b28786d0aa0a5fc097c3d1bffeb155c046869745e0cf8a40694cde5dec6 |
| SRC-003 | modeller-agents reconnaissance | /mnt/data/modeller-agents-recon-05-08-2026.md | Primary target-repository reconnaissance | ff13383d3d884886bf84147df25fdc867da21d482f4be3cb86af1064887d56b1 |
| SRC-004 | Orchestration execution review | /mnt/data/orchestration-execution-review-2026-07-12.md | Observed orchestration failures and recovery | 848fe712130be65eecfc783c9b8e864399b5aa75d2b1d51e78b3f57a860c9315 |
| SRC-005 | Typed packs decisions | /mnt/data/typed-packs-open-decisions.md | Knowledge routing decisions and gates | c43bb2c88af297416f6760b96190a77b266e7a16c5acffef51ae36bf8b982e99 |
| SRC-006 | Memory classify runtime plan | /mnt/data/N2-C1-classify-runtime-plan.md | Memory/knowledge seam design | 9eb6a8788c4fd5acb1153e3c3d4abb2d858c9d077932ff078ae3f3a6e2347f7f |
| SRC-007 | Vault alignment plan | /mnt/data/vault-alignment-plan.md | Knowledge authority and routing constraints | b577378ca42009c0b9429fe875c544f29c647a962817462ac3f4f67763aa4b9b |
| SRC-008 | Vault optimisation plan | /mnt/data/vault-optimisation-plan(1).md | Knowledge metadata and doctor controls | df8d7d5b8ab671ddb81efba0e12510f1f21f397fd3167c755c24ecb098cf886b |
| SRC-009 | Knowledge handoff | /mnt/data/handoff.md | Current cross-repository governance state | 2a751b2aa8d5a1dcf62c2863b34dba34b064195b0a2c24fceca83b80350afde4 |
| SRC-010 | Baseline flow | /mnt/data/baseline-flow.md | Current intended routing flow | 7d62a7f8c258e1776ee3365456ccc734432a78194c326e730026c44b980fc40f |
| SRC-011 | Workflow skill | /mnt/data/SKILL-workflow.md | Gated implementation method | 13b90aeb20a8c54f31b35ea4bd7d95d51aacc76b1f5234cf613a182268b81f19 |
| SRC-012 | Orchestrate skill | /mnt/data/SKILL-orchestrate.md | Task classification, routing, model tiers | 12a4faaa5734cd3d3d1f634523bc7ab389b36f7dfde0984b9fe4fbe39f76abfb |
| SRC-013 | modeller-agents integration plan | /mnt/data/INTEGRATION_PLAN-modeller-agents.md | Historical target architecture and boundaries | 9bdce09457a8a86267b4e5594d36be93b792c8bdf89660eaf13987a203085b79 |

## External benchmark sources

| ID | Repository | URL | Use |
|---|---|---|---|
| WEB-001 | DeusData/codebase-memory-mcp | https://github.com/DeusData/codebase-memory-mcp | Persistent code knowledge graph; MCP code intelligence. |
| WEB-002 | MemPalace/mempalace | https://github.com/MemPalace/mempalace | Verbatim conversation storage and scoped semantic retrieval; benchmark claims require independent verification. |
| WEB-003 | letta-ai/letta | https://github.com/letta-ai/letta | Stateful agents with advanced memory. |
| WEB-004 | letta-ai/letta-code | https://github.com/letta-ai/letta-code | Agent identity, memory blocks, skills, hooks, permissions, self-improvement. |
| WEB-005 | garrytan/gstack | https://github.com/garrytan/gstack | Role-oriented workflow skills and workflow enforcement. |
| WEB-006 | BayramAnnakov/claude-reflect | https://github.com/BayramAnnakov/claude-reflect | Capture corrections, then promote through manual review. |
| WEB-007 | cobusgreyling/loop-engineering | https://github.com/cobusgreyling/loop-engineering | Loop budgets, state, circuit breakers, worktree isolation, maturity levels. |
| WEB-008 | bmad-code-org/BMAD-METHOD | https://github.com/bmad-code-org/BMAD-METHOD | Explicit decisions, specialized agents, structured workflows, preserved context. |
| WEB-009 | JuliusBrussee/caveman | https://github.com/JuliusBrussee/caveman | Response compression and compact delegation outputs. |
| WEB-010 | DietrichGebert/ponytail | https://github.com/DietrichGebert/ponytail | Reuse ladder and anti-overengineering rules. |
| WEB-011 | repowise-dev/repowise | https://github.com/repowise-dev/repowise | Codebase intelligence, health scoring, documentation and architecture context via MCP. |
| WEB-012 | coleam00/Archon | https://github.com/coleam00/Archon | Provider-oriented harness, knowledge, project and task management. |

## Source limitations

- The supplied recons are read-only reports and include validation results, but this package did not re-run commands against the live Windows repositories.
- Some governing documents include historical/superseded sections; current status banners and later evidence take precedence.
- External repository claims, performance numbers, stars, and benchmark results are not adopted as project evidence. Only architectural patterns are used.
- Licenses must be checked at the exact version/commit before code reuse.
- The user’s requested target enhancement list includes an empty bullet under “All roles”; no missing repository was inferred.

## Evidence-to-source mapping

| Finding range | Primary sources |
|---|---|
| CUR-001, CUR-007 | SRC-002, SRC-003, SRC-013 |
| CUR-002–CUR-006, CUR-008–CUR-010, CUR-019 | SRC-001, SRC-002, SRC-003 |
| CUR-011–CUR-013, CUR-020 | SRC-002 |
| CUR-014–CUR-015 | SRC-004 |
| CUR-016 | SRC-005–SRC-009 |
| CUR-017–CUR-018 | SRC-003, SRC-004, SRC-011–SRC-013 |

## Testudo and decision sources added in v2

| ID | Title | Path | Role | SHA-256 |
|---|---|---|---|---|
| SRC-014 | Testudo Product Requirements Document | /mnt/data/Product-requirements-document.md | Normative product requirements and acceptance criteria | cb765f6d051657234b2f306ea22c7db1716ff6b0cffb9cc72111ec0ad0994b9c |
| SRC-015 | Testudo Business Need and Design Brief | /mnt/data/Business-need-design-brief.md | Product vision, user journeys, one-agent model and MVP boundary | 9b5d8c77f170cb3824833ffe09ae9f511fa64a8b06c5fc4f3b59a67435a986d6 |
| SRC-016 | Confirmed user decisions — 2026-08-05 | user-decisions-2026-08-05.md | Final decision authority for audit v3 | 5d807f74974843d3c72ab6f2029ec9b00c2d6005c01aefb60bf3360d99636602 |

## v2 authority notes

- SRC-016 confirms all v1 decision recommendations and resolves DEC-012 and DEC-014.
- SRC-014 is normative where it uses MUST/MUST NOT/SHOULD/MAY.
- SRC-015 governs product experience and future Testudo architecture.
- The Testudo documents are working drafts for broader Product/Design/Architecture validation, but they are the requested product baseline for this audit.
- No new external web claims were needed for v2; the v1 benchmark remains pattern-level evidence only.

## v2 evidence mapping

| Finding range | Primary sources |
|---|---|
| CUR-021–CUR-024 | SRC-001, SRC-003, SRC-014, SRC-015 |
| CUR-025 | SRC-014–SRC-016 |
| CUR-026–CUR-029 | SRC-014, SRC-015 |
| CUR-030 | SRC-002, SRC-004, SRC-016 |

## Rendering-modelling source added in v3

| Source | Role | Authority / use |
|---|---|---|
| `implementation-plan.v3.json` | Seven-epic rendering-modelling implementation plan | Plan evidence for intended scope, decisions and residuals; not proof of delivery. Preserved unchanged under `evidence/`. |

### Extracted evidence

- 31 work items across Epic 0–6.
- 30 `aimsun-psp` items and one governed `modelling-knowledge` inbox write.
- Gaps for DuckDB/Parquet, screenshots, Excel and Testudo client work.
- Canonical DuckDB vertical slice plus path/trajectory/calibration/knowledge extensions.
- HTML, screenshot, Excel, report and GeoLibre artifact vision.
- Testudo write deferred by mission scope.
- Live Aimsun and GeoLibre UI proof recorded separately.
- Baseline-relative rollback.

### Interpretation

The supplied plan is not silently corrected. Residual wording such as E6-WI-03 naming v2 is recorded as a finding. Generic architecture is recommendation/inference, not delivered implementation evidence.
