# 01 — Current Approach

## 1. Scope and audit questions

This audit evaluates how DMW governance can be extended while `modeller-agents` becomes the simplified executable target. The questions are:

1. Which capabilities are real, reusable, partial, duplicated, obsolete, or missing?
2. Where do intended, documented, implemented, and observed behaviors diverge?
3. Which failures are logic failures versus seam failures?
4. Which controls must remain deterministic and which may be delegated to agents?
5. What is the smallest target structure that preserves authority, evidence, and recovery?

## 2. Current system boundary

```mermaid
flowchart LR
    U[User] --> D[DMW Decider prompt]
    D --> M[DMW Manager prompt]
    M --> WO[Work order / manual dispatch]
    WO --> W[Native or external Worker]
    W --> LR[Lane or Worker receipt]
    LR --> MA[modeller-agents runtime]
    MA --> G[Workflow check]
    G --> R[Reviewer / human gate]
    MA --> B[Backend registry]
    MA --> MEM[modeller-memory]
    MA --> K[modelling-knowledge references]
```

DMW is a declarative control plane. Its host supplies actual `Agent(...)` execution. `modeller-agents` is a Python routing and work-order runtime, but the supplied recon states it does not spawn and govern the full DMW role lifecycle. The missing seam is a typed executable bridge.

## 3. Intended, documented, implemented, observed

| Area | Intended | Documented | Implemented | Observed |
|---|---|---|---|---|
| Role lifecycle | Decider→Manager→Recon→Worker→Reviewer | Explicit roles and artifacts | Prompts, work orders, receipts | Manual relay required for some external roles |
| Authority | Roles are bounded | Strong prohibitions and ownership | Partial schema constants | Tool grants and runtime capabilities diverge |
| Completion | Gates determine completion | Workflow and E2E contracts | Validators and workflow checks | Workers can return before gate; orchestrator catches failures later |
| Resume | Mechanical checkpoint verification | Hash/schema/test policy | Helpers and schemas | No automatic coordinator |
| Consent | User approves implementation | Authorization receipts | Hash-bound gate helpers | Relayed instruction nearly became fabricated consent |
| Memory | Persistent, scoped, retrievable | Markdown/JSON descriptions conflict | JSON worker; separate memory subsystem | Verification strength not retained consistently |
| Knowledge | Accepted vault content is authoritative | Strong no-copy/no-write rules | Typed packs and parity controls | General activation remains governance-gated |
| Backend | Registered contract-conformant execution | `backend.json`, result contract | Registry and runner | Version drift and incomplete smoke/result validation |
| Catalog | Canonical source resolution | Catalog rules | Multiple physical and generated copies | Duplicate IDs and drift warnings |

## 4. Components and responsibilities

| Component | Current strength | Current weakness | Disposition |
|---|---|---|---|
| DMW role prompts | Clear authority and responsibility boundaries | Static host tool assumptions | **Reuse/Refactor** into canonical role policies |
| DMW schemas | Strong artifact ownership and approvals | Missing semantic constraints and template parity | **Extend** |
| DMW workflow YAML | Explicit lifecycle vocabulary | No executor | **Reuse** as migration input, not runtime authority |
| modeller routing | Mature repository/capability/knowledge routing | Draft-state and catalog complexity | **Reuse/Refactor** |
| modeller work orders | Bounded paths, artifacts, tests | No dispatch, role, tier, hard identity binding | **Extend** |
| modeller workflow/V-cycle | Human gates and invalidation concepts | Ingestion does not automatically re-gate | **Extend** |
| Backend registry | Correct ownership location | Contract drift and weak smoke evidence | **Extend** |
| Memory/knowledge seam | Correct authority separation | End-to-end proof incomplete | **Integrate later** |
| Testudo workflow skills | Strong gated process and reuse-first discipline | Product-specific detail and 15-step ceremony | **Adapt** into compact mission profiles |

## 5. Current lifecycle and decision flow

```mermaid
stateDiagram-v2
    [*] --> Intake
    Intake --> Recon
    Recon --> Plan
    Plan --> ReviewPlan
    ReviewPlan --> Authorization
    Authorization --> Dispatch
    Dispatch --> Integrate
    Integrate --> Verify
    Verify --> Delivery
    Delivery --> Learning
    Learning --> [*]

    ReviewPlan --> Plan: findings
    Integrate --> Dispatch: failed gate
    Verify --> Dispatch: failed assertion
    Authorization --> [*]: rejected
```

The lifecycle is conceptually sound. Failures occur at the seams: artifact creation versus tool grants, worker return versus gate authority, provider invocation versus provenance, checkpoint policy versus executable recovery, and memory claim versus verification method.

## 6. Strengths to preserve

- Explicit role authority and prohibitions.
- Immutable approval and hash-based receipts.
- Independent Reviewer concept.
- Human approval at material V-cycle gates.
- Worktree isolation and orchestrator-owned git.
- Source-boundary checks and knowledge authority separation.
- Content-addressed artifacts and material-change invalidation.
- Reuse-before-build, bounded write scope, and worker no-delegation rules.
- Deterministic doctor/readiness and testable contracts.

## 7. Root-cause clusters

### RC-A — Two sources of runtime truth

**Five Whys:** role behavior is inconsistent because runtime capabilities differ from prompts; they differ because plugin frontmatter and Python runtime are separate; they are separate because DMW and modeller-agents evolved independently; they evolved independently because one optimized governance and the other routing; no canonical contract compiler binds them.

**Corrective action:** one canonical contract model, generated projections, one runtime.

### RC-B — Claims are treated as evidence

Workers and reviewers can describe completion, but completion is not always mechanically reconstructed. The system needs evidence ingestion, not message trust.

### RC-C — Artifact proliferation without a dependency graph

Many receipts exist, but invalidation, latest-trusted discovery, and generated-artifact parity are not universally derived from dependencies.

### RC-D — Host coupling

Static host tool grants make external substitution and per-mission policy difficult. Provider selection must move into runtime contracts.

### RC-E — Memory conflates truth and recall

Durable memory needs verification method, freshness, and authority; accepted knowledge remains a separate governed outcome.

## 8. Detailed findings


### CUR-001 — Cross-repository contract versions are incompatible

- **Observation:** modeller-agents expects retired 1.0; aimsun-psp exposes 1.1; modeller-pipelines is current at 1.2.
- **Evidence:** Verified; sources are listed in the traceability matrix and source register.
- **Impact:** False compatibility, invalid result validation, blocked activation.
- **Root cause:** Contract ownership evolved independently without one compatibility matrix.
- **Confidence:** High
- **Recommendation:** Align on 1.2 and explicitly support only declared N-1 compatibility. (`REC-012`)

### CUR-002 — The DMW lifecycle is not executable end-to-end

- **Observation:** DMW defines MissionBrief→Manager→Recon→Worker→Reviewer; modeller-agents stops at work orders and handoffs.
- **Evidence:** Verified; sources are listed in the traceability matrix and source register.
- **Impact:** Manual relay, inconsistent role enforcement, no automatic re-gating.
- **Root cause:** Governance and runtime were developed as separate layers without a binding adapter.
- **Confidence:** High
- **Recommendation:** Implement a typed role bridge and provider-neutral dispatcher in modeller-agents. (`REC-001`)

### CUR-003 — Role responsibilities and tool grants conflict

- **Observation:** DMW Decider/Reviewer own artifacts they cannot write; external dispatch is declared but not injected.
- **Evidence:** Verified; sources are listed in the traceability matrix and source register.
- **Impact:** Roles may fabricate completion, fail unexpectedly, or require unsafe manual workarounds.
- **Root cause:** Static frontmatter is being used as both policy and runtime capability configuration.
- **Confidence:** High
- **Recommendation:** Move capability grants into validated per-mission dispatch contracts. (`REC-004`)

### CUR-004 — Checkpoint and resume are policy-only

- **Observation:** Schemas and helper functions exist, but no coordinator discovers, verifies, and resumes the latest checkpoint.
- **Evidence:** Verified; sources are listed in the traceability matrix and source register.
- **Impact:** Resume can trust stale or incomplete artifacts.
- **Root cause:** Checkpoint primitives were created without a lifecycle service.
- **Confidence:** High
- **Recommendation:** Build a disk-first checkpoint manager with mechanical verification receipts. (`REC-005`)

### CUR-005 — Templates and schemas are unsynchronized

- **Observation:** WorkerBrief, ManagerDelivery, and LearningDisposition templates fail their canonical schemas.
- **Evidence:** Verified; sources are listed in the traceability matrix and source register.
- **Impact:** Bootstrap creates invalid artifacts and weakens trust in all gates.
- **Root cause:** Templates and schemas have separate maintenance paths and no regression suite.
- **Confidence:** High
- **Recommendation:** Generate templates from schemas or test every template against its schema. (`REC-003`)

### CUR-006 — E2E success semantics are under-enforced

- **Observation:** A report can claim pass while required assertions are failed or not run.
- **Evidence:** Verified; sources are listed in the traceability matrix and source register.
- **Impact:** False-positive mission completion.
- **Root cause:** Requiredness is lost between verification contract and report.
- **Confidence:** High
- **Recommendation:** Bind each assertion by ID and reject pass unless all required assertions pass. (`REC-003`)

### CUR-007 — Backend result acceptance is under-validated

- **Observation:** Result path, status/exit consistency, run containment, write order, and smoke evidence are incomplete.
- **Evidence:** Verified; sources are listed in the traceability matrix and source register.
- **Impact:** Failed or malformed backend runs may be accepted.
- **Root cause:** Registry metadata is treated as proof of runtime conformance.
- **Confidence:** High
- **Recommendation:** Require exact run-dir result contract and digest-bound smoke receipts. (`REC-012`)

### CUR-008 — Catalog authority is duplicated

- **Observation:** DMW has duplicate physical skill copies; modeller-agents duplicates skills across plugin, docs, Python aliases, and YAML.
- **Evidence:** Verified; sources are listed in the traceability matrix and source register.
- **Impact:** Ambiguous routing and silent drift.
- **Root cause:** Human-maintained mirrors became quasi-authoritative.
- **Confidence:** High
- **Recommendation:** Use one canonical catalog and generate all host/plugin projections. (`REC-002`)

### CUR-009 — Agent identity and model-tier policy are prompt-level

- **Observation:** Identity mismatch is warning-only and model tier is absent from work-order schema.
- **Evidence:** Verified; sources are listed in the traceability matrix and source register.
- **Impact:** Receipt spoofing, wrong cost tier, inconsistent safety posture.
- **Root cause:** Identity and cost policy are advisory rather than contract fields.
- **Confidence:** High
- **Recommendation:** Make role, agent ID, provider, model tier, and policy digest mandatory and fail closed. (`REC-003`)

### CUR-010 — Memory format and ownership contracts conflict

- **Observation:** DMW documentation says Markdown records while implementation writes JSON; memory/knowledge promotion is not fully exercised.
- **Evidence:** Verified; sources are listed in the traceability matrix and source register.
- **Impact:** Broken interoperability and unclear source of truth.
- **Root cause:** Documentation, implementation, and vault governance evolved separately.
- **Confidence:** Medium
- **Recommendation:** Adopt typed JSON events internally and Markdown only as governed knowledge projection. (`REC-010`)

### CUR-011 — Implementation authorization can be confused with relayed consent

- **Observation:** The live-fire mission nearly produced a user-approved receipt from a relayed “proceed” instruction; a classifier blocked it.
- **Evidence:** Corroborated; sources are listed in the traceability matrix and source register.
- **Impact:** Fabricated consent and unauthorized mutation.
- **Root cause:** Decision capture does not distinguish ordinary decisions from non-delegable authorization.
- **Confidence:** High
- **Recommendation:** Require a fresh, explicit user answer bound to the exact authorization request digest. (`REC-007`)

### CUR-012 — External Reviewer/Worker substitution is not a first-class capability

- **Observation:** A manual Decider→main-thread relay was needed because Manager tool grants were static.
- **Evidence:** Corroborated; sources are listed in the traceability matrix and source register.
- **Impact:** Extra hops, provenance complexity, provider lock-in.
- **Root cause:** Provider selection is embedded in host tool configuration.
- **Confidence:** High
- **Recommendation:** Introduce provider adapters selected by mission policy with response validation. (`REC-004`)

### CUR-013 — Long-running review has no enforced decomposition fallback

- **Observation:** A review ran 50+ minutes and required manual kill/split; DMW has policy helpers but no coordinator.
- **Evidence:** Corroborated; sources are listed in the traceability matrix and source register.
- **Impact:** Stalled missions, wasted budget, unavailable verdicts.
- **Root cause:** Review duration policy is not connected to dispatcher control.
- **Confidence:** High
- **Recommendation:** Add historical-baseline timeout and split along declared sub-checks. (`REC-008`)

### CUR-014 — A worker gate is not the worker-result acceptance condition

- **Observation:** Workers can return edits before their own gate; integration catches failures later.
- **Evidence:** Corroborated; sources are listed in the traceability matrix and source register.
- **Impact:** Ungated work enters integration and increases recovery cost.
- **Root cause:** Completion messages are treated as evidence of completion.
- **Confidence:** High
- **Recommendation:** Treat worker output as raw evidence until orchestrator reruns the gate. (`REC-003`)

### CUR-015 — Generated artifact currency is not universally rechecked

- **Observation:** A generated vault index became stale after sibling edits.
- **Evidence:** Corroborated; sources are listed in the traceability matrix and source register.
- **Impact:** Derived artifacts can silently disagree with source state.
- **Root cause:** Parity checks are domain-specific rather than a general dependency rule.
- **Confidence:** High
- **Recommendation:** Invalidate and regenerate dependent artifacts after material changes. (`REC-005`)

### CUR-016 — Knowledge routing and memory promotion are intentionally incomplete

- **Observation:** Knowledge domains are governance-gated; the classify runtime/C1 path is documented but not proven end-to-end in supplied sources.
- **Evidence:** Verified; sources are listed in the traceability matrix and source register.
- **Impact:** Agents may use stale or unauthorized context if activation is rushed.
- **Root cause:** Correct authority separation exists, but remaining gates are not closed.
- **Confidence:** Medium
- **Recommendation:** Keep knowledge/memory as adapters with explicit availability and authority receipts. (`REC-010`)

### CUR-017 — The target repository is structurally mature but harder to read than necessary

- **Observation:** Large modules, duplicate package name, multiple catalog projections, many artifact types.
- **Evidence:** Verified; sources are listed in the traceability matrix and source register.
- **Impact:** Higher onboarding and change risk.
- **Root cause:** Successive features accumulated without a simplification pass.
- **Confidence:** Medium
- **Recommendation:** Consolidate around a small runtime kernel and generated projections. (`REC-001`)

### CUR-018 — Learning is documented but not connected mechanically

- **Observation:** Incidents, decisions, tests, catalogs, and learning dispositions are not linked in one ledger.
- **Evidence:** Verified; sources are listed in the traceability matrix and source register.
- **Impact:** Repeated failures and weak proof of institutional learning.
- **Root cause:** Retrospectives are narrative artifacts, not typed events.
- **Confidence:** Medium
- **Recommendation:** Create an improvement event ledger with closure criteria. (`REC-011`)

### CUR-019 — Persistence semantics for Manager and Reviewer conflict

- **Observation:** DMW sources disagree on persistent versus fresh identities.
- **Evidence:** Verified; sources are listed in the traceability matrix and source register.
- **Impact:** Resume and accountability behavior are undefined.
- **Root cause:** Identity continuity and artifact continuity were conflated.
- **Confidence:** High
- **Recommendation:** Use fresh or persistent providers interchangeably, but bind continuity to artifacts and policy digest. (`REC-006`)

### CUR-020 — Verification strength is not preserved as memory

- **Observation:** Semantic read-through and mechanical grep/byte-diff were both recorded as “confirmed.”
- **Evidence:** Corroborated; sources are listed in the traceability matrix and source register.
- **Impact:** Future agents over-trust weak claims and repeat defects.
- **Root cause:** Memory records lack method, scope, freshness, and strength metadata.
- **Confidence:** High
- **Recommendation:** Store verification method, evidence digest, scope, actor, and expiry with every durable claim. (`REC-006`)


## 9. Current review points and human controls

| Review point | Current owner | Defect | Required target behavior |
|---|---|---|---|
| Mission intent | Decider/user | Context continuity is provider-dependent | Artifact-bound intent plus user-visible decision record |
| Plan review | Reviewer | Final aggregation authority ambiguous | Reviewer verdict; Manager may revise but not self-accept |
| Implementation authorization | User | Relayed consent ambiguity | Fresh explicit answer to digest-bound request |
| Worker acceptance | Manager/orchestrator | Receipt claims can precede gate | Orchestrator reruns gate before acceptance |
| E2E acceptance | Reviewer | Required assertions under-enforced | Required assertion IDs and mechanical pass rule |
| Knowledge promotion | Vault board | Runtime proof incomplete | Candidate→inbox→review trace with authority context |

## 10. Current-state conclusion

The architecture is not failing because its governance ideas are weak. It is failing because too many governance concepts are descriptive rather than executable, and because two repositories duplicate parts of the orchestration model. The target must reduce representation count while increasing mechanical enforcement.

## 11. Testudo product context and new findings

Testudo changes the boundary of the orchestration initiative. The future product is a project-centred web cockpit in which the user sees one contextual AI agent, while simulation tools and specialised agents remain technical services behind controlled workflows. The product requirements make project context, permission inheritance, task state, evidence lineage, output classification and human approval normative product concerns rather than optional orchestration features.

```text
Testudo project workspace
  ├─ active context
  ├─ one visible AI conversation
  ├─ workflows and persistent tasks
  ├─ simulation runs and analytical datasets
  ├─ findings, evidence and publications
  └─ approvals and audit
           ↓
modeller-agents orchestration subsystem
  ├─ Decider policy
  ├─ Manager planning
  ├─ Recon evidence
  ├─ Worker execution
  ├─ Reviewer verification
  └─ gates, providers, checkpoints and receipts
```

### CUR-021 — The current orchestration surface is not yet a Testudo product subsystem

- **Observation:** DMW and `modeller-agents` are designed primarily as plugin/CLI orchestration surfaces. Testudo requires a stable product-facing API and task/event model.
- **Evidence:** SRC-001, SRC-003, SRC-014, SRC-015.
- **Impact:** Directly embedding plugin behaviour would expose host-specific mechanics and prevent a coherent web experience.
- **Root cause:** The runtime was designed before the Testudo product contract was stable.
- **Confidence:** High, Corroborated.
- **Recommendation:** REC-013; implement a Testudo orchestration gateway and keep plugin adapters behind it.

### CUR-022 — Internal role separation conflicts with the one-visible-agent experience unless hidden behind a gateway

- **Observation:** DMW defines several agent roles; Testudo explicitly requires one visible contextual AI agent.
- **Evidence:** SRC-001, SRC-014, SRC-015.
- **Impact:** Exposing role chats would fragment context and confuse authority.
- **Root cause:** Governance roles and user interaction personas were treated as the same design dimension.
- **Confidence:** High, Verified from documents.
- **Recommendation:** REC-014; internal roles remain separate policies and receipts, while the Interaction Gateway owns the single conversation.

### CUR-023 — The orchestration context is narrower than Testudo's active business context

- **Observation:** Testudo requires user, responsibilities, permissions, project, model, version, period, scenario, SimulationRun, view and selection in an inspectable context.
- **Evidence:** SRC-014, SRC-015.
- **Impact:** A valid technical mission can still operate on the wrong business run or unauthorized selection.
- **Root cause:** Mission context and product active context evolved independently.
- **Confidence:** High, Verified.
- **Recommendation:** REC-015; define one versioned Testudo `ActiveContextEnvelope` and bind every mission/approval to its digest.

### CUR-024 — Product and orchestration identities are currently easy to conflate

- **Observation:** Both systems use terms such as run, workflow, task and agent.
- **Evidence:** SRC-003, SRC-014, SRC-015.
- **Impact:** Results, retries, audit records and UI status can be attached to the wrong object.
- **Root cause:** No canonical cross-domain vocabulary has been ratified.
- **Confidence:** High, Inferred from schemas and product model.
- **Recommendation:** REC-016; distinguish `Project`, `Mission`, `Task`, `SimulationRun`, `DispatchAttempt` and `ResultSet`.

### CUR-025 — Storage ownership is not aligned to Testudo's future data volumes and authority model

- **Observation:** Audit v1 left the event store open and focused on mission-local persistence. Testudo adds user/project metadata and high-volume simulation datasets.
- **Evidence:** SRC-014, SRC-015, SRC-016.
- **Impact:** One generic database would either overload product transactions or weaken analytical performance and portability.
- **Root cause:** Persistence was considered from the orchestration repository only.
- **Confidence:** High, Confirmed decision.
- **Recommendation:** REC-017; PostgreSQL for product authority, DuckDB for simulation analytics, object/file storage for immutable artifacts.

### CUR-026 — Testudo approval responsibilities are not yet mapped to orchestration gates

- **Observation:** Testudo identifies client/Decider or Data/Model Owner, Transport Modeller/Technical Reviewer and Project Manager/Publication Approver. The runtime has generic user and reviewer gates.
- **Evidence:** SRC-014, SRC-015.
- **Impact:** The technically correct person may be unable to approve, or a user may approve outside their project responsibility.
- **Root cause:** Runtime authorization is role-generic rather than project-responsibility aware.
- **Confidence:** High, Reported/Verified.
- **Recommendation:** REC-019; use project-scoped responsibility claims in each `DecisionRequest`.

### CUR-027 — Task, partial-result and recovery semantics are not yet synchronised with the product

- **Observation:** Testudo requires persistent task states, partial results, reconnection, cancellation and targeted recovery.
- **Evidence:** SRC-014, SRC-015, SRC-004.
- **Impact:** A mission may recover internally while the product shows stale or misleading status.
- **Root cause:** Runtime event and product task state models have no formal bridge.
- **Confidence:** High, Corroborated.
- **Recommendation:** REC-018; define a versioned event projection and idempotent task-state reducer.

### CUR-028 — Findings and publications require a governed handoff beyond Manager delivery

- **Observation:** Runtime delivery currently ends at mission artifacts; Testudo requires technical findings, human review, publication versioning and client approval.
- **Evidence:** SRC-014, SRC-015.
- **Impact:** Successful technical execution does not automatically produce a valid business deliverable.
- **Root cause:** Orchestration completion and product publication were treated as the same endpoint.
- **Confidence:** High, Verified.
- **Recommendation:** REC-020; create explicit `FindingCandidate`, `ReviewedFinding` and `PublicationVersion` handoffs.

### CUR-029 — User permission inheritance must be enforced before provider dispatch, not only in Testudo UI

- **Observation:** Testudo requires AI and services to inherit the triggering user's authorization scope.
- **Evidence:** SRC-014, SRC-015.
- **Impact:** An agent provider could become a permission bypass.
- **Root cause:** Provider capabilities and product authorization were previously separate checks.
- **Confidence:** High, Verified.
- **Recommendation:** REC-015 and REC-019; the context gateway issues least-privilege capability grants from server-side authorization.

### CUR-030 — Product event sourcing is a future seam, while mission recovery needs an immediate independent ledger

- **Observation:** PostgreSQL is approved as a future event-store platform, but current live-fire recovery depends on files persisted before failures.
- **Evidence:** SRC-002, SRC-004, SRC-016.
- **Impact:** Prematurely replacing file checkpoints would weaken recovery; never bridging events would fragment audit.
- **Root cause:** Mission continuity and product audit have different consistency and lifecycle needs.
- **Confidence:** High, Confirmed/Inferred.
- **Recommendation:** REC-018; retain content-addressed mission evidence and project lifecycle events into PostgreSQL, then evaluate a unified event store later.

## 12. Revised root-cause synthesis

The primary issue is no longer only duplicated orchestration. It is a missing product/runtime seam. The corrective architecture must simultaneously:

1. consolidate DMW and `modeller-agents`;
2. prevent internal role complexity from leaking into the Testudo UX;
3. bind missions to an authorized project context;
4. separate product metadata from analytical datasets;
5. translate runtime evidence into tasks, findings and publications;
6. preserve mechanical recovery while enabling product-level audit.

## 13. Rendering-modelling and pipeline-control-plane findings

### CUR-031 — Pipelines are not first-class orchestration objects

**Observation:** Current work orders can describe repository tasks, but there is no canonical object representing a versioned pipeline definition, data contracts, stages, implementation repository, approvals, runtime entrypoint and supported artifacts.  
**Evidence:** The attached plan encodes epic grouping and dependencies inside free-text objectives because the implementation-plan schema has no epic or pipeline-lifecycle object.  
**Impact:** Pipeline architecture is reconstructed in mission prose; plan, build and use cannot share one machine-readable contract.  
**Root cause:** `modeller-agents` evolved from task routing rather than pipeline lifecycle management.  
**Confidence:** Verified / High.  
**Recommendation:** REC-021, REC-023.

### CUR-032 — Planning, implementing and using a pipeline are conflated

**Observation:** Existing skills and work orders do not encode whether the agent is designing a pipeline, changing its implementation, or operating an approved version.  
**Impact:** Operational requests can inherit repository-write capabilities; planning can be judged against runtime evidence; implementation can be confused with activation.  
**Root cause:** Capability selection is skill-centred rather than lifecycle-mode-centred.  
**Confidence:** Corroborated / High.  
**Recommendation:** REC-022, REC-030.

### CUR-033 — Canonical analytical data is not yet the mandatory rendering seam

**Observation:** The supplied plan migrates from raw/artifact-set rendering to canonical DuckDB, but existing rendering paths can still read independent source shapes.  
**Impact:** KPI values and quality semantics can diverge across HTML, Excel, reports, screenshots and GeoLibre.  
**Root cause:** Presentation capabilities preceded canonical-data enforcement.  
**Confidence:** Reported and plan-backed / High.  
**Recommendation:** REC-024, REC-025.

### CUR-034 — Derived artifact parity is not a universal gate

**Observation:** The plan introduces parity tests incrementally, but `modeller-agents` has no generic rule requiring declared presentation surfaces to trace to the same dataset, query and metric definition.  
**Impact:** Persuasive outputs may disagree without blocking acceptance or publication.  
**Root cause:** Artifact validation focuses on existence/schema rather than semantic equality.  
**Confidence:** Inferred / High.  
**Recommendation:** REC-026.

### CUR-035 — Source adapters have different runtime constraints

**Observation:** SQLite results, model geometry, APA paths and FZP trajectories require different runtimes, APIs, memory patterns and proof strategies. The plan moves APA API glue to `aimsun_psf`, while FZP processing is streaming/partitioned.  
**Impact:** Generic Worker briefs can assign the wrong skill, environment or evidence.  
**Root cause:** The capability catalog lacks data-adapter profiles.  
**Confidence:** Verified / High.  
**Recommendation:** REC-028, REC-029.

### CUR-036 — The capability catalog lacks key rendering/data skills

**Observation:** The plan records gaps for DuckDB/Parquet authoring, screenshot automation, Excel/report generation and Testudo publication-client work. Closest-wrapper substitution is repeatedly required.  
**Impact:** Capability receipts are weaker than the actual work and substitutions are difficult to govern.  
**Root cause:** Catalog coverage reflects earlier PSP work, not the full artifact lifecycle.  
**Confidence:** Verified / High.  
**Recommendation:** REC-029.

### CUR-037 — Live-model proof and implementation proof are not separated by contract

**Observation:** The plan repeatedly explains that code and contract tests are deliverable while Aimsun/aconsole execution requires a human environment.  
**Impact:** Reviews can overclaim live acceptance or undervalue completed implementation.  
**Root cause:** One completion status is used for source, contract, integration and live-pilot proof.  
**Confidence:** Verified / High.  
**Recommendation:** REC-031.

### CUR-038 — Testudo publication remains a payload-only seam

**Observation:** The plan intentionally keeps Testudo read-only and defers transactional PostgreSQL registration.  
**Impact:** A publish-ready payload can exist while project Task, SimulationRun registry and artifact catalog remain incomplete.  
**Root cause:** Cross-repository write authority was withheld by decision.  
**Confidence:** Verified / High.  
**Recommendation:** REC-027, REC-032.

### CUR-039 — GeoLibre is both artifact target and future UI dependency

**Observation:** The plan adds a DuckDB-backed package while preserving an older shard exporter and excluding the GeoLibre application repository.  
**Impact:** Export formats may coexist and package tests cannot prove desktop/UI behavior.  
**Root cause:** Data package and viewer implementation have different scopes.  
**Confidence:** Verified / High.  
**Recommendation:** REC-027 and a deprecation decision.

### CUR-040 — Large trajectories require specialized storage policy

**Observation:** FZP needs streaming, Parquet partitioning, indexing, decimation and retention.  
**Impact:** Memory exhaustion, slow runs, storage inflation and privacy exposure.  
**Root cause:** Generic artifacts do not distinguish bulk analytical datasets.  
**Confidence:** Verified / High.  
**Recommendation:** REC-024, REC-028.

### CUR-041 — The plan contains minor self-reference drift

**Observation:** E6-WI-03 requires a handoff reference to `implementation-plan.json v2` although the supplied plan is v3.  
**Impact:** Close-out documentation can cite the wrong plan version.  
**Root cause:** Surgical revisions preserved older wording outside the named finding set.  
**Confidence:** Verified / High.  
**Recommendation:** Add a plan-self-consistency validator; preserve the evidence snapshot unchanged.

### CUR-042 — The 31-item plan is not yet a reusable pipeline template

**Observation:** Seven epics provide detailed Aimsun/rendering work, but no generic mapping exists to reusable stages, roles, data contracts and Testudo interactions.  
**Impact:** Future demand or simulation pipelines would clone prose.  
**Root cause:** The implementation plan is a mission artifact, not a platform model.  
**Confidence:** Inferred / High.  
**Recommendation:** REC-021–REC-032.

## 14. Rendering-modelling root-cause synthesis

```text
Pipeline treated as repository tasks
  + presentation before canonical-data enforcement
  + incomplete capability catalog
  + product registration and licensed runtime outside mission scope
  = strong plan but no reusable pipeline control plane
```

The corrective action is not moving rendering code into `modeller-agents`. It is making pipeline definitions, modes, datasets, artifacts, gates and receipts first-class while keeping technical implementation in owning repositories.
