# 06 — Build Specification

## 1. Actors

User, Decider, Manager, Recon, Worker, Reviewer, Orchestrator Engine, Provider, Backend, Memory Adapter, Knowledge Adapter, Repository Owner, Knowledge Board, and Release Owner.

## 2. Use-case summary

| Use case | Primary actor | Success outcome |
|---|---|---|
| Start mission | User/Decider | Valid manifest, context receipts, unresolved choices surfaced |
| Plan mission | Manager | Versioned plan with bounded work, tests, gates, risks |
| Authorize implementation | User | Fresh digest-bound authorization receipt |
| Dispatch role | Orchestrator | Provider accepts least-privilege typed request |
| Integrate Worker result | Orchestrator | Identity/scope validated; gates rerun |
| Review plan/result | Reviewer | Independent assertion-level verdict |
| Resume | Orchestrator | Latest checkpoint mechanically verified |
| Retrieve context | Recon | Fresh, scoped, authority-tagged evidence |
| Promote learning | Human board | Improvement or knowledge accepted with full trace |
| Activate backend | Operations/owner | Current compatibility and smoke proof |

## 3. Requirement rules

`MUST` and `MUST NOT` are release-blocking. `SHOULD` requires a documented deviation. `MAY` is optional. Requirements are uniquely identified and traceable in `traceability-matrix.csv`.

## 4. Error handling

All boundary errors fail closed with a typed error code, human-readable remediation, affected IDs/digests, and whether retry, new evidence, user decision, provider substitution, or rollback is required. Provider text errors are never parsed as approval or pass without a typed receipt.

## 5. Requirements


### BR-001 — Single executable authority

- **ID:** BR-001
- **Title:** Single executable authority
- **Statement:** The solution MUST operate with `modeller-agents` as the sole mission state and transition authority.
- **Rationale:** Eliminates competing runtimes and drift.
- **Source:** CUR-002,CUR-017
- **Priority:** P0
- **Dependencies:** ADR-001
- **Acceptance criteria:** Only one component can advance state; DMW execution assets are generated projections.
- **Validation method:** Architecture and state tests.
- **Related risks:** RISK-002
- **Related architecture:** ADR-001,ADR-003
- **Related plan items:** PLAN-002,PLAN-008
- **Status:** Proposed

### BR-002 — Preserve DMW governance

- **ID:** BR-002
- **Title:** Preserve DMW governance
- **Statement:** The solution MUST preserve bounded roles, independent review, immutable approvals, checkpoint verification, and artifact ownership.
- **Rationale:** These are the strongest existing controls.
- **Source:** CUR-002,CUR-004
- **Priority:** P0
- **Dependencies:** BR-001
- **Acceptance criteria:** Role and lifecycle acceptance suite passes.
- **Validation method:** End-to-end mission tests.
- **Related risks:** RISK-004
- **Related architecture:** ADR-002,ADR-003
- **Related plan items:** PLAN-004,PLAN-025
- **Status:** Proposed

### BR-003 — Provider portability

- **ID:** BR-003
- **Title:** Provider portability
- **Statement:** The solution MUST support mission-selected native and external agent providers without changing shared role policies.
- **Rationale:** External substitution is a target enhancement and current failure.
- **Source:** CUR-003,CUR-012
- **Priority:** P0
- **Dependencies:** BR-001
- **Acceptance criteria:** Same Worker/Reviewer contract executes through two providers.
- **Validation method:** Provider contract tests.
- **Related risks:** RISK-011
- **Related architecture:** ADR-005
- **Related plan items:** PLAN-009–PLAN-011
- **Status:** Proposed

### BR-004 — Recoverable missions

- **ID:** BR-004
- **Title:** Recoverable missions
- **Statement:** The solution MUST recover from agent, stream, or quota failure without losing persisted trusted work.
- **Rationale:** Observed failures were recoverable only because artifacts were on disk.
- **Source:** CUR-004
- **Priority:** P0
- **Dependencies:** BR-001
- **Acceptance criteria:** Interruption at each state resumes after mechanical verification.
- **Validation method:** Interruption matrix.
- **Related risks:** RISK-007
- **Related architecture:** ADR-004,ADR-012
- **Related plan items:** PLAN-006,PLAN-007
- **Status:** Proposed

### BR-005 — Evidence-based completion

- **ID:** BR-005
- **Title:** Evidence-based completion
- **Statement:** The solution MUST treat messages and memory as claims, not completion authority.
- **Rationale:** Prevents false done states.
- **Source:** CUR-006,CUR-014,CUR-020
- **Priority:** P0
- **Dependencies:** BR-001
- **Acceptance criteria:** Every accepted transition has a mechanical GateReceipt.
- **Validation method:** Trace audit.
- **Related risks:** RISK-014
- **Related architecture:** ADR-003,ADR-006
- **Related plan items:** PLAN-014,PLAN-015
- **Status:** Proposed

### BR-006 — Lean readable structure

- **ID:** BR-006
- **Title:** Lean readable structure
- **Statement:** The solution SHOULD reduce canonical runtime concepts, duplicate catalogs, and hand-maintained projections.
- **Rationale:** Improves maintainability and onboarding.
- **Source:** CUR-008,CUR-017
- **Priority:** P1
- **Dependencies:** BR-001
- **Acceptance criteria:** One canonical catalog/model source; generated projections; documented module map.
- **Validation method:** Catalog parity and architecture review.
- **Related risks:** RISK-022
- **Related architecture:** ADR-002
- **Related plan items:** PLAN-005,PLAN-022,PLAN-029
- **Status:** Proposed

### FR-001 — Role bridge

- **ID:** FR-001
- **Title:** Role bridge
- **Statement:** The runtime MUST implement typed Decider, Manager, Recon, Worker, and Reviewer requests and receipts.
- **Rationale:** Makes the target lifecycle executable and auditable.
- **Source:** CUR-002
- **Priority:** P0
- **Dependencies:** BR-001,BR-002
- **Acceptance criteria:** A test demonstrates role bridge and a negative case fails closed.
- **Validation method:** Unit/integration/mission test.
- **Related risks:** RISK-004
- **Related architecture:** ADR-003
- **Related plan items:** PLAN-004,PLAN-008,PLAN-012
- **Status:** Proposed

### FR-002 — State advancement

- **ID:** FR-002
- **Title:** State advancement
- **Statement:** Only the orchestrator MUST advance mission state after validating receipts and gates.
- **Rationale:** Makes the target lifecycle executable and auditable.
- **Source:** CUR-014
- **Priority:** P0
- **Dependencies:** BR-001,BR-002
- **Acceptance criteria:** A test demonstrates state advancement and a negative case fails closed.
- **Validation method:** Unit/integration/mission test.
- **Related risks:** RISK-005
- **Related architecture:** ADR-003
- **Related plan items:** PLAN-008,PLAN-015
- **Status:** Proposed

### FR-003 — Mission-scoped capability grants

- **ID:** FR-003
- **Title:** Mission-scoped capability grants
- **Statement:** Dispatch requests MUST declare and validate tools, paths, commands, network, write, git, secrets, role, provider, and model tier.
- **Rationale:** Makes the target lifecycle executable and auditable.
- **Source:** CUR-003,CUR-009
- **Priority:** P0
- **Dependencies:** BR-001,BR-002
- **Acceptance criteria:** A test demonstrates mission-scoped capability grants and a negative case fails closed.
- **Validation method:** Unit/integration/mission test.
- **Related risks:** RISK-006
- **Related architecture:** ADR-005
- **Related plan items:** PLAN-009
- **Status:** Proposed

### FR-004 — Hard identity binding

- **ID:** FR-004
- **Title:** Hard identity binding
- **Statement:** A receipt whose role, agent, provider, or request digest differs from the request MUST be rejected.
- **Rationale:** Makes the target lifecycle executable and auditable.
- **Source:** CUR-009
- **Priority:** P0
- **Dependencies:** BR-001,BR-002
- **Acceptance criteria:** A test demonstrates hard identity binding and a negative case fails closed.
- **Validation method:** Unit/integration/mission test.
- **Related risks:** RISK-007
- **Related architecture:** ADR-005
- **Related plan items:** PLAN-009,PLAN-015
- **Status:** Proposed

### FR-005 — Surgical plan revision

- **ID:** FR-005
- **Title:** Surgical plan revision
- **Statement:** Manager plan revisions MUST identify touched findings and preserve unaffected content semantically and, where configured, byte-for-byte.
- **Rationale:** Makes the target lifecycle executable and auditable.
- **Source:** SRC-002
- **Priority:** P0
- **Dependencies:** BR-001,BR-002
- **Acceptance criteria:** A test demonstrates surgical plan revision and a negative case fails closed.
- **Validation method:** Unit/integration/mission test.
- **Related risks:** RISK-008
- **Related architecture:** ADR-003
- **Related plan items:** PLAN-012
- **Status:** Proposed

### FR-006 — Recon planning

- **ID:** FR-006
- **Title:** Recon planning
- **Statement:** Recon MUST create a bounded query plan and return evidence, uncertainty, and missing proof without implementation recommendations.
- **Rationale:** Makes the target lifecycle executable and auditable.
- **Source:** CUR-017
- **Priority:** P0
- **Dependencies:** BR-001,BR-002
- **Acceptance criteria:** A test demonstrates recon planning and a negative case fails closed.
- **Validation method:** Unit/integration/mission test.
- **Related risks:** RISK-009
- **Related architecture:** ADR-009
- **Related plan items:** PLAN-017
- **Status:** Proposed

### FR-007 — Worker reuse ladder

- **ID:** FR-007
- **Title:** Worker reuse ladder
- **Statement:** Worker MUST search for existing implementation, standard/platform capability, and installed dependency before building new code.
- **Rationale:** Makes the target lifecycle executable and auditable.
- **Source:** BMK-009
- **Priority:** P0
- **Dependencies:** BR-001,BR-002
- **Acceptance criteria:** A test demonstrates worker reuse ladder and a negative case fails closed.
- **Validation method:** Unit/integration/mission test.
- **Related risks:** RISK-010
- **Related architecture:** ADR-009
- **Related plan items:** PLAN-012,PLAN-017
- **Status:** Proposed

### FR-008 — Worker gate re-execution

- **ID:** FR-008
- **Title:** Worker gate re-execution
- **Statement:** The orchestrator MUST rerun declared gates after Worker receipt ingestion.
- **Rationale:** Makes the target lifecycle executable and auditable.
- **Source:** CUR-014
- **Priority:** P0
- **Dependencies:** BR-001,BR-002
- **Acceptance criteria:** A test demonstrates worker gate re-execution and a negative case fails closed.
- **Validation method:** Unit/integration/mission test.
- **Related risks:** RISK-011
- **Related architecture:** ADR-003
- **Related plan items:** PLAN-015
- **Status:** Proposed

### FR-009 — Independent review

- **ID:** FR-009
- **Title:** Independent review
- **Statement:** Final acceptance MUST require a Reviewer receipt from an identity independent of the Manager/Worker.
- **Rationale:** Makes the target lifecycle executable and auditable.
- **Source:** CUR-006
- **Priority:** P0
- **Dependencies:** BR-001,BR-002
- **Acceptance criteria:** A test demonstrates independent review and a negative case fails closed.
- **Validation method:** Unit/integration/mission test.
- **Related risks:** RISK-012
- **Related architecture:** ADR-003
- **Related plan items:** PLAN-014,PLAN-016
- **Status:** Proposed

### FR-010 — Review decomposition

- **ID:** FR-010
- **Title:** Review decomposition
- **Statement:** The runtime MUST cancel and decompose a stalled review along declared assertion groups.
- **Rationale:** Makes the target lifecycle executable and auditable.
- **Source:** CUR-013
- **Priority:** P0
- **Dependencies:** BR-001,BR-002
- **Acceptance criteria:** A test demonstrates review decomposition and a negative case fails closed.
- **Validation method:** Unit/integration/mission test.
- **Related risks:** RISK-013
- **Related architecture:** ADR-009
- **Related plan items:** PLAN-016
- **Status:** Proposed

### FR-011 — Artifact invalidation

- **ID:** FR-011
- **Title:** Artifact invalidation
- **Statement:** Changing an upstream artifact MUST invalidate dependent reviews, authorizations, checkpoints, and generated artifacts.
- **Rationale:** Makes the target lifecycle executable and auditable.
- **Source:** CUR-015
- **Priority:** P0
- **Dependencies:** BR-001,BR-002
- **Acceptance criteria:** A test demonstrates artifact invalidation and a negative case fails closed.
- **Validation method:** Unit/integration/mission test.
- **Related risks:** RISK-014
- **Related architecture:** ADR-004
- **Related plan items:** PLAN-006
- **Status:** Proposed

### FR-012 — Readiness plan

- **ID:** FR-012
- **Title:** Readiness plan
- **Statement:** Diagnostics SHOULD emit dependency-ordered remediation, not only blockers.
- **Rationale:** Makes the target lifecycle executable and auditable.
- **Source:** CUR-017
- **Priority:** P1
- **Dependencies:** BR-001,BR-002
- **Acceptance criteria:** A test demonstrates readiness plan and a negative case fails closed.
- **Validation method:** Unit/integration/mission test.
- **Related risks:** RISK-015
- **Related architecture:** ADR-010
- **Related plan items:** PLAN-024
- **Status:** Proposed

### FR-013 — Improvement closure

- **ID:** FR-013
- **Title:** Improvement closure
- **Statement:** An improvement MUST NOT be marked promoted until its incident, decision, contract change, regression test, and released version are linked.
- **Rationale:** Makes the target lifecycle executable and auditable.
- **Source:** CUR-018
- **Priority:** P1
- **Dependencies:** BR-001,BR-002
- **Acceptance criteria:** A test demonstrates improvement closure and a negative case fails closed.
- **Validation method:** Unit/integration/mission test.
- **Related risks:** RISK-016
- **Related architecture:** ADR-004
- **Related plan items:** PLAN-023
- **Status:** Proposed

### FR-014 — Generated compatibility package

- **ID:** FR-014
- **Title:** Generated compatibility package
- **Statement:** The build MUST generate a DMW-compatible plugin projection from canonical contracts.
- **Rationale:** Makes the target lifecycle executable and auditable.
- **Source:** CUR-008
- **Priority:** P1
- **Dependencies:** BR-001,BR-002
- **Acceptance criteria:** A test demonstrates generated compatibility package and a negative case fails closed.
- **Validation method:** Unit/integration/mission test.
- **Related risks:** RISK-017
- **Related architecture:** ADR-002
- **Related plan items:** PLAN-025
- **Status:** Proposed

### NFR-001 — Deterministic replay

- **ID:** NFR-001
- **Title:** Deterministic replay
- **Statement:** Given the same event/artifact set, state reconstruction MUST be deterministic.
- **Rationale:** Ensures operational quality of the runtime.
- **Source:** CUR-004,CUR-017
- **Priority:** P0
- **Dependencies:** FR-001
- **Acceptance criteria:** Event replay hash matches.
- **Validation method:** Automated non-functional test.
- **Related risks:** RISK-021
- **Related architecture:** ADR-004
- **Related plan items:** PLAN-006
- **Status:** Proposed

### NFR-002 — Context budget

- **ID:** NFR-002
- **Title:** Context budget
- **Statement:** Each role dispatch MUST enforce configured context and query budgets.
- **Rationale:** Ensures operational quality of the runtime.
- **Source:** CUR-004,CUR-017
- **Priority:** P1
- **Dependencies:** FR-001
- **Acceptance criteria:** Budget overrun fails or requires explicit escalation.
- **Validation method:** Automated non-functional test.
- **Related risks:** RISK-022
- **Related architecture:** ADR-009
- **Related plan items:** PLAN-017
- **Status:** Proposed

### NFR-003 — Cancellation

- **ID:** NFR-003
- **Title:** Cancellation
- **Statement:** Providers MUST expose cancellation or be wrapped with a process/session termination strategy.
- **Rationale:** Ensures operational quality of the runtime.
- **Source:** CUR-004,CUR-017
- **Priority:** P0
- **Dependencies:** FR-001
- **Acceptance criteria:** Stalled provider is stopped and receipt recorded.
- **Validation method:** Automated non-functional test.
- **Related risks:** RISK-023
- **Related architecture:** ADR-005
- **Related plan items:** PLAN-009,PLAN-016
- **Status:** Proposed

### NFR-004 — Performance

- **ID:** NFR-004
- **Title:** Performance
- **Statement:** Routine state validation and receipt ingestion SHOULD complete without model invocation.
- **Rationale:** Ensures operational quality of the runtime.
- **Source:** CUR-004,CUR-017
- **Priority:** P1
- **Dependencies:** FR-001
- **Acceptance criteria:** Deterministic operations are local and measured.
- **Validation method:** Automated non-functional test.
- **Related risks:** RISK-024
- **Related architecture:** ADR-003
- **Related plan items:** PLAN-008
- **Status:** Proposed

### NFR-005 — Portability

- **ID:** NFR-005
- **Title:** Portability
- **Statement:** Canonical contracts MUST be host-neutral and generated adapters MUST isolate host syntax.
- **Rationale:** Ensures operational quality of the runtime.
- **Source:** CUR-004,CUR-017
- **Priority:** P1
- **Dependencies:** FR-001
- **Acceptance criteria:** Two host/provider projections pass parity.
- **Validation method:** Automated non-functional test.
- **Related risks:** RISK-025
- **Related architecture:** ADR-002,ADR-005
- **Related plan items:** PLAN-005,PLAN-025
- **Status:** Proposed

### NFR-006 — Maintainability

- **ID:** NFR-006
- **Title:** Maintainability
- **Statement:** No canonical role, skill, schema, or capability ID MAY have two hand-maintained authoritative definitions.
- **Rationale:** Ensures operational quality of the runtime.
- **Source:** CUR-004,CUR-017
- **Priority:** P1
- **Dependencies:** FR-001
- **Acceptance criteria:** Duplicate-source test is green.
- **Validation method:** Automated non-functional test.
- **Related risks:** RISK-026
- **Related architecture:** ADR-002
- **Related plan items:** PLAN-022,PLAN-029
- **Status:** Proposed

### NFR-007 — Backward compatibility

- **ID:** NFR-007
- **Title:** Backward compatibility
- **Statement:** The `modeller` CLI SHOULD preserve supported commands or provide explicit deprecation adapters.
- **Rationale:** Ensures operational quality of the runtime.
- **Source:** CUR-004,CUR-017
- **Priority:** P1
- **Dependencies:** FR-001
- **Acceptance criteria:** Black-box compatibility suite passes.
- **Validation method:** Automated non-functional test.
- **Related risks:** RISK-027
- **Related architecture:** ADR-010
- **Related plan items:** PLAN-028,PLAN-029
- **Status:** Proposed

### NFR-008 — Availability

- **ID:** NFR-008
- **Title:** Availability
- **Statement:** A provider or retrieval outage MUST degrade explicitly without corrupting mission state.
- **Rationale:** Ensures operational quality of the runtime.
- **Source:** CUR-004,CUR-017
- **Priority:** P0
- **Dependencies:** FR-001
- **Acceptance criteria:** Outage tests yield blocked/degraded receipts.
- **Validation method:** Automated non-functional test.
- **Related risks:** RISK-028
- **Related architecture:** ADR-004,ADR-005
- **Related plan items:** PLAN-007,PLAN-009
- **Status:** Proposed

### DATA-001 — Event immutability

- **ID:** DATA-001
- **Title:** Event immutability
- **Statement:** Mission events MUST be append-only and uniquely identified; corrections MUST supersede rather than overwrite.
- **Rationale:** Protects traceability, reproducibility, and authority.
- **Source:** CUR-004,CUR-018
- **Priority:** P0
- **Dependencies:** BR-004,BR-005
- **Acceptance criteria:** Positive and tamper fixtures satisfy event immutability; invalid records fail closed.
- **Validation method:** Schema and storage tests.
- **Related risks:** RISK-007
- **Related architecture:** ADR-004
- **Related plan items:** PLAN-006
- **Status:** Proposed

### DATA-002 — Artifact content addressing

- **ID:** DATA-002
- **Title:** Artifact content addressing
- **Statement:** Every persisted artifact MUST carry a SHA-256 digest and canonical media/schema type.
- **Rationale:** Protects traceability, reproducibility, and authority.
- **Source:** CUR-004,CUR-015
- **Priority:** P0
- **Dependencies:** BR-004,BR-005
- **Acceptance criteria:** Positive and tamper fixtures satisfy artifact content addressing; invalid records fail closed.
- **Validation method:** Schema and storage tests.
- **Related risks:** RISK-008
- **Related architecture:** ADR-004
- **Related plan items:** PLAN-006
- **Status:** Proposed

### DATA-003 — Dependency edges

- **ID:** DATA-003
- **Title:** Dependency edges
- **Statement:** The ledger MUST record upstream/downstream artifact dependencies used for invalidation.
- **Rationale:** Protects traceability, reproducibility, and authority.
- **Source:** CUR-015
- **Priority:** P0
- **Dependencies:** BR-004,BR-005
- **Acceptance criteria:** Positive and tamper fixtures satisfy dependency edges; invalid records fail closed.
- **Validation method:** Schema and storage tests.
- **Related risks:** RISK-009
- **Related architecture:** ADR-004
- **Related plan items:** PLAN-006
- **Status:** Proposed

### DATA-004 — Verification metadata

- **ID:** DATA-004
- **Title:** Verification metadata
- **Statement:** Every durable claim MUST store method, evidence reference, scope, actor, timestamp, freshness, and strength.
- **Rationale:** Protects traceability, reproducibility, and authority.
- **Source:** CUR-020
- **Priority:** P0
- **Dependencies:** BR-004,BR-005
- **Acceptance criteria:** Positive and tamper fixtures satisfy verification metadata; invalid records fail closed.
- **Validation method:** Schema and storage tests.
- **Related risks:** RISK-010
- **Related architecture:** ADR-006
- **Related plan items:** PLAN-018
- **Status:** Proposed

### DATA-005 — Authority context

- **ID:** DATA-005
- **Title:** Authority context
- **Statement:** Memory and knowledge retrieval records MUST identify authority source, accepted status, source digest, and retrieval time.
- **Rationale:** Protects traceability, reproducibility, and authority.
- **Source:** CUR-016
- **Priority:** P1
- **Dependencies:** BR-004,BR-005
- **Acceptance criteria:** Positive and tamper fixtures satisfy authority context; invalid records fail closed.
- **Validation method:** Schema and storage tests.
- **Related risks:** RISK-011
- **Related architecture:** ADR-008
- **Related plan items:** PLAN-019
- **Status:** Proposed

### DATA-006 — Relative artifact paths

- **ID:** DATA-006
- **Title:** Relative artifact paths
- **Statement:** Backend and role receipts MUST use run-relative artifact paths; absolute paths MUST be rejected except declared host roots.
- **Rationale:** Protects traceability, reproducibility, and authority.
- **Source:** CUR-007
- **Priority:** P0
- **Dependencies:** BR-004,BR-005
- **Acceptance criteria:** Positive and tamper fixtures satisfy relative artifact paths; invalid records fail closed.
- **Validation method:** Schema and storage tests.
- **Related risks:** RISK-012
- **Related architecture:** ADR-010
- **Related plan items:** PLAN-020
- **Status:** Proposed

### DATA-007 — Schema versioning

- **ID:** DATA-007
- **Title:** Schema versioning
- **Statement:** Every contract-bearing artifact MUST declare a schema/contract version.
- **Rationale:** Protects traceability, reproducibility, and authority.
- **Source:** CUR-001,CUR-005
- **Priority:** P0
- **Dependencies:** BR-004,BR-005
- **Acceptance criteria:** Positive and tamper fixtures satisfy schema versioning; invalid records fail closed.
- **Validation method:** Schema and storage tests.
- **Related risks:** RISK-013
- **Related architecture:** ADR-010
- **Related plan items:** PLAN-003,PLAN-004
- **Status:** Proposed

### DATA-008 — Sensitive fields

- **ID:** DATA-008
- **Title:** Sensitive fields
- **Statement:** Secrets and restricted evidence MUST NOT be persisted in general mission artifacts; references MUST be redacted or vaulted.
- **Rationale:** Protects traceability, reproducibility, and authority.
- **Source:** CUR-016
- **Priority:** P1
- **Dependencies:** BR-004,BR-005
- **Acceptance criteria:** Positive and tamper fixtures satisfy sensitive fields; invalid records fail closed.
- **Validation method:** Schema and storage tests.
- **Related risks:** RISK-014
- **Related architecture:** ADR-008
- **Related plan items:** PLAN-019
- **Status:** Proposed

### INT-001 — Native agent provider

- **ID:** INT-001
- **Title:** Native agent provider
- **Statement:** The runtime MUST integrate the host-native agent mechanism through the Provider interface.
- **Rationale:** Defines clean seams with external systems.
- **Source:** CUR-002
- **Priority:** P0
- **Dependencies:** FR-001
- **Acceptance criteria:** Integration fixture and failure-mode test demonstrate native agent provider.
- **Validation method:** Contract/integration tests.
- **Related risks:** RISK-009
- **Related architecture:** ADR-005
- **Related plan items:** PLAN-010
- **Status:** Proposed

### INT-002 — External agent provider

- **ID:** INT-002
- **Title:** External agent provider
- **Statement:** The runtime MUST integrate at least one external Worker/Reviewer provider through the same interface.
- **Rationale:** Defines clean seams with external systems.
- **Source:** CUR-012
- **Priority:** P0
- **Dependencies:** FR-001
- **Acceptance criteria:** Integration fixture and failure-mode test demonstrate external agent provider.
- **Validation method:** Contract/integration tests.
- **Related risks:** RISK-010
- **Related architecture:** ADR-005
- **Related plan items:** PLAN-011
- **Status:** Proposed

### INT-003 — Manual relay fallback

- **ID:** INT-003
- **Title:** Manual relay fallback
- **Statement:** A manual relay MAY be supported only as an explicit provider with provenance, no silent fallback, and no authority upgrade.
- **Rationale:** Defines clean seams with external systems.
- **Source:** CUR-012
- **Priority:** P1
- **Dependencies:** FR-001
- **Acceptance criteria:** Integration fixture and failure-mode test demonstrate manual relay fallback.
- **Validation method:** Contract/integration tests.
- **Related risks:** RISK-011
- **Related architecture:** ADR-005
- **Related plan items:** PLAN-009
- **Status:** Proposed

### INT-004 — Code graph provider

- **ID:** INT-004
- **Title:** Code graph provider
- **Statement:** Recon MAY query a code graph provider and MUST validate repository identity and freshness before use.
- **Rationale:** Defines clean seams with external systems.
- **Source:** BMK-001
- **Priority:** P1
- **Dependencies:** FR-001
- **Acceptance criteria:** Integration fixture and failure-mode test demonstrate code graph provider.
- **Validation method:** Contract/integration tests.
- **Related risks:** RISK-012
- **Related architecture:** ADR-009
- **Related plan items:** PLAN-017
- **Status:** Proposed

### INT-005 — Source fallback

- **ID:** INT-005
- **Title:** Source fallback
- **Statement:** Recon MUST retain direct source read/search fallback when indexes are missing or stale.
- **Rationale:** Defines clean seams with external systems.
- **Source:** BMK-001
- **Priority:** P1
- **Dependencies:** FR-001
- **Acceptance criteria:** Integration fixture and failure-mode test demonstrate source fallback.
- **Validation method:** Contract/integration tests.
- **Related risks:** RISK-013
- **Related architecture:** ADR-009
- **Related plan items:** PLAN-017
- **Status:** Proposed

### INT-006 — Memory adapter

- **ID:** INT-006
- **Title:** Memory adapter
- **Statement:** The runtime SHOULD query `modeller-memory` through a typed adapter and MUST treat returned items as non-authoritative claims unless promoted.
- **Rationale:** Defines clean seams with external systems.
- **Source:** CUR-010,CUR-016
- **Priority:** P1
- **Dependencies:** FR-001
- **Acceptance criteria:** Integration fixture and failure-mode test demonstrate memory adapter.
- **Validation method:** Contract/integration tests.
- **Related risks:** RISK-014
- **Related architecture:** ADR-008
- **Related plan items:** PLAN-019
- **Status:** Proposed

### INT-007 — Knowledge adapter

- **ID:** INT-007
- **Title:** Knowledge adapter
- **Statement:** The runtime SHOULD retrieve accepted knowledge by stable ID and vault digest without copying note bodies into canonical packs.
- **Rationale:** Defines clean seams with external systems.
- **Source:** CUR-016
- **Priority:** P1
- **Dependencies:** FR-001
- **Acceptance criteria:** Integration fixture and failure-mode test demonstrate knowledge adapter.
- **Validation method:** Contract/integration tests.
- **Related risks:** RISK-015
- **Related architecture:** ADR-008
- **Related plan items:** PLAN-019
- **Status:** Proposed

### INT-008 — Backend registry

- **ID:** INT-008
- **Title:** Backend registry
- **Statement:** The runtime MUST validate backend descriptor, contract lock, runner output, and smoke receipt before activation.
- **Rationale:** Defines clean seams with external systems.
- **Source:** CUR-001,CUR-007
- **Priority:** P0
- **Dependencies:** FR-001
- **Acceptance criteria:** Integration fixture and failure-mode test demonstrate backend registry.
- **Validation method:** Contract/integration tests.
- **Related risks:** RISK-016
- **Related architecture:** ADR-010
- **Related plan items:** PLAN-020,PLAN-021
- **Status:** Proposed

### INT-009 — Generated DMW adapter

- **ID:** INT-009
- **Title:** Generated DMW adapter
- **Statement:** The contract generator MUST emit DMW-compatible role, manifest, schema, and skill projection files.
- **Rationale:** Defines clean seams with external systems.
- **Source:** CUR-008
- **Priority:** P0
- **Dependencies:** FR-001
- **Acceptance criteria:** Integration fixture and failure-mode test demonstrate generated dmw adapter.
- **Validation method:** Contract/integration tests.
- **Related risks:** RISK-017
- **Related architecture:** ADR-002
- **Related plan items:** PLAN-025
- **Status:** Proposed

### INT-010 — Improvement export

- **ID:** INT-010
- **Title:** Improvement export
- **Statement:** The runtime SHOULD export reviewed improvement events to repository documentation or governed knowledge intake without direct promotion.
- **Rationale:** Defines clean seams with external systems.
- **Source:** CUR-018
- **Priority:** P1
- **Dependencies:** FR-001
- **Acceptance criteria:** Integration fixture and failure-mode test demonstrate improvement export.
- **Validation method:** Contract/integration tests.
- **Related risks:** RISK-018
- **Related architecture:** ADR-008
- **Related plan items:** PLAN-023
- **Status:** Proposed

### SEC-001 — Least privilege

- **ID:** SEC-001
- **Title:** Least privilege
- **Statement:** Every dispatch MUST be denied unless requested capabilities are a subset of provider and mission policy grants.
- **Rationale:** Prevents unauthorized action, spoofing, and authority escalation.
- **Source:** CUR-003
- **Priority:** P0
- **Dependencies:** BR-003,BR-005
- **Acceptance criteria:** Adversarial tests prove least privilege fails closed when violated.
- **Validation method:** Security tests and review.
- **Related risks:** RISK-011
- **Related architecture:** ADR-005
- **Related plan items:** PLAN-009
- **Status:** Proposed

### SEC-002 — No implicit git

- **ID:** SEC-002
- **Title:** No implicit git
- **Statement:** Worker and Recon roles MUST NOT perform git mutation unless a distinct user-authorized profile explicitly permits it.
- **Rationale:** Prevents unauthorized action, spoofing, and authority escalation.
- **Source:** SRC-004,SRC-011
- **Priority:** P0
- **Dependencies:** BR-003,BR-005
- **Acceptance criteria:** Adversarial tests prove no implicit git fails closed when violated.
- **Validation method:** Security tests and review.
- **Related risks:** RISK-012
- **Related architecture:** ADR-003
- **Related plan items:** PLAN-012
- **Status:** Proposed

### SEC-003 — Path containment

- **ID:** SEC-003
- **Title:** Path containment
- **Statement:** Writes and returned artifacts MUST remain within declared roots and allowed paths.
- **Rationale:** Prevents unauthorized action, spoofing, and authority escalation.
- **Source:** CUR-007,CUR-009
- **Priority:** P0
- **Dependencies:** BR-003,BR-005
- **Acceptance criteria:** Adversarial tests prove path containment fails closed when violated.
- **Validation method:** Security tests and review.
- **Related risks:** RISK-013
- **Related architecture:** ADR-005
- **Related plan items:** PLAN-009,PLAN-020
- **Status:** Proposed

### SEC-004 — Consent authenticity

- **ID:** SEC-004
- **Title:** Consent authenticity
- **Statement:** Implementation authorization MUST reject agent-authored, relayed, stale, mismatched, or reused user receipts.
- **Rationale:** Prevents unauthorized action, spoofing, and authority escalation.
- **Source:** CUR-011
- **Priority:** P0
- **Dependencies:** BR-003,BR-005
- **Acceptance criteria:** Adversarial tests prove consent authenticity fails closed when violated.
- **Validation method:** Security tests and review.
- **Related risks:** RISK-014
- **Related architecture:** ADR-011
- **Related plan items:** PLAN-013
- **Status:** Proposed

### SEC-005 — Independent reviewer

- **ID:** SEC-005
- **Title:** Independent reviewer
- **Statement:** Reviewer identity and provider session MUST be independent of implementation identities for final acceptance.
- **Rationale:** Prevents unauthorized action, spoofing, and authority escalation.
- **Source:** CUR-006
- **Priority:** P0
- **Dependencies:** BR-003,BR-005
- **Acceptance criteria:** Adversarial tests prove independent reviewer fails closed when violated.
- **Validation method:** Security tests and review.
- **Related risks:** RISK-015
- **Related architecture:** ADR-003
- **Related plan items:** PLAN-014
- **Status:** Proposed

### SEC-006 — No authority inflation

- **ID:** SEC-006
- **Title:** No authority inflation
- **Statement:** Memory, Recon, and external provider outputs MUST NOT be promoted to accepted knowledge or user approval by format conversion alone.
- **Rationale:** Prevents unauthorized action, spoofing, and authority escalation.
- **Source:** CUR-010,CUR-016
- **Priority:** P0
- **Dependencies:** BR-003,BR-005
- **Acceptance criteria:** Adversarial tests prove no authority inflation fails closed when violated.
- **Validation method:** Security tests and review.
- **Related risks:** RISK-016
- **Related architecture:** ADR-008,ADR-011
- **Related plan items:** PLAN-019,PLAN-023
- **Status:** Proposed

### SEC-007 — Secret handling

- **ID:** SEC-007
- **Title:** Secret handling
- **Statement:** Provider requests MUST declare secret scopes and logs MUST redact secret values.
- **Rationale:** Prevents unauthorized action, spoofing, and authority escalation.
- **Source:** CUR-003
- **Priority:** P0
- **Dependencies:** BR-003,BR-005
- **Acceptance criteria:** Adversarial tests prove secret handling fails closed when violated.
- **Validation method:** Security tests and review.
- **Related risks:** RISK-017
- **Related architecture:** ADR-005
- **Related plan items:** PLAN-009
- **Status:** Proposed

### SEC-008 — Supply-chain evidence

- **ID:** SEC-008
- **Title:** Supply-chain evidence
- **Statement:** Active external capabilities MUST include source version/digest, license, schema, and smoke evidence.
- **Rationale:** Prevents unauthorized action, spoofing, and authority escalation.
- **Source:** CUR-007,CUR-008
- **Priority:** P0
- **Dependencies:** BR-003,BR-005
- **Acceptance criteria:** Adversarial tests prove supply-chain evidence fails closed when violated.
- **Validation method:** Security tests and review.
- **Related risks:** RISK-018
- **Related architecture:** ADR-010
- **Related plan items:** PLAN-021,PLAN-022
- **Status:** Proposed

### OBS-001 — State transition log

- **ID:** OBS-001
- **Title:** State transition log
- **Statement:** Every attempted and successful transition MUST emit a structured audit event.
- **Rationale:** Makes operation explainable and reviewable.
- **Source:** CUR-002
- **Priority:** P0
- **Dependencies:** DATA-001
- **Acceptance criteria:** An audit query reconstructs state transition log from persisted records.
- **Validation method:** Observability integration test.
- **Related risks:** RISK-016
- **Related architecture:** ADR-004
- **Related plan items:** PLAN-006,PLAN-008
- **Status:** Proposed

### OBS-002 — Dispatch telemetry

- **ID:** OBS-002
- **Title:** Dispatch telemetry
- **Statement:** The runtime MUST record provider, role, model tier, start/end, status, timeout, cancellation, and retry/decomposition data.
- **Rationale:** Makes operation explainable and reviewable.
- **Source:** CUR-012,CUR-013
- **Priority:** P0
- **Dependencies:** DATA-001
- **Acceptance criteria:** An audit query reconstructs dispatch telemetry from persisted records.
- **Validation method:** Observability integration test.
- **Related risks:** RISK-017
- **Related architecture:** ADR-005
- **Related plan items:** PLAN-009,PLAN-016
- **Status:** Proposed

### OBS-003 — Context telemetry

- **ID:** OBS-003
- **Title:** Context telemetry
- **Statement:** Every context load SHOULD record source, query, selected items, digest, authority, budget, and token estimate.
- **Rationale:** Makes operation explainable and reviewable.
- **Source:** CUR-016,CUR-020
- **Priority:** P1
- **Dependencies:** DATA-001
- **Acceptance criteria:** An audit query reconstructs context telemetry from persisted records.
- **Validation method:** Observability integration test.
- **Related risks:** RISK-018
- **Related architecture:** ADR-006,ADR-009
- **Related plan items:** PLAN-017,PLAN-018
- **Status:** Proposed

### OBS-004 — Gate evidence

- **ID:** OBS-004
- **Title:** Gate evidence
- **Statement:** Every gate MUST record command/assertion IDs, exit status, output/evidence digest, and requiredness.
- **Rationale:** Makes operation explainable and reviewable.
- **Source:** CUR-006,CUR-014
- **Priority:** P0
- **Dependencies:** DATA-001
- **Acceptance criteria:** An audit query reconstructs gate evidence from persisted records.
- **Validation method:** Observability integration test.
- **Related risks:** RISK-019
- **Related architecture:** ADR-006
- **Related plan items:** PLAN-014,PLAN-015
- **Status:** Proposed

### OBS-005 — Invalidation events

- **ID:** OBS-005
- **Title:** Invalidation events
- **Statement:** The ledger MUST expose why and when an artifact or approval became stale.
- **Rationale:** Makes operation explainable and reviewable.
- **Source:** CUR-015
- **Priority:** P0
- **Dependencies:** DATA-001
- **Acceptance criteria:** An audit query reconstructs invalidation events from persisted records.
- **Validation method:** Observability integration test.
- **Related risks:** RISK-020
- **Related architecture:** ADR-004
- **Related plan items:** PLAN-006
- **Status:** Proposed

### OBS-006 — Readiness status

- **ID:** OBS-006
- **Title:** Readiness status
- **Statement:** Diagnostics MUST distinguish unavailable, stale, incompatible, unproven, active, and deprecated capabilities.
- **Rationale:** Makes operation explainable and reviewable.
- **Source:** CUR-001,CUR-007
- **Priority:** P1
- **Dependencies:** DATA-001
- **Acceptance criteria:** An audit query reconstructs readiness status from persisted records.
- **Validation method:** Observability integration test.
- **Related risks:** RISK-021
- **Related architecture:** ADR-010
- **Related plan items:** PLAN-021,PLAN-024
- **Status:** Proposed

### OBS-007 — KPI reporting

- **ID:** OBS-007
- **Title:** KPI reporting
- **Statement:** Pilot reports MUST measure context, dispatch count, manual hops, retries, recovery time, gate failures, and false-pass prevention.
- **Rationale:** Makes operation explainable and reviewable.
- **Source:** BR-006
- **Priority:** P1
- **Dependencies:** DATA-001
- **Acceptance criteria:** An audit query reconstructs kpi reporting from persisted records.
- **Validation method:** Observability integration test.
- **Related risks:** RISK-022
- **Related architecture:** ADR-003
- **Related plan items:** PLAN-026,PLAN-027
- **Status:** Proposed

### OBS-008 — Improvement trace

- **ID:** OBS-008
- **Title:** Improvement trace
- **Statement:** The system MUST report open and closed improvement chains and missing closure links.
- **Rationale:** Makes operation explainable and reviewable.
- **Source:** CUR-018
- **Priority:** P1
- **Dependencies:** DATA-001
- **Acceptance criteria:** An audit query reconstructs improvement trace from persisted records.
- **Validation method:** Observability integration test.
- **Related risks:** RISK-023
- **Related architecture:** ADR-004
- **Related plan items:** PLAN-023
- **Status:** Proposed

### HITL-001 — Mission ambiguity

- **ID:** HITL-001
- **Title:** Mission ambiguity
- **Statement:** The Decider MUST present unresolved material choices to the user before authorization.
- **Rationale:** Specifies exact human authority and review behavior.
- **Source:** SRC-002
- **Priority:** P1
- **Dependencies:** SEC-004
- **Acceptance criteria:** The named human action is required and its absence blocks the transition.
- **Validation method:** Workflow/adversarial tests.
- **Related risks:** RISK-013
- **Related architecture:** ADR-007
- **Related plan items:** PLAN-012
- **Status:** Proposed

### HITL-002 — Implementation authorization

- **ID:** HITL-002
- **Title:** Implementation authorization
- **Statement:** Only a fresh explicit user answer MAY satisfy the implementation authorization gate.
- **Rationale:** Specifies exact human authority and review behavior.
- **Source:** CUR-011
- **Priority:** P0
- **Dependencies:** SEC-004
- **Acceptance criteria:** The named human action is required and its absence blocks the transition.
- **Validation method:** Workflow/adversarial tests.
- **Related risks:** RISK-014
- **Related architecture:** ADR-011
- **Related plan items:** PLAN-013
- **Status:** Proposed

### HITL-003 — Plan acceptance

- **ID:** HITL-003
- **Title:** Plan acceptance
- **Statement:** An independent Reviewer MUST approve or conditionally approve the plan before implementation authorization.
- **Rationale:** Specifies exact human authority and review behavior.
- **Source:** CUR-006
- **Priority:** P0
- **Dependencies:** SEC-004
- **Acceptance criteria:** The named human action is required and its absence blocks the transition.
- **Validation method:** Workflow/adversarial tests.
- **Related risks:** RISK-015
- **Related architecture:** ADR-003
- **Related plan items:** PLAN-014
- **Status:** Proposed

### HITL-004 — Mutation boundary

- **ID:** HITL-004
- **Title:** Mutation boundary
- **Statement:** High-risk writes, destructive actions, secrets, production changes, and git publication MUST require configured human approval.
- **Rationale:** Specifies exact human authority and review behavior.
- **Source:** SRC-011
- **Priority:** P0
- **Dependencies:** SEC-004
- **Acceptance criteria:** The named human action is required and its absence blocks the transition.
- **Validation method:** Workflow/adversarial tests.
- **Related risks:** RISK-016
- **Related architecture:** ADR-003,ADR-011
- **Related plan items:** PLAN-012,PLAN-013
- **Status:** Proposed

### HITL-005 — Review conflict

- **ID:** HITL-005
- **Title:** Review conflict
- **Statement:** Conflicting Reviewer results MUST be escalated to a named human owner or a new independent review, never averaged silently.
- **Rationale:** Specifies exact human authority and review behavior.
- **Source:** CUR-013
- **Priority:** P0
- **Dependencies:** SEC-004
- **Acceptance criteria:** The named human action is required and its absence blocks the transition.
- **Validation method:** Workflow/adversarial tests.
- **Related risks:** RISK-017
- **Related architecture:** ADR-003
- **Related plan items:** PLAN-016
- **Status:** Proposed

### HITL-006 — Knowledge promotion

- **ID:** HITL-006
- **Title:** Knowledge promotion
- **Statement:** A human/antagonist board MUST approve durable knowledge promotion; the runtime MAY only draft candidates.
- **Rationale:** Specifies exact human authority and review behavior.
- **Source:** CUR-016
- **Priority:** P0
- **Dependencies:** SEC-004
- **Acceptance criteria:** The named human action is required and its absence blocks the transition.
- **Validation method:** Workflow/adversarial tests.
- **Related risks:** RISK-018
- **Related architecture:** ADR-008
- **Related plan items:** PLAN-019
- **Status:** Proposed

### HITL-007 — Provider substitution

- **ID:** HITL-007
- **Title:** Provider substitution
- **Statement:** A provider change that alters capabilities, data location, or cost tier SHOULD require user/owner approval.
- **Rationale:** Specifies exact human authority and review behavior.
- **Source:** CUR-012
- **Priority:** P1
- **Dependencies:** SEC-004
- **Acceptance criteria:** The named human action is required and its absence blocks the transition.
- **Validation method:** Workflow/adversarial tests.
- **Related risks:** RISK-019
- **Related architecture:** ADR-005
- **Related plan items:** PLAN-009
- **Status:** Proposed

### HITL-008 — Stop control

- **ID:** HITL-008
- **Title:** Stop control
- **Statement:** The user MUST be able to stop or cancel active provider work; the runtime MUST persist a cancellation receipt.
- **Rationale:** Specifies exact human authority and review behavior.
- **Source:** CUR-013
- **Priority:** P1
- **Dependencies:** SEC-004
- **Acceptance criteria:** The named human action is required and its absence blocks the transition.
- **Validation method:** Workflow/adversarial tests.
- **Related risks:** RISK-020
- **Related architecture:** ADR-005
- **Related plan items:** PLAN-009,PLAN-016
- **Status:** Proposed

### HITL-009 — Rollback approval

- **ID:** HITL-009
- **Title:** Rollback approval
- **Statement:** Release cutover and rollback MUST be explicitly approved by the release owner.
- **Rationale:** Specifies exact human authority and review behavior.
- **Source:** BR-004
- **Priority:** P1
- **Dependencies:** SEC-004
- **Acceptance criteria:** The named human action is required and its absence blocks the transition.
- **Validation method:** Workflow/adversarial tests.
- **Related risks:** RISK-021
- **Related architecture:** ADR-004
- **Related plan items:** PLAN-028,PLAN-030
- **Status:** Proposed

### HITL-010 — Override audit

- **ID:** HITL-010
- **Title:** Override audit
- **Statement:** Any human override MUST record actor, reason, scope, expiry, and affected evidence; it MUST NOT fabricate a passing gate.
- **Rationale:** Specifies exact human authority and review behavior.
- **Source:** BR-005
- **Priority:** P1
- **Dependencies:** SEC-004
- **Acceptance criteria:** The named human action is required and its absence blocks the transition.
- **Validation method:** Workflow/adversarial tests.
- **Related risks:** RISK-022
- **Related architecture:** ADR-006
- **Related plan items:** PLAN-014
- **Status:** Proposed

### TEST-001 — Contract version mismatch

- **ID:** TEST-001
- **Title:** Contract version mismatch
- **Statement:** Retired 1.0 MUST fail; declared 1.1 N-1 MAY pass only with compatibility declaration.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-001
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-006
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-003
- **Status:** Proposed

### TEST-002 — Template parity

- **ID:** TEST-002
- **Title:** Template parity
- **Statement:** Every generated template MUST validate after documented fields are filled.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-005
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-007
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-005
- **Status:** Proposed

### TEST-003 — Duplicate canonical source

- **ID:** TEST-003
- **Title:** Duplicate canonical source
- **Statement:** Two selectable paths with the same ID MUST fail catalog validation.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-008
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-008
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-022
- **Status:** Proposed

### TEST-004 — Identity spoof

- **ID:** TEST-004
- **Title:** Identity spoof
- **Statement:** Mismatched role/agent/provider/request digest MUST fail receipt ingestion.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-009
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-009
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-009,PLAN-015
- **Status:** Proposed

### TEST-005 — Consent fabrication

- **ID:** TEST-005
- **Title:** Consent fabrication
- **Statement:** Agent-authored, relayed, stale, or reused authorization MUST fail.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-011
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-010
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-013
- **Status:** Proposed

### TEST-006 — Required assertion semantics

- **ID:** TEST-006
- **Title:** Required assertion semantics
- **Statement:** A pass report containing any failed/not-run required assertion MUST fail.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-006
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-011
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-014
- **Status:** Proposed

### TEST-007 — Worker re-gate

- **ID:** TEST-007
- **Title:** Worker re-gate
- **Statement:** A Worker “pass” with failing command MUST be rejected by orchestrator gate.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-014
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-012
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-015
- **Status:** Proposed

### TEST-008 — Checkpoint interruption matrix

- **ID:** TEST-008
- **Title:** Checkpoint interruption matrix
- **Statement:** Interrupt after every major state and verify deterministic resume.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-004
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-013
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-007
- **Status:** Proposed

### TEST-009 — Checkpoint tamper

- **ID:** TEST-009
- **Title:** Checkpoint tamper
- **Statement:** Changed hash, path, schema, test, mission ID, or scope MUST invalidate checkpoint.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-004
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-014
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-007
- **Status:** Proposed

### TEST-010 — Generated artifact currency

- **ID:** TEST-010
- **Title:** Generated artifact currency
- **Statement:** A dependent edit MUST stale and regenerate derived artifacts before pass.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-015
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-015
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-006
- **Status:** Proposed

### TEST-011 — External provider lifecycle

- **ID:** TEST-011
- **Title:** External provider lifecycle
- **Statement:** External Worker and Reviewer MUST execute without manual relay and with valid provenance.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-012
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-016
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-011
- **Status:** Proposed

### TEST-012 — Review decomposition threshold

- **ID:** TEST-012
- **Title:** Review decomposition threshold
- **Statement:** Stalled review MUST split at configured historical threshold and preserve assertion coverage.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-013
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-017
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-016
- **Status:** Proposed

### TEST-013 — Backend result containment

- **ID:** TEST-013
- **Title:** Backend result containment
- **Statement:** Relative final path, external path, misplaced result, inconsistent status/exit, and absolute artifact paths MUST fail.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-007
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-018
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-020
- **Status:** Proposed

### TEST-014 — Backend smoke tamper

- **ID:** TEST-014
- **Title:** Backend smoke tamper
- **Statement:** Changing backend descriptor, lock, runner, or contract MUST stale smoke receipt.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-007
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-019
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-021
- **Status:** Proposed

### TEST-015 — Verification-strength round trip

- **ID:** TEST-015
- **Title:** Verification-strength round trip
- **Statement:** Mechanical and semantic confirmations MUST remain distinct through persist/resume/retrieval.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-020
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-020
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-018
- **Status:** Proposed

### TEST-016 — Knowledge authority fence

- **ID:** TEST-016
- **Title:** Knowledge authority fence
- **Statement:** Memory candidate MUST NOT write accepted knowledge; stale authority context MUST flag.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-016
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-021
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-019
- **Status:** Proposed

### TEST-017 — Improvement closure

- **ID:** TEST-017
- **Title:** Improvement closure
- **Statement:** An improvement without regression test or release version MUST remain open.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** CUR-018
- **Priority:** P1
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-022
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-023
- **Status:** Proposed

### TEST-018 — Pilot rendering mission

- **ID:** TEST-018
- **Title:** Pilot rendering mission
- **Statement:** Replay must prove consent, external Reviewer, recovery, surgical revisions, and final gate.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** SRC-002
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-023
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-026
- **Status:** Proposed

### TEST-019 — Pilot generality mission

- **ID:** TEST-019
- **Title:** Pilot generality mission
- **Statement:** A different repository mission MUST pass with lower manual/context overhead.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** BR-006
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-024
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-027
- **Status:** Proposed

### TEST-020 — Rollback drill

- **ID:** TEST-020
- **Title:** Rollback drill
- **Statement:** Cutover rollback MUST restore old runtime without losing new artifacts.
- **Rationale:** Converts observed defects and target controls into regression evidence.
- **Source:** BR-004
- **Priority:** P0
- **Dependencies:** Relevant requirement
- **Acceptance criteria:** Test has a positive case and at least one explicit negative/tamper case.
- **Validation method:** Automated or live acceptance test.
- **Related risks:** RISK-025
- **Related architecture:** Relevant ADR
- **Related plan items:** PLAN-028,PLAN-030
- **Status:** Proposed


## 6. Deferred items

- Automatic knowledge promotion.
- Autonomous merge/push or production mutation.
- Multi-tenant central capability service.
- Full UI/dashboard implementation.
- Broad support for every agent host.
- Long-term semantic memory optimization beyond verification-bearing records.

## 7. Exclusions

The runtime does not own backend implementation, accepted knowledge, source-repository local agents, or user identity systems. It coordinates through contracts.

# 11. Testudo embedding requirements

The following requirements extend the v1 orchestration specification. They are normative for embedding the runtime within Testudo.

## 11.1 Business requirements

### BR-007 — Product-owned orchestration experience

- **ID:** BR-007
- **Title:** Embed orchestration as a Testudo subsystem
- **Statement:** Testudo MUST own the user-facing AI experience and MUST consume `modeller-agents` through a versioned subsystem contract.
- **Rationale:** The product requires project-centred continuity without exposing plugin or provider mechanics.
- **Source:** SRC-014 §1, §3, §9; SRC-015 INT-001–INT-006.
- **Priority:** P0
- **Dependencies:** BR-001, ADR-013
- **Acceptance criteria:** One Testudo interaction creates and observes a mission without opening another agent interface; host-specific plugin fields are absent from product payloads.
- **Validation method:** API and end-to-end user test.
- **Related risks:** RISK-031, RISK-032
- **Related architecture:** ADR-013, ADR-022
- **Related plan items:** PLAN-033, PLAN-034, PLAN-044
- **Status:** Approved baseline

### BR-008 — Single visible contextual agent

- **ID:** BR-008
- **Title:** Present one visible agent
- **Statement:** Testudo MUST present one visible contextual AI agent while preserving internal Decider, Manager, Recon, Worker and Reviewer separation.
- **Rationale:** Internal governance must not fragment the product experience.
- **Source:** SRC-014 §9; SRC-015 ARC-005.
- **Priority:** P0
- **Dependencies:** BR-007
- **Acceptance criteria:** The user remains in one Project × User conversation; internal roles are visible only in authorized diagnostics; receipts preserve internal authorship.
- **Validation method:** UX and audit test.
- **Related risks:** RISK-032
- **Related architecture:** ADR-014
- **Related plan items:** PLAN-034
- **Status:** Approved baseline

### BR-009 — Project-centred missions

- **ID:** BR-009
- **Title:** Bind orchestration to the Testudo project
- **Statement:** Every mission, task, result registration, finding and publication MUST belong to one Testudo project and an inspectable active context.
- **Rationale:** The project is the persistent product unit and primary authorization boundary.
- **Source:** SRC-014 §7; SRC-015 BR-002, INT-001.
- **Priority:** P0
- **Dependencies:** BR-007, DATA-009
- **Acceptance criteria:** Missing or inaccessible project context blocks material actions; lineage retains project and context digests.
- **Validation method:** Data and authorization tests.
- **Related risks:** RISK-031, RISK-035
- **Related architecture:** ADR-015
- **Related plan items:** PLAN-032, PLAN-035
- **Status:** Approved baseline

### BR-010 — Dual persistence ownership

- **ID:** BR-010
- **Title:** Separate product authority from analytical datasets
- **Statement:** Product authority MUST be stored in PostgreSQL, simulation analytical datasets MUST use DuckDB or governed Parquet, and immutable evidence MUST use file/object artifacts.
- **Rationale:** Transactional product state, analytical workloads and recovery artifacts have different requirements.
- **Source:** SRC-016.
- **Priority:** P0
- **Dependencies:** DATA-011–DATA-013
- **Acceptance criteria:** Permission/project records are not authoritative in DuckDB; unbounded result tables are not stored in PostgreSQL by default; every cross-store reference has a stable ID and checksum.
- **Validation method:** Architecture, migration and data-placement tests.
- **Related risks:** RISK-033, RISK-039
- **Related architecture:** ADR-016
- **Related plan items:** PLAN-036–PLAN-038
- **Status:** Confirmed

## 11.2 Functional requirements

### FR-015 — Context gateway

- **ID:** FR-015
- **Title:** Validate active context before material actions
- **Statement:** The Gateway MUST validate user, permissions, project, model, version, period, scenario, selected SimulationRun, view and selection before preparing or executing a material action.
- **Rationale:** Correct technical execution on the wrong context is a product failure.
- **Source:** SRC-014 §9.1; SRC-015 FR-002, INT-001.
- **Priority:** P0
- **Dependencies:** DATA-009, INT-012
- **Acceptance criteria:** Invalid, stale or unauthorized context returns a blocking structured error; the digest is retained in mission and approval records.
- **Validation method:** Context matrix tests.
- **Related risks:** RISK-031, RISK-035
- **Related architecture:** ADR-015
- **Related plan items:** PLAN-032, PLAN-033
- **Status:** Approved baseline

### FR-016 — Mission/task binding

- **ID:** FR-016
- **Title:** Create a mission and linked Testudo task
- **Statement:** Preparing an executable workflow MUST create a `Mission` in `modeller-agents` and a linked persistent `Task` in Testudo.
- **Rationale:** Product progress and runtime state need distinct but correlated identities.
- **Source:** SRC-014 §8; SRC-015 FR-009.
- **Priority:** P0
- **Dependencies:** DATA-010, INT-011
- **Acceptance criteria:** Both IDs and one correlation ID are returned atomically or compensated; retries are idempotent.
- **Validation method:** Integration and retry tests.
- **Related risks:** RISK-034, RISK-036
- **Related architecture:** ADR-017
- **Related plan items:** PLAN-033, PLAN-039
- **Status:** Approved baseline

### FR-017 — Runtime-to-product task projection

- **ID:** FR-017
- **Title:** Synchronize persistent task lifecycle
- **Statement:** Testudo MUST project preparation, approval, execution, partial result, intervention, recovery, completion, failure and cancellation from typed runtime events.
- **Rationale:** Long tasks must remain understandable after reconnection or provider failure.
- **Source:** SRC-014 §8.4; SRC-015 FR-009, OBS-001.
- **Priority:** P0
- **Dependencies:** INT-013, OBS-010
- **Acceptance criteria:** Event replay reconstructs the same task state; provider prose cannot mark completion.
- **Validation method:** Event replay and failure injection.
- **Related risks:** RISK-034, RISK-037
- **Related architecture:** ADR-018
- **Related plan items:** PLAN-039, PLAN-040
- **Status:** Approved baseline

### FR-018 — Project-responsibility approvals

- **ID:** FR-018
- **Title:** Render exact human approvals
- **Statement:** Testudo MUST render exact approval requests and accept decisions only from the required project responsibility.
- **Rationale:** Generic user consent is insufficient for simulation, technical review and publication.
- **Source:** SRC-014 §4, §9.4; SRC-015 HITL-001–HITL-004.
- **Priority:** P0
- **Dependencies:** HITL-011–HITL-014
- **Acceptance criteria:** Request displays context/effects/risks; unauthorized actor cannot approve; receipt binds exact digests.
- **Validation method:** Role and bypass tests.
- **Related risks:** RISK-035
- **Related architecture:** ADR-020
- **Related plan items:** PLAN-035
- **Status:** Approved baseline

### FR-019 — Conversation continuity

- **ID:** FR-019
- **Title:** Preserve one conversation across internal delegation
- **Statement:** Internal role dispatch MUST NOT create additional user-visible conversations or change the Project × User conversation identity.
- **Rationale:** The visible agent is the connective layer of the product.
- **Source:** SRC-014 §9; SRC-015 FR-015.
- **Priority:** P0
- **Dependencies:** BR-008, DATA-014
- **Acceptance criteria:** Messages and status updates return to the same conversation; private visibility is preserved.
- **Validation method:** Multi-user conversation tests.
- **Related risks:** RISK-032, RISK-035
- **Related architecture:** ADR-014
- **Related plan items:** PLAN-034
- **Status:** Approved baseline

### FR-020 — Output classification

- **ID:** FR-020
- **Title:** Classify visible outputs and actions
- **Statement:** Every visible agent output MUST be classified as interpretation, hypothesis, recommendation, prepared action or executed action, and computed results and human decisions MUST remain separate.
- **Rationale:** Testudo trust depends on semantic separation.
- **Source:** SRC-014 §9.5; SRC-015 INT-007.
- **Priority:** P0
- **Dependencies:** FR-019
- **Acceptance criteria:** Classification is present in API and UI; category changes are logged; human approver is identified.
- **Validation method:** Content and comprehension tests.
- **Related risks:** RISK-032, RISK-037
- **Related architecture:** ADR-021
- **Related plan items:** PLAN-034, PLAN-041
- **Status:** Approved baseline

### FR-021 — Partial dataset visibility

- **ID:** FR-021
- **Title:** Register partial result sets
- **Statement:** The runtime MUST register available, missing, invalid and processing datasets separately and Testudo MUST display their authorized uses.
- **Rationale:** Partial success must neither be lost nor represented as complete.
- **Source:** SRC-015 BR-006, FR-010.
- **Priority:** P0
- **Dependencies:** DATA-012, INT-015
- **Acceptance criteria:** Dataset status and limitations are queryable; comparison/publication gates account for missing outputs.
- **Validation method:** Missing-output tests.
- **Related risks:** RISK-037, RISK-039
- **Related architecture:** ADR-016, ADR-021
- **Related plan items:** PLAN-037, PLAN-040
- **Status:** Approved baseline

### FR-022 — Technical finding lifecycle

- **ID:** FR-022
- **Title:** Create a governed finding handoff
- **Statement:** Accepted technical mission evidence MAY create a `FindingCandidate`, but MUST NOT become an accepted finding without Technical Reviewer action.
- **Rationale:** Mission completion is not a human technical conclusion.
- **Source:** SRC-014 §10; SRC-015 HITL-002, INT-009.
- **Priority:** P0
- **Dependencies:** HITL-012, INT-016
- **Acceptance criteria:** Evidence, context, uncertainty and AI contribution are retained; accept/correct/reject states are explicit.
- **Validation method:** Review workflow test.
- **Related risks:** RISK-037
- **Related architecture:** ADR-021
- **Related plan items:** PLAN-041
- **Status:** Approved baseline

### FR-023 — Publication lifecycle

- **ID:** FR-023
- **Title:** Prepare a versioned publication handoff
- **Statement:** Testudo MUST prepare a frozen or versioned publication from reviewed findings and MUST require Project Manager approval before client release.
- **Rationale:** Client communication requires separate authority and stable provenance.
- **Source:** SRC-014 §10; SRC-015 FR-014, HITL-002.
- **Priority:** P0
- **Dependencies:** FR-022, HITL-013
- **Acceptance criteria:** Publication retains context, SimulationRun, datasets, views, findings, reviewer and approver; replay does not alter it.
- **Validation method:** Versioning and approval tests.
- **Related risks:** RISK-037
- **Related architecture:** ADR-021
- **Related plan items:** PLAN-042
- **Status:** Approved baseline

### FR-024 — UI action protocol

- **ID:** FR-024
- **Title:** Execute visible reversible UI actions
- **Statement:** Low-risk map, chart and table actions MAY be executed by the visible agent only through visible, attributed and reversible `UiActionRequest` contracts.
- **Rationale:** Product assistance must remain observable.
- **Source:** SRC-014 §9.2–§9.4; SRC-015 INT-004.
- **Priority:** P1
- **Dependencies:** INT-017
- **Acceptance criteria:** Action is announced, logged and undoable where declared reversible; unauthorized selection data is excluded.
- **Validation method:** UX, audit and undo tests.
- **Related risks:** RISK-032, RISK-035
- **Related architecture:** ADR-013
- **Related plan items:** PLAN-034
- **Status:** Approved baseline

## 11.3 Data requirements

### DATA-009 — Project context identifiers

- **ID:** DATA-009
- **Title:** Identify Testudo project context
- **Statement:** Every mission and downstream artifact MUST retain project, user, conversation and active-context identifiers and digests.
- **Rationale:** Product traceability and permission evaluation require stable anchors.
- **Source:** SRC-014 §7; SRC-015 BR-002, OBS-003.
- **Priority:** P0
- **Dependencies:** None
- **Acceptance criteria:** Orphan mission/artifact registration fails; historical context remains resolvable or marked unavailable.
- **Validation method:** Lineage tests.
- **Related risks:** RISK-031, RISK-035
- **Related architecture:** ADR-015
- **Related plan items:** PLAN-032
- **Status:** Approved baseline

### DATA-010 — Cross-domain identity separation

- **ID:** DATA-010
- **Title:** Separate Mission, Task and SimulationRun
- **Statement:** `Mission`, `Task`, `SimulationRun`, `DispatchAttempt` and `ResultSet` MUST use distinct identifiers and relation fields.
- **Rationale:** The same word `run` creates audit and recovery ambiguity.
- **Source:** SRC-003, SRC-014 §7.
- **Priority:** P0
- **Dependencies:** DATA-009
- **Acceptance criteria:** Schemas reject field substitution; UI labels use business terms; logs carry all relevant IDs.
- **Validation method:** Schema and correlation tests.
- **Related risks:** RISK-036
- **Related architecture:** ADR-017
- **Related plan items:** PLAN-031
- **Status:** Approved baseline

### DATA-011 — PostgreSQL product records

- **ID:** DATA-011
- **Title:** Store product authority in PostgreSQL
- **Statement:** Users, projects, permissions, responsibilities, task metadata, conversations, findings, publications, approvals and artifact references MUST be persisted in PostgreSQL.
- **Rationale:** These are shared transactional product records.
- **Source:** SRC-016.
- **Priority:** P0
- **Dependencies:** DATA-009
- **Acceptance criteria:** ACID transactions protect authority changes; project authorization is enforced server-side; migrations are versioned.
- **Validation method:** Database, concurrency and authorization tests.
- **Related risks:** RISK-033, RISK-035
- **Related architecture:** ADR-016
- **Related plan items:** PLAN-036
- **Status:** Confirmed

### DATA-012 — DuckDB result datasets

- **ID:** DATA-012
- **Title:** Store simulation analytics in DuckDB
- **Statement:** High-volume simulation, observed, KPI, validation, comparison and trajectory datasets MUST use DuckDB or governed Parquet accessed through DuckDB-compatible manifests.
- **Rationale:** Simulation analytics require columnar query performance and portable datasets.
- **Source:** SRC-016.
- **Priority:** P0
- **Dependencies:** DATA-010
- **Acceptance criteria:** Dataset manifests include schema, checksum, project, model, scenario, SimulationRun, source and quality state; no silent truncation.
- **Validation method:** Load, integrity and query tests.
- **Related risks:** RISK-033, RISK-039
- **Related architecture:** ADR-016
- **Related plan items:** PLAN-037
- **Status:** Confirmed

### DATA-013 — Artifact catalog

- **ID:** DATA-013
- **Title:** Reference immutable evidence
- **Statement:** PostgreSQL MUST store references and metadata for immutable evidence artifacts, while artifact content remains content-addressed in controlled file or object storage.
- **Rationale:** Recovery and large artifacts should not depend on database blobs.
- **Source:** SRC-002, SRC-004, SRC-016.
- **Priority:** P0
- **Dependencies:** DATA-011
- **Acceptance criteria:** Digest verification detects replacement; access follows project permissions; retention status is visible.
- **Validation method:** Tamper, access and recovery tests.
- **Related risks:** RISK-034
- **Related architecture:** ADR-016, ADR-018
- **Related plan items:** PLAN-038
- **Status:** Approved baseline

### DATA-014 — Project × User conversations

- **ID:** DATA-014
- **Title:** Keep conversations private by default
- **Statement:** Visible-agent conversations MUST be scoped to Project × User and private unless explicitly published.
- **Rationale:** Exploratory AI interaction is not automatically shared project knowledge.
- **Source:** SRC-014 §9.6; SRC-015 FR-015, SEC-005.
- **Priority:** P0
- **Dependencies:** DATA-011
- **Acceptance criteria:** Other project users cannot read the conversation by default; publication creates a separate governed object.
- **Validation method:** Multi-user tests.
- **Related risks:** RISK-035
- **Related architecture:** ADR-013
- **Related plan items:** PLAN-034, PLAN-036
- **Status:** Approved baseline

### DATA-015 — Future event-store seam

- **ID:** DATA-015
- **Title:** Preserve PostgreSQL event-store compatibility
- **Statement:** Product events MUST use stable IDs, versions, sequence/correlation fields and payload schemas compatible with later PostgreSQL event-store persistence.
- **Rationale:** Event-store adoption is deferred, not precluded.
- **Source:** SRC-016.
- **Priority:** P1
- **Dependencies:** INT-013
- **Acceptance criteria:** Events replay deterministically; publisher/storage implementation can be replaced without changing producers.
- **Validation method:** Replay and adapter tests.
- **Related risks:** RISK-034
- **Related architecture:** ADR-018
- **Related plan items:** PLAN-045
- **Status:** Confirmed direction

### DATA-016 — Cross-store lineage

- **ID:** DATA-016
- **Title:** Version result and publication lineage
- **Statement:** Findings and publications MUST retain versioned references to PostgreSQL records, DuckDB datasets and immutable artifacts.
- **Rationale:** Cross-store data separation must not break reproducibility.
- **Source:** SRC-014 §10; SRC-015 DATA-006, DATA-010.
- **Priority:** P0
- **Dependencies:** DATA-011–DATA-013
- **Acceptance criteria:** A publication resolves or explicitly reports every lineage element; changed active data does not mutate prior publication.
- **Validation method:** Publication lineage audit.
- **Related risks:** RISK-033, RISK-037
- **Related architecture:** ADR-016, ADR-021
- **Related plan items:** PLAN-041, PLAN-042
- **Status:** Approved baseline

## 11.4 Integration requirements

### INT-011 — Orchestration Gateway API

- **ID:** INT-011
- **Title:** Provide a versioned Testudo orchestration API
- **Statement:** `modeller-agents` MUST expose prepare, create, approve, execute, observe, cancel, retry, register-result and close operations through versioned contracts.
- **Rationale:** Testudo must not call plugin internals.
- **Source:** SRC-014 §6; SRC-015 ARC-003, ARC-005.
- **Priority:** P0
- **Dependencies:** BR-007
- **Acceptance criteria:** API is host-neutral, idempotent and schema-validated; provider-specific fields remain internal.
- **Validation method:** Contract and compatibility tests.
- **Related risks:** RISK-031, RISK-038
- **Related architecture:** ADR-013, ADR-022
- **Related plan items:** PLAN-033
- **Status:** Approved baseline

### INT-012 — Context contract

- **ID:** INT-012
- **Title:** Consume a signed active-context envelope
- **Statement:** The Gateway MUST accept only a signed or server-attested active-context envelope issued by Testudo.
- **Rationale:** Agent-provided context must not expand user authority.
- **Source:** SRC-015 INT-001, SEC-002.
- **Priority:** P0
- **Dependencies:** DATA-009
- **Acceptance criteria:** Altered/expired envelopes fail; permission digest is audited; sensitive payloads are minimized.
- **Validation method:** Tamper and expiry tests.
- **Related risks:** RISK-031, RISK-035
- **Related architecture:** ADR-015
- **Related plan items:** PLAN-032, PLAN-035
- **Status:** Approved baseline

### INT-013 — Product event bridge

- **ID:** INT-013
- **Title:** Publish typed task events
- **Statement:** The runtime MUST publish versioned, idempotent product events for all user-visible mission state changes.
- **Rationale:** Testudo task status must be deterministic and recoverable.
- **Source:** SRC-015 OBS-001.
- **Priority:** P0
- **Dependencies:** INT-011
- **Acceptance criteria:** Duplicate delivery is safe; ordering gaps are detected; replay reaches the same state.
- **Validation method:** Event contract and replay tests.
- **Related risks:** RISK-034
- **Related architecture:** ADR-018
- **Related plan items:** PLAN-039
- **Status:** Approved baseline

### INT-014 — Backend execution boundary

- **ID:** INT-014
- **Title:** Invoke simulation backends without transferring product authority
- **Statement:** Simulation and modelling backends MUST receive only the configuration, datasets and scoped capabilities required for the approved task.
- **Rationale:** A backend is a technical authority, not a user/project authority.
- **Source:** SRC-014 §3, §6.3; SRC-015 SEC-002.
- **Priority:** P0
- **Dependencies:** SEC-009, SEC-011
- **Acceptance criteria:** Backend cannot query unrelated projects or approve task transitions; returned results pass contract validation.
- **Validation method:** Capability and result tests.
- **Related risks:** RISK-035, RISK-038
- **Related architecture:** ADR-005, ADR-013
- **Related plan items:** PLAN-033, PLAN-035
- **Status:** Approved baseline

### INT-015 — Result registration

- **ID:** INT-015
- **Title:** Register dataset manifests and quality states
- **Statement:** A backend result MUST be registered through a `ResultDatasetManifest` before Testudo exposes it as available.
- **Rationale:** File presence alone does not establish provenance or completeness.
- **Source:** SRC-015 DATA-006, FR-010.
- **Priority:** P0
- **Dependencies:** DATA-012, DATA-013
- **Acceptance criteria:** Schema, checksum, lineage, quality and status pass; rejected manifests do not advance task completion.
- **Validation method:** Result contract tests.
- **Related risks:** RISK-037, RISK-039
- **Related architecture:** ADR-016
- **Related plan items:** PLAN-037, PLAN-040
- **Status:** Approved baseline

### INT-016 — Finding/knowledge seam

- **ID:** INT-016
- **Title:** Submit project and knowledge candidates separately
- **Statement:** The runtime MUST distinguish a Testudo project finding candidate from a cross-project knowledge candidate.
- **Rationale:** Project review and durable knowledge governance have different authorities.
- **Source:** SRC-014 §6.8; SRC-015 INT-009; SRC-006–SRC-009.
- **Priority:** P1
- **Dependencies:** FR-022
- **Acceptance criteria:** Accepting a project finding does not automatically promote vault knowledge; source/evidence are retained.
- **Validation method:** State and governance tests.
- **Related risks:** RISK-037, RISK-040
- **Related architecture:** ADR-008, ADR-021
- **Related plan items:** PLAN-041
- **Status:** Approved baseline

### INT-017 — Visible UI actions

- **ID:** INT-017
- **Title:** Execute UI actions through a product protocol
- **Statement:** Agent-driven filters, selections, recentering and comparison opening MUST use a Testudo-owned UI action protocol.
- **Rationale:** Providers must not manipulate the browser or product state through hidden channels.
- **Source:** SRC-014 §9.3; SRC-015 INT-004.
- **Priority:** P1
- **Dependencies:** INT-011
- **Acceptance criteria:** Action is authorized, attributable, observable and reversible when declared.
- **Validation method:** UI protocol and undo tests.
- **Related risks:** RISK-032, RISK-035
- **Related architecture:** ADR-013
- **Related plan items:** PLAN-034
- **Status:** Approved baseline

### INT-018 — Publication integration

- **ID:** INT-018
- **Title:** Hand off reviewed evidence for publication
- **Statement:** The runtime MUST provide a frozen publication handoff containing reviewed findings, context, dataset and artifact references, but Testudo MUST own composition, recipient control and approval.
- **Rationale:** Technical delivery must not bypass product publication authority.
- **Source:** SRC-014 §6.7, §10; SRC-015 FR-014, FR-017.
- **Priority:** P0
- **Dependencies:** FR-023, DATA-016
- **Acceptance criteria:** Runtime cannot mark publication approved; Testudo retains version and approver.
- **Validation method:** End-to-end publication test.
- **Related risks:** RISK-037
- **Related architecture:** ADR-021
- **Related plan items:** PLAN-042, PLAN-044
- **Status:** Approved baseline

## 11.5 Security requirements

### SEC-009 — Permission inheritance

- **ID:** SEC-009
- **Title:** Inherit triggering-user permissions
- **Statement:** Every mission and provider dispatch MUST be limited to the data and capabilities authorized for the triggering user and project responsibility.
- **Rationale:** AI must not become an access bypass.
- **Source:** SRC-015 BR-007, SEC-002.
- **Priority:** P0
- **Dependencies:** INT-012
- **Acceptance criteria:** Negative tests deny cross-project and out-of-role operations; attempts are logged.
- **Validation method:** Authorization bypass tests.
- **Related risks:** RISK-035
- **Related architecture:** ADR-015, ADR-020
- **Related plan items:** PLAN-035
- **Status:** Approved baseline

### SEC-010 — Project isolation

- **ID:** SEC-010
- **Title:** Isolate projects and conversations
- **Statement:** PostgreSQL queries, artifact references, DuckDB datasets and conversations MUST enforce project scope.
- **Rationale:** Data can be confidential client deliverables.
- **Source:** SRC-014 §4; SRC-015 SEC-001, SEC-005.
- **Priority:** P0
- **Dependencies:** DATA-011–DATA-014
- **Acceptance criteria:** Cross-project identifiers do not leak metadata; revoked access prevents new reads/actions.
- **Validation method:** Multi-project security tests.
- **Related risks:** RISK-035
- **Related architecture:** ADR-016
- **Related plan items:** PLAN-035–PLAN-038
- **Status:** Approved baseline

### SEC-011 — External provider policy

- **ID:** SEC-011
- **Title:** Control external agent and service transmission
- **Statement:** External agent or service dispatch MUST identify destination, purpose, fields, classification, redaction and consent before transmission.
- **Rationale:** Client/project data cannot leave its scope silently.
- **Source:** SRC-014 §9.4, §11; SRC-015 SEC-003.
- **Priority:** P0
- **Dependencies:** SEC-009
- **Acceptance criteria:** Prohibited data is blocked; payload digest and destination are audited; policy can disable provider.
- **Validation method:** DLP and provider tests.
- **Related risks:** RISK-035, RISK-040
- **Related architecture:** ADR-005, ADR-019
- **Related plan items:** PLAN-035, PLAN-043
- **Status:** Approved baseline

### SEC-012 — Secret isolation

- **ID:** SEC-012
- **Title:** Keep secrets outside agent context
- **Statement:** Database credentials, provider secrets and backend credentials MUST NOT be included in conversational or role context.
- **Rationale:** Agents require scoped operations, not reusable credentials.
- **Source:** SRC-015 SEC-002, SEC-003.
- **Priority:** P0
- **Dependencies:** INT-011
- **Acceptance criteria:** Secrets are resolved by trusted adapters; logs and receipts contain no raw secret.
- **Validation method:** Secret scanning and runtime tests.
- **Related risks:** RISK-035
- **Related architecture:** ADR-013
- **Related plan items:** PLAN-033, PLAN-035
- **Status:** Approved baseline

### SEC-013 — Audit integrity

- **ID:** SEC-013
- **Title:** Protect audit and approval records
- **Statement:** Sensitive action, approval, task and publication audit records MUST be append-only or tamper-evident and access-controlled.
- **Rationale:** Attribution and investigation depend on trustworthy history.
- **Source:** SRC-015 SEC-004, OBS-002.
- **Priority:** P0
- **Dependencies:** DATA-011, DATA-013
- **Acceptance criteria:** Modification is detected or prohibited; actor/context/result/timestamp are retained.
- **Validation method:** Tamper and audit tests.
- **Related risks:** RISK-034, RISK-035
- **Related architecture:** ADR-018
- **Related plan items:** PLAN-036, PLAN-038, PLAN-039
- **Status:** Approved baseline

## 11.6 Observability requirements

### OBS-009 — Cross-system correlation

- **ID:** OBS-009
- **Title:** Correlate product, mission, task and simulation
- **Statement:** Logs and events MUST carry project, context, conversation, task, mission, SimulationRun and dispatch identifiers where applicable.
- **Rationale:** Distributed evidence is otherwise not auditable.
- **Source:** SRC-015 OBS-001–OBS-003.
- **Priority:** P0
- **Dependencies:** DATA-010
- **Acceptance criteria:** One correlation query reconstructs the reference journey.
- **Validation method:** Trace audit.
- **Related risks:** RISK-034, RISK-036
- **Related architecture:** ADR-017, ADR-018
- **Related plan items:** PLAN-031, PLAN-039
- **Status:** Approved baseline

### OBS-010 — Persistent task observability

- **ID:** OBS-010
- **Title:** Emit task lifecycle events
- **Statement:** Every task transition MUST have a timestamp, cause, actor/system and evidence reference.
- **Rationale:** Users need to understand waits, failures and recovery.
- **Source:** SRC-015 OBS-001.
- **Priority:** P0
- **Dependencies:** INT-013
- **Acceptance criteria:** Durations and failure metrics are computable; missing sequence is detected.
- **Validation method:** Event and dashboard tests.
- **Related risks:** RISK-034, RISK-037
- **Related architecture:** ADR-018
- **Related plan items:** PLAN-039
- **Status:** Approved baseline

### OBS-011 — AI action attribution

- **ID:** OBS-011
- **Title:** Observe agent actions and visible output types
- **Statement:** Prepared actions, executed actions, UI changes, provider dispatches and publication handoffs MUST be logged with output classification.
- **Rationale:** Proposal and execution must remain distinguishable.
- **Source:** SRC-015 OBS-002, INT-007.
- **Priority:** P0
- **Dependencies:** FR-020
- **Acceptance criteria:** Triggering human and internal subsystem are distinguishable; sensitive parameters are protected.
- **Validation method:** Audit tests.
- **Related risks:** RISK-032, RISK-035
- **Related architecture:** ADR-014
- **Related plan items:** PLAN-034, PLAN-039
- **Status:** Approved baseline

### OBS-012 — Result-to-publication lineage

- **ID:** OBS-012
- **Title:** Observe cross-store evidence lineage
- **Statement:** Authorized users MUST trace a publication to findings, task, mission, SimulationRun, DuckDB datasets, artifacts, methods and approvals.
- **Rationale:** Data separation must not reduce reproducibility.
- **Source:** SRC-014 §10; SRC-015 OBS-003.
- **Priority:** P0
- **Dependencies:** DATA-016
- **Acceptance criteria:** Broken or deleted references are flagged without rewriting history.
- **Validation method:** Lineage audit.
- **Related risks:** RISK-033, RISK-037
- **Related architecture:** ADR-016, ADR-021
- **Related plan items:** PLAN-041, PLAN-042, PLAN-044
- **Status:** Approved baseline

### OBS-013 — Integration KPIs

- **ID:** OBS-013
- **Title:** Measure product and agent outcomes
- **Statement:** Testudo SHOULD measure context confirmation time, workflow preparation time, task recovery, external tool breaks, agent suggestion handling and publication lead time.
- **Rationale:** The integration must prove business value, not only technical correctness.
- **Source:** SRC-014 §13; SRC-015 OBS-004.
- **Priority:** P1
- **Dependencies:** SEC-010
- **Acceptance criteria:** Metrics have purpose, minimal personal data and baseline comparison.
- **Validation method:** Analytics review.
- **Related risks:** RISK-038
- **Related architecture:** ADR-013
- **Related plan items:** PLAN-044
- **Status:** Approved baseline

## 11.7 Human supervision requirements

### HITL-011 — Run Owner confirmation

- **ID:** HITL-011
- **Title:** Approve simulation launch
- **Statement:** A simulation launch MUST require explicit confirmation from the authorized Transport Modeller or Run Owner bound to the exact context and configuration.
- **Rationale:** Simulation has cost and material modelling impact.
- **Source:** SRC-014 §5.1, §9.4; SRC-015 HITL-001.
- **Priority:** P0
- **Dependencies:** FR-018
- **Acceptance criteria:** Refusal or expiry does not launch; changed plan/context invalidates approval.
- **Validation method:** Gate tests.
- **Related risks:** RISK-031, RISK-035
- **Related architecture:** ADR-020
- **Related plan items:** PLAN-035, PLAN-044
- **Status:** Approved baseline

### HITL-012 — Technical Reviewer authority

- **ID:** HITL-012
- **Title:** Review technical findings
- **Statement:** A finding MUST require accept, correct, reject or revision action by an authorized Technical Reviewer before it is treated as accepted project knowledge.
- **Rationale:** AI interpretation is not technical validation.
- **Source:** SRC-014 §6.6; SRC-015 HITL-002.
- **Priority:** P0
- **Dependencies:** FR-022
- **Acceptance criteria:** Reviewer, status, comments and version are retained; rejected content is inactive.
- **Validation method:** Review tests.
- **Related risks:** RISK-037
- **Related architecture:** ADR-020, ADR-021
- **Related plan items:** PLAN-041
- **Status:** Approved baseline

### HITL-013 — Publication Approver authority

- **ID:** HITL-013
- **Title:** Approve client publication
- **Statement:** Client publication MUST require explicit Project Manager or configured Publication Approver action.
- **Rationale:** Technical review and external release have different responsibilities.
- **Source:** SRC-014 §4, §5.2; SRC-015 HITL-002.
- **Priority:** P0
- **Dependencies:** FR-023
- **Acceptance criteria:** Recipients, content version, context and caveats are shown; approval is logged.
- **Validation method:** Permission and publication tests.
- **Related risks:** RISK-037
- **Related architecture:** ADR-020, ADR-021
- **Related plan items:** PLAN-042, PLAN-044
- **Status:** Approved baseline

### HITL-014 — Data/Model Owner control

- **ID:** HITL-014
- **Title:** Approve owned data/model use
- **Statement:** Use or transmission of client-owned assets outside an already approved project purpose MUST require Data/Model Owner or project Decider approval.
- **Rationale:** Ownership and functional permissions are separate.
- **Source:** SRC-015 Actors; SRC-014 §4.
- **Priority:** P0
- **Dependencies:** SEC-011
- **Acceptance criteria:** Purpose, destination, assets and scope are explicit; no inferred approval.
- **Validation method:** Consent and scope tests.
- **Related risks:** RISK-035
- **Related architecture:** ADR-020
- **Related plan items:** PLAN-035
- **Status:** Approved baseline

### HITL-015 — Product-aware stop condition

- **ID:** HITL-015
- **Title:** Escalate context, evidence and authority uncertainty
- **Statement:** The visible agent and runtime MUST stop and request the appropriate human responsibility when context, comparability, evidence or authority is insufficient.
- **Rationale:** A plausible action is not a safe action.
- **Source:** SRC-015 HITL-004, INT-008.
- **Priority:** P0
- **Dependencies:** FR-015, FR-018
- **Acceptance criteria:** Reason and required responsibility are explicit; correction permits controlled resume.
- **Validation method:** Ambiguity scenarios.
- **Related risks:** RISK-031, RISK-035, RISK-037
- **Related architecture:** ADR-015, ADR-020
- **Related plan items:** PLAN-032, PLAN-035, PLAN-044
- **Status:** Approved baseline

## 11.8 Non-functional requirements

### NFR-009 — Process resilience

- **ID:** NFR-009
- **Title:** Isolate product and orchestration failures
- **Statement:** A runtime/provider failure MUST NOT corrupt Testudo product records, and a temporary Testudo disconnect MUST NOT destroy an executing mission.
- **Rationale:** Long simulation workflows cross process and service boundaries.
- **Source:** SRC-014 §8.4; SRC-015 NFR-002.
- **Priority:** P0
- **Dependencies:** DATA-013, INT-013
- **Acceptance criteria:** Reconnection and checkpoint recovery restore consistent status; duplicate events are safe.
- **Validation method:** Service failure tests.
- **Related risks:** RISK-034, RISK-038
- **Related architecture:** ADR-018, ADR-022
- **Related plan items:** PLAN-038, PLAN-039, PLAN-044
- **Status:** Approved baseline

### NFR-010 — DuckDB volume integrity

- **ID:** NFR-010
- **Title:** Support representative analytical volumes
- **Statement:** DuckDB datasets MUST support representative network, interval, trajectory and comparison volumes without silent loss or corruption.
- **Rationale:** Testudo value depends on real simulation scale.
- **Source:** SRC-015 NFR-001, NFR-005; SRC-016.
- **Priority:** P0
- **Dependencies:** DATA-012
- **Acceptance criteria:** Three volumetry profiles tested; thresholds and degraded modes documented.
- **Validation method:** Load and integrity tests.
- **Related risks:** RISK-039
- **Related architecture:** ADR-016
- **Related plan items:** PLAN-037, PLAN-044
- **Status:** Approved baseline

### NFR-011 — Agent accessibility

- **ID:** NFR-011
- **Title:** Maintain accessible one-agent interaction
- **Statement:** Agent, task, approval and evidence interactions MUST support keyboard use, visible focus and non-colour-only states.
- **Rationale:** The orchestration interface is part of the primary professional journey.
- **Source:** SRC-014 §14; SRC-015 NFR-003.
- **Priority:** P0
- **Dependencies:** BR-008
- **Acceptance criteria:** Main journey passes accessibility audit; progress/error types have textual alternatives.
- **Validation method:** WCAG and user tests.
- **Related risks:** RISK-032
- **Related architecture:** ADR-013
- **Related plan items:** PLAN-034, PLAN-044
- **Status:** Approved baseline

### NFR-012 — Deployment portability

- **ID:** NFR-012
- **Title:** Keep contracts deployable across local and service modes
- **Statement:** Testudo integration contracts MUST work when the Gateway/runtime are in one process and when they are separately deployed.
- **Rationale:** Local modelling environments and production web deployment differ.
- **Source:** SRC-014 §16; inferred architecture need.
- **Priority:** P1
- **Dependencies:** INT-011, INT-013
- **Acceptance criteria:** Same conformance suite passes in both modes; no shared-memory assumption exists in contracts.
- **Validation method:** Deployment matrix tests.
- **Related risks:** RISK-038
- **Related architecture:** ADR-022
- **Related plan items:** PLAN-033, PLAN-044
- **Status:** Approved baseline

### NFR-013 — Approved feature isolation

- **ID:** NFR-013
- **Title:** Preserve subsystem replaceability
- **Statement:** Each integrated external-inspired subsystem MUST be independently disableable and replaceable without changing mission or Testudo contracts.
- **Rationale:** Legal approval permits integration but does not justify architecture coupling.
- **Source:** SRC-016, DEC-012.
- **Priority:** P1
- **Dependencies:** ADR-019
- **Acceptance criteria:** Kill-switch and fallback tests pass; attribution and version are recorded.
- **Validation method:** Contract/failure tests.
- **Related risks:** RISK-040
- **Related architecture:** ADR-019
- **Related plan items:** PLAN-043
- **Status:** Confirmed

## 11.9 Validation requirements

### TEST-021 — One visible agent with internal delegation

- **ID:** TEST-021
- **Title:** Validate hidden role delegation
- **Statement:** The reference journey MUST demonstrate one user-visible conversation while internal role receipts prove Decider, Manager, Worker and Reviewer separation.
- **Rationale:** UX simplification must not erase governance evidence.
- **Source:** BR-008, FR-019.
- **Priority:** P0
- **Dependencies:** BR-008, FR-019
- **Acceptance criteria:** No role-chat switch; internal provenance remains auditable.
- **Validation method:** E2E and audit.
- **Related risks:** RISK-032
- **Related architecture:** ADR-014
- **Related plan items:** PLAN-034, PLAN-044
- **Status:** Approved baseline

### TEST-022 — Active-context tamper and staleness

- **ID:** TEST-022
- **Title:** Validate context authority
- **Statement:** v2 MUST reject altered, expired, unauthorized and stale active-context envelopes.
- **Rationale:** Context is a security and correctness boundary.
- **Source:** FR-015, INT-012.
- **Priority:** P0
- **Dependencies:** FR-015, INT-012
- **Acceptance criteria:** No mission or approval proceeds; the exact reason is visible.
- **Validation method:** Security and state tests.
- **Related risks:** RISK-031, RISK-035
- **Related architecture:** ADR-015
- **Related plan items:** PLAN-032, PLAN-035
- **Status:** Approved baseline

### TEST-023 — Mission/Task/SimulationRun separation

- **ID:** TEST-023
- **Title:** Validate cross-domain identities
- **Statement:** v2 MUST prove that retries, provider attempts and mission recovery do not create or overwrite the wrong SimulationRun.
- **Rationale:** Identity confusion can corrupt business history.
- **Source:** DATA-010.
- **Priority:** P0
- **Dependencies:** DATA-010
- **Acceptance criteria:** IDs and lineage remain correct across retries.
- **Validation method:** Correlation test.
- **Related risks:** RISK-036
- **Related architecture:** ADR-017
- **Related plan items:** PLAN-031, PLAN-039
- **Status:** Approved baseline

### TEST-024 — PostgreSQL/DuckDB placement

- **ID:** TEST-024
- **Title:** Validate persistence ownership
- **Statement:** v2 MUST verify product records, analytical datasets and artifacts are stored only in their approved authority layer.
- **Rationale:** Storage convenience must not override architecture authority.
- **Source:** DATA-011–DATA-013.
- **Priority:** P0
- **Dependencies:** DATA-011–DATA-013
- **Acceptance criteria:** Placement-policy violations fail CI or runtime registration.
- **Validation method:** Schema and integration tests.
- **Related risks:** RISK-033, RISK-039
- **Related architecture:** ADR-016
- **Related plan items:** PLAN-036–PLAN-038
- **Status:** Confirmed

### TEST-025 — Task event replay and recovery

- **ID:** TEST-025
- **Title:** Validate product/runtime state consistency
- **Statement:** v2 MUST reconstruct the same Testudo task state after event replay, duplicate events, runtime restart and checkpoint recovery.
- **Rationale:** Product status cannot be a best-effort reflection.
- **Source:** FR-017, INT-013, NFR-009.
- **Priority:** P0
- **Dependencies:** FR-017, INT-013, NFR-009
- **Acceptance criteria:** No false completion; recovery state is visible.
- **Validation method:** Failure injection and replay.
- **Related risks:** RISK-034, RISK-038
- **Related architecture:** ADR-018
- **Related plan items:** PLAN-038, PLAN-039, PLAN-044
- **Status:** Approved baseline

### TEST-026 — Project responsibility approvals

- **ID:** TEST-026
- **Title:** Validate human authority matrix
- **Statement:** v2 MUST test Run Owner, Technical Reviewer, Publication Approver, Data/Model Owner and Administrator positive and negative authority cases.
- **Rationale:** Each material decision has a distinct accountable actor.
- **Source:** HITL-011–HITL-014.
- **Priority:** P0
- **Dependencies:** HITL-011–HITL-014
- **Acceptance criteria:** Each action accepts only its authorized responsibility; no agent-authored consent.
- **Validation method:** Permission matrix tests.
- **Related risks:** RISK-035
- **Related architecture:** ADR-020
- **Related plan items:** PLAN-035, PLAN-044
- **Status:** Approved baseline

### TEST-027 — Partial DuckDB result registration

- **ID:** TEST-027
- **Title:** Validate partial analytical outputs
- **Statement:** v2 MUST register and display partial, invalid, missing and complete result datasets without misrepresenting completeness.
- **Rationale:** Partial results are a normal operational state.
- **Source:** FR-021, INT-015.
- **Priority:** P0
- **Dependencies:** FR-021, INT-015
- **Acceptance criteria:** Publication/comparison restrictions follow dataset state.
- **Validation method:** Dataset failure scenarios.
- **Related risks:** RISK-037, RISK-039
- **Related architecture:** ADR-016, ADR-021
- **Related plan items:** PLAN-037, PLAN-040
- **Status:** Approved baseline

### TEST-028 — Finding and publication separation

- **ID:** TEST-028
- **Title:** Validate business review transitions
- **Statement:** v2 MUST prove mission acceptance, technical finding review and publication approval are separate transitions and actors.
- **Rationale:** Technical success is not a human decision or client release.
- **Source:** FR-022, FR-023.
- **Priority:** P0
- **Dependencies:** FR-022, FR-023
- **Acceptance criteria:** Skipping a stage fails; versions and actors are retained.
- **Validation method:** Workflow E2E.
- **Related risks:** RISK-037
- **Related architecture:** ADR-021
- **Related plan items:** PLAN-041, PLAN-042, PLAN-044
- **Status:** Approved baseline

### TEST-029 — Cross-store publication lineage

- **ID:** TEST-029
- **Title:** Validate end-to-end provenance
- **Statement:** A publication MUST trace to PostgreSQL product records, DuckDB datasets and immutable artifacts after active data changes.
- **Rationale:** Data separation cannot weaken reproducibility.
- **Source:** DATA-016, OBS-012.
- **Priority:** P0
- **Dependencies:** DATA-016, OBS-012
- **Acceptance criteria:** Frozen publication remains unchanged; stale or missing references are flagged.
- **Validation method:** Lineage audit.
- **Related risks:** RISK-033, RISK-037
- **Related architecture:** ADR-016, ADR-021
- **Related plan items:** PLAN-041, PLAN-042
- **Status:** Approved baseline

### TEST-030 — Approved subsystem isolation

- **ID:** TEST-030
- **Title:** Validate DEC-012 integrations
- **Statement:** Each DEC-012 subsystem integration MUST pass attribution, contract, security, disable and fallback tests.
- **Rationale:** Approved reuse still requires operational independence.
- **Source:** DEC-012, NFR-013.
- **Priority:** P1
- **Dependencies:** NFR-013
- **Acceptance criteria:** Disabling the subsystem does not corrupt state or change the Testudo API.
- **Validation method:** Component and chaos tests.
- **Related risks:** RISK-040
- **Related architecture:** ADR-019
- **Related plan items:** PLAN-043
- **Status:** Confirmed

### TEST-031 — Local and separated deployment modes

- **ID:** TEST-031
- **Title:** Validate deployment portability
- **Statement:** The same reference mission MUST pass in local in-process mode and separated service mode.
- **Rationale:** Development and production topologies differ.
- **Source:** NFR-012.
- **Priority:** P1
- **Dependencies:** NFR-012
- **Acceptance criteria:** Contract behavior and receipts are equivalent; cancellation and restart work.
- **Validation method:** Deployment matrix.
- **Related risks:** RISK-038
- **Related architecture:** ADR-022
- **Related plan items:** PLAN-033, PLAN-044
- **Status:** Approved baseline

### TEST-032 — Testudo vertical slice

- **ID:** TEST-032
- **Title:** Validate the full product journey
- **Statement:** v2 MUST pass a representative project journey from context confirmation through simulation, result analysis, technical finding and approved publication.
- **Rationale:** The architecture must prove business continuity, not isolated APIs.
- **Source:** SRC-014 §5, §8–§10; SRC-015 TEST-001–TEST-004.
- **Priority:** P0
- **Dependencies:** BR-007–BR-010, FR-015–FR-023
- **Acceptance criteria:** One project and conversation; explicit launch approval; persistent task; DuckDB result; evidence-linked finding; Technical Reviewer action; Project Manager publication approval; full lineage and recovery proof.
- **Validation method:** Automated E2E plus Transport Modeller and Project Manager user test.
- **Related risks:** RISK-031–RISK-039
- **Related architecture:** ADR-013–ADR-022
- **Related plan items:** PLAN-044
- **Status:** Approved baseline

## 6. Rendering-modelling and pipeline-control-plane requirements

### BR-011 — Govern the complete pipeline lifecycle

**Statement:** The system MUST govern pipeline planning, implementation, version activation and operation as distinct activities.  
**Rationale:** Different activities require different authorities and evidence.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** ADR-023–ADR-025  

**Acceptance criteria:**
- Planning occurs without production writes.
- Operation requires an active immutable version.
- Mode and authority are visible in receipts.

**Validation method:** Lifecycle and authorization tests  
**Related risks:** RISK-041,RISK-050  
**Related architecture:** ADR-023–ADR-025  
**Related plan items:** PLAN-046–PLAN-049,PLAN-056,PLAN-066  
**Status:** Approved baseline

### BR-012 — Preserve backend ownership

**Statement:** `modeller-agents` MUST NOT own or duplicate backend-specific extraction, simulation or rendering implementation.  
**Rationale:** Centralizing backend logic recreates coupling.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-001,ADR-023  

**Acceptance criteria:**
- Definitions reference owning repositories and entrypoints.
- No Aimsun/SQLite/APA/FZP implementation enters orchestration core.

**Validation method:** Boundary/import tests  
**Related risks:** RISK-041,RISK-047  
**Related architecture:** ADR-023  
**Related plan items:** PLAN-046–PLAN-048,PLAN-057  
**Status:** Approved baseline

### BR-013 — Use one canonical analytical truth

**Statement:** Every declared rendering and publication output MUST derive from a validated canonical dataset.  
**Rationale:** Independent raw-source paths create inconsistent decisions.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** ADR-026,ADR-028  

**Acceptance criteria:**
- Artifacts declare dataset digest and metric/query lineage.
- Compatibility paths are feature-flagged and parity-tested.

**Validation method:** Lineage/parity audit  
**Related risks:** RISK-042,RISK-043  
**Related architecture:** ADR-026,ADR-028  
**Related plan items:** PLAN-060,PLAN-061  
**Status:** Approved baseline

### BR-014 — Support reproducible presentation packages

**Statement:** The rendering-modelling profile MUST produce declared HTML, screenshots, Excel, report and GeoLibre outputs or explicit residual statuses.  
**Rationale:** Business value includes analysis and handover.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-013  

**Acceptance criteria:**
- Artifact set is versioned and content-addressed.
- Missing required surface blocks completion unless approved residual.

**Validation method:** Artifact-package E2E  
**Related risks:** RISK-043–RISK-045  
**Related architecture:** ADR-028,ADR-030  
**Related plan items:** PLAN-059–PLAN-065  
**Status:** Approved baseline

### BR-015 — Separate product registry and payload

**Statement:** Testudo/PostgreSQL MUST register runs, datasets, artifacts, tasks and lineage without copying bulk simulation rows.  
**Rationale:** Authority and analytics have different storage needs.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** ADR-016,ADR-026,ADR-027  

**Acceptance criteria:**
- PostgreSQL contains references and summaries.
- DuckDB/Parquet contains bulk data.

**Validation method:** Placement/volume tests  
**Related risks:** RISK-033,RISK-039,RISK-046  
**Related architecture:** ADR-026,ADR-027  
**Related plan items:** PLAN-060,PLAN-071,PLAN-072  
**Status:** Approved baseline

### BR-016 — Preserve honest acceptance

**Statement:** The system MUST distinguish source implementation, contract, integration and licensed live-pilot proof.  
**Rationale:** Unavailable environments must not create false pass or blanket failure.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** ADR-032  

**Acceptance criteria:**
- Each dimension has independent status/evidence.
- Live pass requires literal run evidence.
- Unavailable environment creates residual with closure command.

**Validation method:** Acceptance-state tests  
**Related risks:** RISK-051  
**Related architecture:** ADR-032  
**Related plan items:** PLAN-053,PLAN-064,PLAN-065  
**Status:** Approved baseline

### FR-025 — Create a pipeline definition

**Statement:** The system MUST create and validate a versioned PipelineDefinition with owner, purpose, repositories, stages, contracts, modes, entrypoints and outputs.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Create a pipeline definition is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** PipelineDefinition schema tests  
**Related risks:** RISK-041  
**Related architecture:** ADR-023,ADR-025  
**Related plan items:** PLAN-046–PLAN-048  
**Status:** Approved baseline

### FR-026 — Plan a pipeline

**Statement:** The Planner MUST produce a PipelinePlan covering sources, stage DAG, data contracts, reuse, capabilities, tests, approvals, rollout, rollback and residuals without modifying production code.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Plan a pipeline is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Plan-mode E2E  
**Related risks:** RISK-041,RISK-047  
**Related architecture:** ADR-024  
**Related plan items:** PLAN-049–PLAN-054  
**Status:** Approved baseline

### FR-027 — Inventory source locations

**Statement:** Recon MUST enumerate all plausible model, config, database, path and trajectory source locations and identify the authority for each.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Inventory source locations is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Recon tests  
**Related risks:** RISK-042  
**Related architecture:** ADR-029  
**Related plan items:** PLAN-050  
**Status:** Approved baseline

### FR-028 — Map pipeline dependencies

**Statement:** The Planner MUST represent stage and cross-repository dependencies as machine-readable edges.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Map pipeline dependencies is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** DAG tests  
**Related risks:** RISK-041,RISK-049  
**Related architecture:** ADR-023  
**Related plan items:** PLAN-051  
**Status:** Approved baseline

### FR-029 — Resolve capability gaps

**Statement:** The system MUST record each required capability as exact, substituted, unavailable or deferred with selected catalog entry and reason.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Resolve capability gaps is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Capability tests  
**Related risks:** RISK-047  
**Related architecture:** ADR-033  
**Related plan items:** PLAN-052,PLAN-058,PLAN-059  
**Status:** Approved baseline

### FR-030 — Authorize pipeline implementation

**Statement:** Builder mode MUST start only from fresh explicit authorization bound to the approved plan and baseline.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Authorize pipeline implementation is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Consent/digest tests  
**Related risks:** RISK-049,RISK-050  
**Related architecture:** ADR-024,ADR-034  
**Related plan items:** PLAN-055,PLAN-056  
**Status:** Approved baseline

### FR-031 — Create bounded implementation work orders

**Statement:** The Builder MUST create stage-specific work orders with repository, write scope, contract, environment, tests, rollback and prohibited actions.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Create bounded implementation work orders is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Work-order tests  
**Related risks:** RISK-047,RISK-050  
**Related architecture:** ADR-024  
**Related plan items:** PLAN-057  
**Status:** Approved baseline

### FR-032 — Re-gate worker output

**Statement:** The orchestrator MUST rerun required static, unit, contract, parity and integration gates after ingesting implementation output.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Re-gate worker output is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Tampered receipt tests  
**Related risks:** RISK-043,RISK-050  
**Related architecture:** ADR-028,ADR-034  
**Related plan items:** PLAN-060–PLAN-062  
**Status:** Approved baseline

### FR-033 — Register an immutable pipeline version

**Statement:** The system MUST register only an accepted implementation as an immutable PipelineVersion with exact source, contracts, dependencies, entrypoint and tests.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Register an immutable pipeline version is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Activation tests  
**Related risks:** RISK-041  
**Related architecture:** ADR-025  
**Related plan items:** PLAN-063  
**Status:** Approved baseline

### FR-034 — Discover applicable pipelines

**Statement:** Testudo SHOULD present registered pipelines as business workflows filtered by active context, prerequisites and responsibility.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P1  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Discover applicable pipelines is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Discovery UX tests  
**Related risks:** RISK-048  
**Related architecture:** ADR-023,ADR-031  
**Related plan items:** PLAN-067  
**Status:** Approved baseline

### FR-035 — Prepare a pipeline run

**Statement:** Operator mode MUST prepare a PipelineRunRequest including active context, version, inputs, source permissions, stages, resources, outputs and effects.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Prepare a pipeline run is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Run-request tests  
**Related risks:** RISK-052  
**Related architecture:** ADR-031  
**Related plan items:** PLAN-068  
**Status:** Approved baseline

### FR-036 — Approve a pipeline run

**Statement:** The system MUST obtain configured Run Owner and Data/Model Owner approvals before sensitive or costly execution.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Approve a pipeline run is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Approval tests  
**Related risks:** RISK-052  
**Related architecture:** ADR-031  
**Related plan items:** PLAN-069  
**Status:** Approved baseline

### FR-037 — Execute only registered versions

**Statement:** Operator mode MUST invoke only the registered entrypoint and dependency set of the selected active PipelineVersion.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Execute only registered versions is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Negative entrypoint tests  
**Related risks:** RISK-050,RISK-053  
**Related architecture:** ADR-025,ADR-031  
**Related plan items:** PLAN-066,PLAN-070  
**Status:** Approved baseline

### FR-038 — Track stage lifecycle

**Statement:** The system MUST track preparation, waiting, execution, partial, completion, failure, cancellation and recovery per stage.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Track stage lifecycle is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** State/replay tests  
**Related risks:** RISK-053  
**Related architecture:** ADR-018,ADR-023  
**Related plan items:** PLAN-070  
**Status:** Approved baseline

### FR-039 — Register partial datasets

**Statement:** The system MUST register available, missing, invalid and processing dataset partitions and authorized uses.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Register partial datasets is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Failure-injection tests  
**Related risks:** RISK-042,RISK-053  
**Related architecture:** ADR-026,ADR-027  
**Related plan items:** PLAN-071  
**Status:** Approved baseline

### FR-040 — Generate HTML from canonical data

**Statement:** The profile MUST generate HTML from canonical DuckDB queries after canonical mode activation.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Generate HTML from canonical data is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** HTML/DuckDB parity tests  
**Related risks:** RISK-043  
**Related architecture:** ADR-028  
**Related plan items:** PLAN-061,PLAN-064  
**Status:** Approved baseline

### FR-041 — Generate deterministic screenshots

**Statement:** The profile MUST render screenshots with render-ready, empty-layer and WebGL-error detection and a populated manifest.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Generate deterministic screenshots is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Headless rendering E2E  
**Related risks:** RISK-044  
**Related architecture:** ADR-028  
**Related plan items:** PLAN-059,PLAN-061,PLAN-064  
**Status:** Approved baseline

### FR-042 — Generate Excel and reports

**Statement:** The profile MUST generate Excel and evidence-linked report pages from canonical data with units, periods, aggregation and citations.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Generate Excel and reports is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Workbook/report tests  
**Related risks:** RISK-043,RISK-044  
**Related architecture:** ADR-028  
**Related plan items:** PLAN-059,PLAN-061  
**Status:** Approved baseline

### FR-043 — Generate a GeoLibre package

**Statement:** The profile MUST generate a versioned DuckDB/Parquet GeoLibre package with WGS84 geometry, views, compatibility metadata and degraded mode.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Generate a GeoLibre package is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Package/UI tests  
**Related risks:** RISK-045  
**Related architecture:** ADR-030  
**Related plan items:** PLAN-059,PLAN-073  
**Status:** Approved baseline

### FR-044 — Publish outputs to Testudo

**Statement:** The system MUST transactionally register the SimulationRun, dataset manifests, artifact references, summaries and task outcome in PostgreSQL.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Publish outputs to Testudo is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** API idempotency tests  
**Related risks:** RISK-048  
**Related architecture:** ADR-027  
**Related plan items:** PLAN-072  
**Status:** Approved baseline

### FR-045 — Submit governed learning candidates

**Statement:** The pipeline MAY submit evidence-linked candidates but MUST NOT automatically promote them to accepted knowledge.  
**Rationale:** A reusable pipeline control plane requires this observable function.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P1  
**Dependencies:** BR-011–BR-016  

**Acceptance criteria:**
- Submit governed learning candidates is represented in a typed artifact or receipt.
- Failure and unauthorized paths are explicit.

**Validation method:** Knowledge seam tests  
**Related risks:** RISK-055  
**Related architecture:** ADR-023  
**Related plan items:** PLAN-074,PLAN-075  
**Status:** Approved baseline

### DATA-017 — Pipeline identity

**Statement:** Stable distinct identifiers MUST exist for PipelineDefinition, PipelineVersion, PipelinePlan and PipelineRunRequest.  
**Rationale:** The rendering and publication lifecycle requires auditable data semantics.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-013–BR-016  

**Acceptance criteria:**
- Pipeline identity is machine-readable and versioned.
- References remain resolvable or explicitly missing.

**Validation method:** Identity/schema tests  
**Related risks:** RISK-041  
**Related architecture:** ADR-025  
**Related plan items:** PLAN-046–PLAN-048  
**Status:** Approved baseline

### DATA-018 — Stage identity

**Statement:** Every stage MUST have stable ID, owner, inputs, outputs, retry and failure semantics.  
**Rationale:** The rendering and publication lifecycle requires auditable data semantics.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-013–BR-016  

**Acceptance criteria:**
- Stage identity is machine-readable and versioned.
- References remain resolvable or explicitly missing.

**Validation method:** DAG/schema tests  
**Related risks:** RISK-041  
**Related architecture:** ADR-023  
**Related plan items:** PLAN-051  
**Status:** Approved baseline

### DATA-019 — Source receipt

**Statement:** Every extraction MUST record source type, reference, digest where applicable, method, time, environment and quality.  
**Rationale:** The rendering and publication lifecycle requires auditable data semantics.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-013–BR-016  

**Acceptance criteria:**
- Source receipt is machine-readable and versioned.
- References remain resolvable or explicitly missing.

**Validation method:** Source-lineage tests  
**Related risks:** RISK-042  
**Related architecture:** ADR-029  
**Related plan items:** PLAN-050,PLAN-060  
**Status:** Approved baseline

### DATA-020 — Canonical dataset manifest

**Statement:** Every canonical package MUST declare schemas, tables/views, partitions, sources, quality, completeness, digests and reference queries.  
**Rationale:** The rendering and publication lifecycle requires auditable data semantics.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-013–BR-016  

**Acceptance criteria:**
- Canonical dataset manifest is machine-readable and versioned.
- References remain resolvable or explicitly missing.

**Validation method:** Manifest tests  
**Related risks:** RISK-042  
**Related architecture:** ADR-026  
**Related plan items:** PLAN-060  
**Status:** Approved baseline

### DATA-021 — DuckDB canonical package

**Statement:** Structured simulation metrics and network data MUST use a versioned DuckDB package for rendering-modelling.  
**Rationale:** The rendering and publication lifecycle requires auditable data semantics.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-013–BR-016  

**Acceptance criteria:**
- DuckDB canonical package is machine-readable and versioned.
- References remain resolvable or explicitly missing.

**Validation method:** Schema/query tests  
**Related risks:** RISK-039,RISK-042  
**Related architecture:** ADR-026  
**Related plan items:** PLAN-060,PLAN-064  
**Status:** Approved baseline

### DATA-022 — Parquet bulk partitions

**Statement:** Large trajectory/path point datasets SHOULD use partitioned Parquet referenced by DuckDB views/indexes.  
**Rationale:** The rendering and publication lifecycle requires auditable data semantics.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-013–BR-016  

**Acceptance criteria:**
- Parquet bulk partitions is machine-readable and versioned.
- References remain resolvable or explicitly missing.

**Validation method:** Streaming/partition tests  
**Related risks:** RISK-046  
**Related architecture:** ADR-026  
**Related plan items:** PLAN-058,PLAN-060  
**Status:** Approved baseline

### DATA-023 — Null and quality semantics

**Statement:** Missing values MUST remain null with explicit quality status and MUST NOT be silently coerced to zero.  
**Rationale:** The rendering and publication lifecycle requires auditable data semantics.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-013–BR-016  

**Acceptance criteria:**
- Null and quality semantics is machine-readable and versioned.
- References remain resolvable or explicitly missing.

**Validation method:** Quality tests  
**Related risks:** RISK-042,RISK-043  
**Related architecture:** ADR-026  
**Related plan items:** PLAN-060  
**Status:** Approved baseline

### DATA-024 — Metric definition

**Statement:** Every KPI MUST declare definition, unit, aggregation, period, query, comparability and limitations.  
**Rationale:** The rendering and publication lifecycle requires auditable data semantics.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-013–BR-016  

**Acceptance criteria:**
- Metric definition is machine-readable and versioned.
- References remain resolvable or explicitly missing.

**Validation method:** Metric tests  
**Related risks:** RISK-043  
**Related architecture:** ADR-028  
**Related plan items:** PLAN-061  
**Status:** Approved baseline

### DATA-025 — Artifact manifest

**Statement:** Every artifact MUST record type, URI, digest, dataset digest, generator, parameters, queries, quality and visibility.  
**Rationale:** The rendering and publication lifecycle requires auditable data semantics.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-013–BR-016  

**Acceptance criteria:**
- Artifact manifest is machine-readable and versioned.
- References remain resolvable or explicitly missing.

**Validation method:** Artifact schema tests  
**Related risks:** RISK-043,RISK-044  
**Related architecture:** ADR-028  
**Related plan items:** PLAN-061,PLAN-072  
**Status:** Approved baseline

### DATA-026 — Screenshot view definition

**Statement:** Every screenshot MUST record view, camera/extent, run, interval, metric, palette, layers, legend, resolution, timestamp and digest.  
**Rationale:** The rendering and publication lifecycle requires auditable data semantics.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-013–BR-016  

**Acceptance criteria:**
- Screenshot view definition is machine-readable and versioned.
- References remain resolvable or explicitly missing.

**Validation method:** Screenshot-manifest tests  
**Related risks:** RISK-044  
**Related architecture:** ADR-028  
**Related plan items:** PLAN-059,PLAN-061  
**Status:** Approved baseline

### DATA-027 — Cross-surface parity record

**Statement:** The system MUST store parity assertions/results for every metric shared across surfaces.  
**Rationale:** The rendering and publication lifecycle requires auditable data semantics.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-013–BR-016  

**Acceptance criteria:**
- Cross-surface parity record is machine-readable and versioned.
- References remain resolvable or explicitly missing.

**Validation method:** Parity-record tests  
**Related risks:** RISK-043  
**Related architecture:** ADR-028  
**Related plan items:** PLAN-061  
**Status:** Approved baseline

### DATA-028 — Product registration record

**Statement:** PostgreSQL MUST store references, digests, summaries, permissions and lineage without bulk rows.  
**Rationale:** The rendering and publication lifecycle requires auditable data semantics.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-013–BR-016  

**Acceptance criteria:**
- Product registration record is machine-readable and versioned.
- References remain resolvable or explicitly missing.

**Validation method:** Placement/API tests  
**Related risks:** RISK-033,RISK-048  
**Related architecture:** ADR-027  
**Related plan items:** PLAN-071,PLAN-072  
**Status:** Approved baseline

### DATA-029 — Residual proof record

**Statement:** Unexecuted live-model, GeoLibre UI or Testudo-write proof MUST be typed with reason, owner and closure action.  
**Rationale:** The rendering and publication lifecycle requires auditable data semantics.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-013–BR-016  

**Acceptance criteria:**
- Residual proof record is machine-readable and versioned.
- References remain resolvable or explicitly missing.

**Validation method:** Residual tests  
**Related risks:** RISK-051  
**Related architecture:** ADR-032  
**Related plan items:** PLAN-053,PLAN-065  
**Status:** Approved baseline

### DATA-030 — Learning candidate evidence

**Statement:** A candidate MUST reference calibration/run, dataset, KPIs, scope, limitations, reviewer and source events.  
**Rationale:** The rendering and publication lifecycle requires auditable data semantics.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** BR-013–BR-016  

**Acceptance criteria:**
- Learning candidate evidence is machine-readable and versioned.
- References remain resolvable or explicitly missing.

**Validation method:** Candidate tests  
**Related risks:** RISK-055  
**Related architecture:** ADR-023  
**Related plan items:** PLAN-074  
**Status:** Approved baseline

### INT-019 — Pipeline registry integration

**Statement:** `modeller-agents` MUST load definitions and versions through a versioned registry interface.  
**Rationale:** Contracts keep orchestration independent from implementation details.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** FR-025–FR-045  

**Acceptance criteria:**
- Pipeline registry integration uses a versioned interface.
- Failure returns structured evidence without authority inflation.

**Validation method:** Registry integration tests  
**Related risks:** RISK-041  
**Related architecture:** ADR-023,ADR-025  
**Related plan items:** PLAN-048  
**Status:** Approved baseline

### INT-020 — Repository adapter

**Statement:** Builder mode MUST interact with repositories through bounded source/read/write/test interfaces.  
**Rationale:** Contracts keep orchestration independent from implementation details.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** FR-025–FR-045  

**Acceptance criteria:**
- Repository adapter uses a versioned interface.
- Failure returns structured evidence without authority inflation.

**Validation method:** Adapter/path tests  
**Related risks:** RISK-049,RISK-050  
**Related architecture:** ADR-023,ADR-034  
**Related plan items:** PLAN-055–PLAN-062  
**Status:** Approved baseline

### INT-021 — Source adapter interface

**Statement:** Source adapters MUST expose inventory, probe, extract and receipt operations with environment requirements.  
**Rationale:** Contracts keep orchestration independent from implementation details.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** FR-025–FR-045  

**Acceptance criteria:**
- Source adapter interface uses a versioned interface.
- Failure returns structured evidence without authority inflation.

**Validation method:** Adapter conformance tests  
**Related risks:** RISK-042,RISK-047  
**Related architecture:** ADR-029  
**Related plan items:** PLAN-058  
**Status:** Approved baseline

### INT-022 — DuckDB/Parquet interface

**Statement:** The runtime MUST validate dataset manifests and reference queries without embedding pipeline-specific SQL.  
**Rationale:** Contracts keep orchestration independent from implementation details.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** FR-025–FR-045  

**Acceptance criteria:**
- DuckDB/Parquet interface uses a versioned interface.
- Failure returns structured evidence without authority inflation.

**Validation method:** Data contract tests  
**Related risks:** RISK-042  
**Related architecture:** ADR-026  
**Related plan items:** PLAN-060  
**Status:** Approved baseline

### INT-023 — Artifact generator interface

**Statement:** Artifact producers MUST accept a dataset manifest and return ArtifactManifest plus evidence.  
**Rationale:** Contracts keep orchestration independent from implementation details.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** FR-025–FR-045  

**Acceptance criteria:**
- Artifact generator interface uses a versioned interface.
- Failure returns structured evidence without authority inflation.

**Validation method:** Generator conformance tests  
**Related risks:** RISK-043,RISK-044  
**Related architecture:** ADR-028  
**Related plan items:** PLAN-059,PLAN-061  
**Status:** Approved baseline

### INT-024 — Headless rendering subsystem

**Statement:** Screenshot automation MUST be isolated behind an approved subsystem with timeout and render evidence.  
**Rationale:** Contracts keep orchestration independent from implementation details.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** FR-025–FR-045  

**Acceptance criteria:**
- Headless rendering subsystem uses a versioned interface.
- Failure returns structured evidence without authority inflation.

**Validation method:** Subsystem tests  
**Related risks:** RISK-044,RISK-047  
**Related architecture:** ADR-019,ADR-033  
**Related plan items:** PLAN-059,PLAN-061  
**Status:** Approved baseline

### INT-025 — GeoLibre adapter

**Statement:** GeoLibre MUST query the canonical package and expose version/degraded-mode information to Testudo.  
**Rationale:** Contracts keep orchestration independent from implementation details.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** FR-025–FR-045  

**Acceptance criteria:**
- GeoLibre adapter uses a versioned interface.
- Failure returns structured evidence without authority inflation.

**Validation method:** Package/UI contract tests  
**Related risks:** RISK-045  
**Related architecture:** ADR-030  
**Related plan items:** PLAN-073  
**Status:** Approved baseline

### INT-026 — Testudo pipeline API

**Statement:** Testudo MUST expose APIs for discovery, run preparation, approval, events, registration and recovery.  
**Rationale:** Contracts keep orchestration independent from implementation details.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** FR-025–FR-045  

**Acceptance criteria:**
- Testudo pipeline API uses a versioned interface.
- Failure returns structured evidence without authority inflation.

**Validation method:** API tests  
**Related risks:** RISK-048,RISK-053  
**Related architecture:** ADR-022,ADR-027  
**Related plan items:** PLAN-067–PLAN-072  
**Status:** Approved baseline

### INT-027 — Licensed runtime adapter

**Statement:** Aimsun/aconsole execution MUST use an environment adapter returning literal logs, exit status and outputs.  
**Rationale:** Contracts keep orchestration independent from implementation details.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** FR-025–FR-045  

**Acceptance criteria:**
- Licensed runtime adapter uses a versioned interface.
- Failure returns structured evidence without authority inflation.

**Validation method:** Fake/live adapter tests  
**Related risks:** RISK-051,RISK-053  
**Related architecture:** ADR-032  
**Related plan items:** PLAN-065,PLAN-070  
**Status:** Approved baseline

### INT-028 — Excel/report dependencies

**Statement:** Excel and report libraries MUST be pinned, attributed and isolated from orchestration state.  
**Rationale:** Contracts keep orchestration independent from implementation details.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P1  
**Dependencies:** FR-025–FR-045  

**Acceptance criteria:**
- Excel/report dependencies uses a versioned interface.
- Failure returns structured evidence without authority inflation.

**Validation method:** Dependency/SBOM tests  
**Related risks:** RISK-047  
**Related architecture:** ADR-019,ADR-033  
**Related plan items:** PLAN-059  
**Status:** Approved baseline

### INT-029 — Knowledge transport interface

**Statement:** Candidate transport MUST target only governed intake and return a receipt; acceptance remains external.  
**Rationale:** Contracts keep orchestration independent from implementation details.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** FR-025–FR-045  

**Acceptance criteria:**
- Knowledge transport interface uses a versioned interface.
- Failure returns structured evidence without authority inflation.

**Validation method:** Knowledge boundary tests  
**Related risks:** RISK-055  
**Related architecture:** ADR-023  
**Related plan items:** PLAN-074  
**Status:** Approved baseline

### INT-030 — Compatibility exporter

**Statement:** The system SHOULD support old export formats through explicit adapters and deprecation metadata.  
**Rationale:** Contracts keep orchestration independent from implementation details.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P1  
**Dependencies:** FR-025–FR-045  

**Acceptance criteria:**
- Compatibility exporter uses a versioned interface.
- Failure returns structured evidence without authority inflation.

**Validation method:** Compatibility tests  
**Related risks:** RISK-045  
**Related architecture:** ADR-030  
**Related plan items:** PLAN-064  
**Status:** Approved baseline

### SEC-014 — Pipeline mode least privilege

**Statement:** Capabilities MUST be granted by mode and stage; operate mode MUST NOT receive repository write tools.  
**Rationale:** Pipeline automation expands access to models, datasets and publication surfaces.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** SEC-001–SEC-013  

**Acceptance criteria:**
- Pipeline mode least privilege is enforced server-side or by policy.
- Denied attempts are logged without leaking metadata.

**Validation method:** Negative permission tests  
**Related risks:** RISK-050  
**Related architecture:** ADR-024,ADR-031  
**Related plan items:** PLAN-049,PLAN-056,PLAN-066  
**Status:** Approved baseline

### SEC-015 — Source data authorization

**Statement:** Every source probe/extraction MUST enforce user/project and Data/Model Owner permissions.  
**Rationale:** Pipeline automation expands access to models, datasets and publication surfaces.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** SEC-001–SEC-013  

**Acceptance criteria:**
- Source data authorization is enforced server-side or by policy.
- Denied attempts are logged without leaking metadata.

**Validation method:** Authorization tests  
**Related risks:** RISK-052,RISK-054  
**Related architecture:** ADR-029  
**Related plan items:** PLAN-050,PLAN-068,PLAN-069  
**Status:** Approved baseline

### SEC-016 — External rendering/publication control

**Statement:** Any browser, external model, remote service or publication transmission MUST be declared and authorized.  
**Rationale:** Pipeline automation expands access to models, datasets and publication surfaces.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** SEC-001–SEC-013  

**Acceptance criteria:**
- External rendering/publication control is enforced server-side or by policy.
- Denied attempts are logged without leaking metadata.

**Validation method:** DLP/external-call tests  
**Related risks:** RISK-044,RISK-052,RISK-054  
**Related architecture:** ADR-031  
**Related plan items:** PLAN-059,PLAN-069,PLAN-072  
**Status:** Approved baseline

### SEC-017 — Artifact sensitivity propagation

**Statement:** Dataset/artifact sensitivity MUST derive from sources and may only be lowered by authorized declassification.  
**Rationale:** Pipeline automation expands access to models, datasets and publication surfaces.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** SEC-001–SEC-013  

**Acceptance criteria:**
- Artifact sensitivity propagation is enforced server-side or by policy.
- Denied attempts are logged without leaking metadata.

**Validation method:** Sensitivity tests  
**Related risks:** RISK-054  
**Related architecture:** ADR-027,ADR-029  
**Related plan items:** PLAN-060,PLAN-061,PLAN-072  
**Status:** Approved baseline

### SEC-018 — Dependency and subsystem integrity

**Statement:** Pipeline versions MUST pin dependencies/subsystems and expose attribution, SBOM and kill-switch status.  
**Rationale:** Pipeline automation expands access to models, datasets and publication surfaces.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** SEC-001–SEC-013  

**Acceptance criteria:**
- Dependency and subsystem integrity is enforced server-side or by policy.
- Denied attempts are logged without leaking metadata.

**Validation method:** Supply-chain tests  
**Related risks:** RISK-047  
**Related architecture:** ADR-019,ADR-033  
**Related plan items:** PLAN-052,PLAN-058,PLAN-059,PLAN-063  
**Status:** Approved baseline

### OBS-014 — Pipeline planning telemetry

**Statement:** The system SHOULD record recon budget, sources, decisions, gaps and review iterations.  
**Rationale:** Reliability and value require structured measurements.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P1  
**Dependencies:** OBS-001–OBS-013  

**Acceptance criteria:**
- Pipeline planning telemetry is correlated to project, task, mission, version and run.
- Sensitive fields are redacted.

**Validation method:** Planning telemetry tests  
**Related risks:** RISK-041,RISK-047  
**Related architecture:** ADR-023  
**Related plan items:** PLAN-049–PLAN-054  
**Status:** Approved baseline

### OBS-015 — Implementation telemetry

**Statement:** The system MUST record baseline, dispatches, file changes, gates, invalidations, residuals and integration.  
**Rationale:** Reliability and value require structured measurements.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** OBS-001–OBS-013  

**Acceptance criteria:**
- Implementation telemetry is correlated to project, task, mission, version and run.
- Sensitive fields are redacted.

**Validation method:** Ledger tests  
**Related risks:** RISK-049,RISK-050  
**Related architecture:** ADR-034  
**Related plan items:** PLAN-055–PLAN-064  
**Status:** Approved baseline

### OBS-016 — Stage execution telemetry

**Statement:** The system MUST record stage start/end, resources, progress, warnings, errors, retries and outputs.  
**Rationale:** Reliability and value require structured measurements.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** OBS-001–OBS-013  

**Acceptance criteria:**
- Stage execution telemetry is correlated to project, task, mission, version and run.
- Sensitive fields are redacted.

**Validation method:** Event tests  
**Related risks:** RISK-053  
**Related architecture:** ADR-023  
**Related plan items:** PLAN-070  
**Status:** Approved baseline

### OBS-017 — Dataset quality telemetry

**Statement:** The system MUST expose row/partition counts, null/quality distributions, coverage and partial status.  
**Rationale:** Reliability and value require structured measurements.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** OBS-001–OBS-013  

**Acceptance criteria:**
- Dataset quality telemetry is correlated to project, task, mission, version and run.
- Sensitive fields are redacted.

**Validation method:** Data telemetry tests  
**Related risks:** RISK-042,RISK-046  
**Related architecture:** ADR-026  
**Related plan items:** PLAN-060,PLAN-071  
**Status:** Approved baseline

### OBS-018 — Artifact telemetry

**Statement:** The system MUST record generator version, duration, render readiness, failures, parity and digests.  
**Rationale:** Reliability and value require structured measurements.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** OBS-001–OBS-013  

**Acceptance criteria:**
- Artifact telemetry is correlated to project, task, mission, version and run.
- Sensitive fields are redacted.

**Validation method:** Artifact telemetry tests  
**Related risks:** RISK-043,RISK-044  
**Related architecture:** ADR-028  
**Related plan items:** PLAN-061  
**Status:** Approved baseline

### OBS-019 — Cross-store reconciliation

**Statement:** The system MUST reconcile mission ledger, Testudo Task, PostgreSQL registry and manifests.  
**Rationale:** Reliability and value require structured measurements.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** OBS-001–OBS-013  

**Acceptance criteria:**
- Cross-store reconciliation is correlated to project, task, mission, version and run.
- Sensitive fields are redacted.

**Validation method:** Replay tests  
**Related risks:** RISK-048,RISK-053  
**Related architecture:** ADR-018,ADR-027  
**Related plan items:** PLAN-071,PLAN-072  
**Status:** Approved baseline

### OBS-020 — Pipeline outcome KPIs

**Statement:** The system SHOULD measure plan time, rework, run success, acceptance, parity, recovery and review latency.  
**Rationale:** Reliability and value require structured measurements.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P1  
**Dependencies:** OBS-001–OBS-013  

**Acceptance criteria:**
- Pipeline outcome KPIs is correlated to project, task, mission, version and run.
- Sensitive fields are redacted.

**Validation method:** KPI dashboard tests  
**Related risks:** RISK-041  
**Related architecture:** ADR-023  
**Related plan items:** PLAN-075  
**Status:** Approved baseline

### HITL-016 — Approve pipeline architecture

**Statement:** Pipeline Owner and Architecture reviewer MUST approve the PipelinePlan before Build mode.  
**Rationale:** Pipeline decisions have technical, cost, data and client impacts.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** HITL-001–HITL-015  

**Acceptance criteria:**
- Approve pipeline architecture is bound to exact context and digests.
- Refusal or expiration blocks transition.

**Validation method:** Plan approval tests  
**Related risks:** RISK-041  
**Related architecture:** ADR-024  
**Related plan items:** PLAN-054  
**Status:** Approved baseline

### HITL-017 — Approve implementation mutation

**Statement:** A fresh explicit decision MUST authorize Builder writes against exact plan and baseline.  
**Rationale:** Pipeline decisions have technical, cost, data and client impacts.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** HITL-001–HITL-015  

**Acceptance criteria:**
- Approve implementation mutation is bound to exact context and digests.
- Refusal or expiration blocks transition.

**Validation method:** Consent tests  
**Related risks:** RISK-049,RISK-050  
**Related architecture:** ADR-024,ADR-034  
**Related plan items:** PLAN-055,PLAN-056  
**Status:** Approved baseline

### HITL-018 — Accept pipeline version

**Statement:** Independent Reviewer and Pipeline Owner MUST accept tests, residuals and rollback before activation.  
**Rationale:** Pipeline decisions have technical, cost, data and client impacts.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** HITL-001–HITL-015  

**Acceptance criteria:**
- Accept pipeline version is bound to exact context and digests.
- Refusal or expiration blocks transition.

**Validation method:** Activation tests  
**Related risks:** RISK-041,RISK-051  
**Related architecture:** ADR-025,ADR-032  
**Related plan items:** PLAN-063,PLAN-064  
**Status:** Approved baseline

### HITL-019 — Approve run and source use

**Statement:** Run Owner and required Data/Model Owner MUST approve execution and source access.  
**Rationale:** Pipeline decisions have technical, cost, data and client impacts.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** HITL-001–HITL-015  

**Acceptance criteria:**
- Approve run and source use is bound to exact context and digests.
- Refusal or expiration blocks transition.

**Validation method:** Run approval tests  
**Related risks:** RISK-052,RISK-054  
**Related architecture:** ADR-031  
**Related plan items:** PLAN-068,PLAN-069  
**Status:** Approved baseline

### HITL-020 — Review artifacts and publication

**Statement:** Technical Reviewer MUST accept dataset/artifact quality and Project Manager MUST separately approve publication.  
**Rationale:** Pipeline decisions have technical, cost, data and client impacts.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** HITL-001–HITL-015  

**Acceptance criteria:**
- Review artifacts and publication is bound to exact context and digests.
- Refusal or expiration blocks transition.

**Validation method:** Review/publication E2E  
**Related risks:** RISK-043,RISK-048  
**Related architecture:** ADR-021,ADR-028  
**Related plan items:** PLAN-071–PLAN-075  
**Status:** Approved baseline

### NFR-014 — Pipeline definition portability

**Statement:** Definitions and manifests SHOULD work across local and separated deployment modes.  
**Rationale:** The pipeline must remain operable on real simulation data and environments.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P1  
**Dependencies:** NFR-001–NFR-013  

**Acceptance criteria:**
- Pipeline definition portability has a documented budget or invariant.
- Violation is observable and blocks or degrades explicitly.

**Validation method:** Portability tests  
**Related risks:** RISK-041  
**Related architecture:** ADR-022,ADR-023  
**Related plan items:** PLAN-047,PLAN-048  
**Status:** Approved baseline

### NFR-015 — Large-data bounded memory

**Statement:** Adapters and generators MUST process representative result/trajectory volumes without unbounded memory.  
**Rationale:** The pipeline must remain operable on real simulation data and environments.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** NFR-001–NFR-013  

**Acceptance criteria:**
- Large-data bounded memory has a documented budget or invariant.
- Violation is observable and blocks or degrades explicitly.

**Validation method:** Load/memory tests  
**Related risks:** RISK-046  
**Related architecture:** ADR-026  
**Related plan items:** PLAN-058,PLAN-060  
**Status:** Approved baseline

### NFR-016 — Deterministic canonicalization

**Statement:** Identical inputs/version/configuration MUST produce identical canonical digests except declared nondeterminism.  
**Rationale:** The pipeline must remain operable on real simulation data and environments.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** NFR-001–NFR-013  

**Acceptance criteria:**
- Deterministic canonicalization has a documented budget or invariant.
- Violation is observable and blocks or degrades explicitly.

**Validation method:** Repeatability tests  
**Related risks:** RISK-042  
**Related architecture:** ADR-026  
**Related plan items:** PLAN-060  
**Status:** Approved baseline

### NFR-017 — Artifact reproducibility

**Statement:** Derived artifacts MUST be reproducible or declare controlled browser/font/runtime nondeterminism.  
**Rationale:** The pipeline must remain operable on real simulation data and environments.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** NFR-001–NFR-013  

**Acceptance criteria:**
- Artifact reproducibility has a documented budget or invariant.
- Violation is observable and blocks or degrades explicitly.

**Validation method:** Repeat-generation tests  
**Related risks:** RISK-044  
**Related architecture:** ADR-028  
**Related plan items:** PLAN-061  
**Status:** Approved baseline

### NFR-018 — Pipeline cancellation/recovery

**Statement:** Long stages MUST support declared cancel, retry and resume without ambiguous state.  
**Rationale:** The pipeline must remain operable on real simulation data and environments.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** NFR-001–NFR-013  

**Acceptance criteria:**
- Pipeline cancellation/recovery has a documented budget or invariant.
- Violation is observable and blocks or degrades explicitly.

**Validation method:** Recovery tests  
**Related risks:** RISK-053  
**Related architecture:** ADR-023  
**Related plan items:** PLAN-070  
**Status:** Approved baseline

### NFR-019 — Pipeline extensibility

**Statement:** New pipelines/surfaces SHOULD require registry/contracts/configuration rather than orchestrator branches.  
**Rationale:** The pipeline must remain operable on real simulation data and environments.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P1  
**Dependencies:** NFR-001–NFR-013  

**Acceptance criteria:**
- Pipeline extensibility has a documented budget or invariant.
- Violation is observable and blocks or degrades explicitly.

**Validation method:** Extension tests  
**Related risks:** RISK-041,RISK-047  
**Related architecture:** ADR-023,ADR-033  
**Related plan items:** PLAN-048,PLAN-052  
**Status:** Approved baseline

### NFR-020 — Query/rendering budgets

**Statement:** The profile MUST define budgets for queries, HTML, screenshots, Excel/report and GeoLibre on representative volumes.  
**Rationale:** The pipeline must remain operable on real simulation data and environments.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** NFR-001–NFR-013  

**Acceptance criteria:**
- Query/rendering budgets has a documented budget or invariant.
- Violation is observable and blocks or degrades explicitly.

**Validation method:** Performance tests  
**Related risks:** RISK-039,RISK-044,RISK-046  
**Related architecture:** ADR-026,ADR-028,ADR-030  
**Related plan items:** PLAN-060,PLAN-061,PLAN-073,PLAN-075  
**Status:** Approved baseline

### TEST-033 — Pipeline definition validation

**Statement:** v3 MUST include validation that validate valid/invalid definitions, stages, modes and entrypoints.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Validate valid/invalid definitions, stages, modes and entrypoints.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-041  
**Related architecture:** ADR-023,ADR-025  
**Related plan items:** PLAN-047,PLAN-048  
**Status:** Approved baseline

### TEST-034 — Plan-mode no-write

**Statement:** v3 MUST include validation that attempt repository writes in plan mode and assert denial.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Attempt repository writes in plan mode and assert denial.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-050  
**Related architecture:** ADR-024  
**Related plan items:** PLAN-049  
**Status:** Approved baseline

### TEST-035 — Pipeline dependency DAG

**Statement:** v3 MUST include validation that reject cycles, missing producers and undeclared cross-repository dependencies.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Reject cycles, missing producers and undeclared cross-repository dependencies.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-041  
**Related architecture:** ADR-023  
**Related plan items:** PLAN-051  
**Status:** Approved baseline

### TEST-036 — Capability substitution receipt

**Statement:** v3 MUST include validation that require explicit gap/substitute receipt and reject silent closest-skill use.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Require explicit gap/substitute receipt and reject silent closest-skill use.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-047  
**Related architecture:** ADR-033  
**Related plan items:** PLAN-052  
**Status:** Approved baseline

### TEST-037 — Baseline-preserving rollback

**Statement:** v3 MUST include validation that preserve pre-existing uncommitted work while reversing only mission delta.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Preserve pre-existing uncommitted work while reversing only mission delta.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-049  
**Related architecture:** ADR-034  
**Related plan items:** PLAN-055,PLAN-062  
**Status:** Approved baseline

### TEST-038 — Builder scope containment

**Statement:** v3 MUST include validation that reject worker identity/path/tool actions outside approved scope.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Reject worker identity/path/tool actions outside approved scope.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-050  
**Related architecture:** ADR-024  
**Related plan items:** PLAN-056,PLAN-057  
**Status:** Approved baseline

### TEST-039 — Pipeline version immutability

**Statement:** v3 MUST include validation that reject activation with mutable or changed source/dependency digest.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Reject activation with mutable or changed source/dependency digest.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-041  
**Related architecture:** ADR-025  
**Related plan items:** PLAN-063  
**Status:** Approved baseline

### TEST-040 — Operator no-code-write

**Statement:** v3 MUST include validation that reject code mutation in operate mode and log it.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Reject code mutation in operate mode and log it.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-050  
**Related architecture:** ADR-031  
**Related plan items:** PLAN-066  
**Status:** Approved baseline

### TEST-041 — Source receipt completeness

**Statement:** v3 MUST include validation that test model, SQLite, APA and FZP receipts for identity, method, environment and quality.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Test model, sqlite, apa and fzp receipts for identity, method, environment and quality.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-042  
**Related architecture:** ADR-029  
**Related plan items:** PLAN-050,PLAN-058,PLAN-060  
**Status:** Approved baseline

### TEST-042 — Canonical DuckDB schema and nulls

**Statement:** v3 MUST include validation that validate tables/views, nulls, quality and reference queries.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Validate tables/views, nulls, quality and reference queries.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-042  
**Related architecture:** ADR-026  
**Related plan items:** PLAN-060,PLAN-064  
**Status:** Approved baseline

### TEST-043 — Trajectory streaming and partitioning

**Statement:** v3 MUST include validation that process data larger than memory budget and validate Parquet/index/decimation.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Process data larger than memory budget and validate parquet/index/decimation.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-046  
**Related architecture:** ADR-026  
**Related plan items:** PLAN-058,PLAN-060  
**Status:** Approved baseline

### TEST-044 — Cross-surface KPI parity

**Statement:** v3 MUST include validation that compare canonical SQL, HTML, Excel, report, screenshot metadata and GeoLibre values.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Compare canonical sql, html, excel, report, screenshot metadata and geolibre values.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-043  
**Related architecture:** ADR-028  
**Related plan items:** PLAN-061,PLAN-064  
**Status:** Approved baseline

### TEST-045 — Screenshot failure detection

**Statement:** v3 MUST include validation that prove render-ready, empty-layer, timeout and WebGL-error detection.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Prove render-ready, empty-layer, timeout and webgl-error detection.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-044  
**Related architecture:** ADR-028  
**Related plan items:** PLAN-059,PLAN-061  
**Status:** Approved baseline

### TEST-046 — GeoLibre package and UI

**Statement:** v3 MUST include validation that open/query package, switch metric/interval, identify section and test degraded mode.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Open/query package, switch metric/interval, identify section and test degraded mode.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-045  
**Related architecture:** ADR-030  
**Related plan items:** PLAN-073  
**Status:** Approved baseline

### TEST-047 — Acceptance-dimension honesty

**Statement:** v3 MUST include validation that reject live pass without literal evidence while preserving residual.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Reject live pass without literal evidence while preserving residual.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-051  
**Related architecture:** ADR-032  
**Related plan items:** PLAN-053,PLAN-065  
**Status:** Approved baseline

### TEST-048 — Testudo registration transaction

**Statement:** v3 MUST include validation that register run/dataset/artifacts idempotently and reject partial authority.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Register run/dataset/artifacts idempotently and reject partial authority.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-048  
**Related architecture:** ADR-027  
**Related plan items:** PLAN-071,PLAN-072  
**Status:** Approved baseline

### TEST-049 — Learning candidate no-promotion

**Statement:** v3 MUST include validation that transport candidate to governed intake without acceptance.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Transport candidate to governed intake without acceptance.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-055  
**Related architecture:** ADR-023  
**Related plan items:** PLAN-074  
**Status:** Approved baseline

### TEST-050 — Rendering-modelling vertical slice

**Statement:** v3 MUST include validation that execute project→run→DuckDB/Parquet→artifacts→GeoLibre→finding→publication with recovery.  
**Rationale:** The test closes a load-bearing risk.  
**Source:** Rendering-modelling implementation plan v3; Testudo PRD; Audit v3  
**Priority:** P0  
**Dependencies:** Relevant requirements  

**Acceptance criteria:**
- Execute project→run→duckdb/parquet→artifacts→geolibre→finding→publication with recovery.
- Literal evidence is recorded; silent skip fails where required.

**Validation method:** Automated, controlled live test or explicit human-run receipt  
**Related risks:** RISK-041–RISK-055  
**Related architecture:** ADR-023–ADR-034  
**Related plan items:** PLAN-075  
**Status:** Approved baseline
