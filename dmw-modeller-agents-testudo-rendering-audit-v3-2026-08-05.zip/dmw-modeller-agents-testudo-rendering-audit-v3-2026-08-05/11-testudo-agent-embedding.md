# 11 — Testudo Agent Embedding Blueprint

## 1. Purpose

This document defines how `modeller-agents` is embedded within Testudo without exposing DMW internal complexity or transferring product authority to the orchestration runtime.

## 2. Product contract

Testudo is the web cockpit of a modelling project. It owns:

- identity and access;
- project responsibilities;
- project/model/version/period/scenario/SimulationRun metadata;
- the active context;
- Project × User conversations;
- persistent tasks and notifications;
- findings, reviews and publications;
- product audit and client access.

`modeller-agents` owns:

- mission planning and state;
- internal DMW roles;
- provider/backend dispatch;
- deterministic gates;
- checkpoint recovery;
- execution evidence;
- capability and timeout controls.

## 3. Role mapping

| Testudo surface or responsibility | Internal subsystem | User-visible? | Authority |
|---|---|---:|---|
| Contextual AI agent | Interaction Gateway + Decider policy | Yes | Prepares/explains only |
| Workflow preparation | Manager | Through visible agent | Technical proposal |
| Repository/data investigation | Recon | No | Evidence only |
| Implementation/analysis execution | Worker/provider | No | Bounded technical action |
| Independent technical verification | Reviewer | Verdict surfaced, role detail diagnostic | Independent machine/agent review |
| Simulation launch | Run Owner / Transport Modeller | Approval UI | Human |
| Finding acceptance | Technical Reviewer / Transport Modeller | Review UI | Human |
| Publication approval | Project Manager | Approval UI | Human |
| Data/model use outside prior scope | Data/Model Owner / Decider | Approval UI | Human |
| Permission changes | Administrator/project authority | Admin UI | Human |

## 4. Main sequence

```mermaid
sequenceDiagram
    participant U as Transport Modeller
    participant T as Testudo
    participant G as Orchestration Gateway
    participant M as modeller-agents
    participant B as Simulation Backend
    participant D as DuckDB
    participant PM as Project Manager

    U->>T: Ask visible agent to prepare a simulation
    T->>G: ActiveContextEnvelope + message
    G->>M: Create Mission
    M-->>G: Plan + risks + approval request
    G-->>T: Prepared action
    T-->>U: Show context, effects, resources and risks
    U->>T: Explicit launch approval
    T->>G: DecisionReceipt
    G->>M: Execute Mission
    M->>B: Scoped backend request
    B-->>M: Progress and result manifest
    M->>D: Validate/register analytical dataset
    M-->>G: Task events + GateReceipt + result references
    G-->>T: Task/result updates
    U->>T: Create technical finding
    T->>G: Finding request with evidence
    G->>M: Independent evidence synthesis/review
    M-->>T: FindingCandidate
    U->>T: Accept/correct/reject as Technical Reviewer
    T-->>PM: Publication draft
    PM->>T: Approve publication
```

## 5. Context lifecycle

1. Testudo resolves the current user and project responsibilities.
2. Testudo resolves model, version, period, scenario and selected SimulationRun.
3. Testudo adds view/selection/filter context.
4. Server-side policy removes unauthorized fields.
5. A versioned envelope and digest are issued.
6. `modeller-agents` validates the envelope and stores the digest.
7. A changed context invalidates any plan or approval that depends on changed fields.
8. A new mission may reuse evidence only after scope and freshness verification.

## 6. Task and event model

The Testudo task is a durable product object. It is not the runtime mission itself.

Minimum task payload:

```json
{
  "task_id": "tsk_...",
  "project_id": "prj_...",
  "mission_id": "mis_...",
  "workflow_id": "wf_...",
  "simulation_run_id": "sim_... or null",
  "status": "preparing|approval_required|running|partial|intervention_required|recovering|completed|failed|cancelled",
  "current_step": "...",
  "available_results": [],
  "missing_results": [],
  "required_action": null,
  "correlation_id": "...",
  "updated_at": "..."
}
```

Events are idempotent and versioned. Testudo is responsible for notification preferences and user presentation. The runtime is responsible for accurate cause, state and evidence.

## 7. Data ownership

### PostgreSQL

Recommended logical schemas:

```text
identity.*
project.*
workflow.*
conversation.*
finding.*
publication.*
audit.*
```

Key references include `mission_id`, `artifact_uri`, `artifact_digest`, `dataset_id`, `dataset_manifest_uri`, `context_digest` and `correlation_id`.

### DuckDB

Recommended logical tables:

```text
network_sections
network_nodes
observations
simulation_section_interval
simulation_turn_interval
trajectories
kpi
validation_result
comparison_result
dataset_metadata
```

Partition or database strategy is decided by DEC-021 after representative tests. Writes should be immutable/versioned where possible; derived tables record source dataset IDs.

### Artifact storage

Use a URI abstraction:

```text
artifact://<project>/<mission>/<digest>
dataset://<project>/<simulation-run>/<dataset-id>
```

The URI resolver applies project permissions and returns a controlled local/object location.

## 8. Approval policies

Approval requests contain:

```text
request_id
action_type
required_responsibility
project_id
context_digest
plan/configuration/evidence digests
effects and irreversible elements
cost/resource estimate where relevant
expiry and one-time-use token
```

The visible agent may explain the request but cannot submit the approval response.

## 9. Findings, publication and knowledge

The lifecycle is:

```text
ResultSet
→ AI/human interpretation
→ FindingCandidate
→ Technical review
→ ReviewedFinding
→ PublicationDraft
→ Project Manager approval
→ PublicationVersion
```

Separately:

```text
ReviewedFinding or mission lesson
→ MemoryCandidate
→ KnowledgeCandidate
→ modelling-knowledge governance
→ Accepted knowledge
```

A project finding can be valid for one project without becoming universal modelling knowledge.

## 10. Error and recovery experience

| Runtime condition | Testudo presentation | Allowed action |
|---|---|---|
| Provider waiting | Waiting for service/resource | Continue waiting, cancel if supported |
| Provider timeout | Intervention required | Retry bounded scope or decompose |
| Partial result | Partial result available | Inspect valid outputs, retry missing outputs |
| Context invalidated | Reconfirmation required | Review new context and re-prepare |
| Checkpoint verified | Recovering/resumed | Continue from verified step |
| Checkpoint failed | Recovery blocked | Inspect evidence; restart from safe prior state |
| Result manifest invalid | Results rejected | Correct backend/export; do not expose as complete |
| Approval expired | Approval required | Issue fresh exact request |

## 11. Security model

- Testudo creates the authorization snapshot.
- The Gateway converts it to a mission capability grant.
- The runtime narrows it per dispatch.
- Providers never receive reusable database credentials.
- External provider calls are classified and audited.
- Dataset/artifact access is mediated by scoped references.
- Conversation and draft content remain private by default.
- Publication creates a separate shared object.

## 12. Delivery slices

### Slice A — Read-only project assistant
- Context explanation.
- Result/dataset lookup.
- Evidence-linked interpretation.
- No simulation launch.

### Slice B — Prepared simulation
- Workflow proposal.
- Context/configuration review.
- Explicit launch approval.
- Persistent task and progress.

### Slice C — Result and recovery
- DuckDB result registration.
- Partial results.
- Checkpoint recovery.
- Comparison and validation.

### Slice D — Finding and publication
- FindingCandidate.
- Technical Reviewer action.
- Publication draft/version.
- Project Manager approval.

### Slice E — Memory and knowledge
- Project memory.
- Knowledge candidate handoff.
- Governed promotion only.

## 13. Acceptance checklist

- [ ] One visible agent per Project × User.
- [ ] Context digest visible and correct before material actions.
- [ ] Internal role/provider separation auditable but hidden from normal UX.
- [ ] Simulation approval actor is correct.
- [ ] Task survives UI disconnect and runtime restart.
- [ ] Partial result is not shown as complete.
- [ ] DuckDB dataset has complete manifest and lineage.
- [ ] PostgreSQL contains product records and references, not unbounded analytics.
- [ ] Finding acceptance is separate from mission acceptance.
- [ ] Publication approval is separate from finding review.
- [ ] Cross-store publication lineage is complete.
- [ ] External providers cannot exceed user/project capability.
- [ ] Checkpoint recovery is mechanical.
- [ ] Approved external subsystems can be disabled.

## 14. Pipeline interaction in Testudo

```text
Project/context
→ visible agent discovers applicable PipelineDefinitions
→ prepares PipelineRunRequest or PipelinePlan
→ displays required approvals
→ modeller-agents operates active version
→ Testudo receives Task events and partial results
→ datasets/artifacts register
→ GeoLibre/HTML/Excel/report become available
→ Transport Modeller reviews finding
→ Project Manager approves publication
```

### UI rules

- Show business goals, not internal work-item IDs or Workers.
- Distinguish design proposal, implementation change and execution.
- Run confirmation displays version, context, sources, outputs, cost/duration and external services.
- Partial DuckDB tables and missing artifacts are explicit.
- GeoLibre opens the exact registered package version.
- Publication freezes dataset/artifact digests.

### PostgreSQL additions

- pipeline definition/version projection;
- selected version and task correlation;
- SimulationRun↔PipelineRun mapping;
- dataset/artifact manifest references;
- approvals and residuals;
- finding/publication lineage.

Bulk DuckDB/Parquet rows remain outside PostgreSQL.
