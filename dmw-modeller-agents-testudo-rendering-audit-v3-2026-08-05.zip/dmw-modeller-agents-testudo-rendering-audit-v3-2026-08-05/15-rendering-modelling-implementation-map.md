# 15 — Rendering-Modelling Implementation Plan Mapping

## 1. Evidence snapshot

- Mission: `rendering-modelling-2026-08-05`
- Plan version: `3`
- Status: `draft`
- Work items: 31
- Repositories written: aimsun-psp, modelling-knowledge
- Snapshot: `evidence/rendering-modelling-implementation-plan.v3.json`

The plan is preserved unchanged as evidence. This mapping does not claim implementation.

## 2. Epic mapping

| Epic | Plan intent | Generic interpretation |
|---|---|---|
| 0 | Contracts and decisions | definition, schemas, capability decisions and scope |
| 1 | Canonical vertical slice | reuse, DuckDB writer, stage wiring, tests and version candidate |
| 2 | Delivery artifacts | HTML, screenshots, Excel, reports and parity |
| 3 | GeoLibre and Testudo | viewer package and product registration |
| 4 | Paths and animation | APA/FZP adapters and bulk-data extension |
| 5 | Governed calibration | approved iteration, comparison, stop/rollback |
| 6 | Knowledge loop | event ledger and governed candidate transport |

## 3. Work-item map

| Work item | Epic/stage | Repository | Primary skill | Main concern | Dependencies named in objective | Residual dimension |
|---|---|---|---|---|---|---|
| E0-WI-01 | Contracts | aimsun-psp | document | Knowledge candidate | E0-WI-03,E1-WI-08,E6-WI-03 | licensed live proof |
| E0-WI-02 | Contracts | aimsun-psp | create-psp-module | DuckDB/canonical schema | E1-WI-03,E1-WI-04 | none |
| E0-WI-03 | Contracts | aimsun-psp | document | Contracts/code/docs |  | none |
| E1-WI-01 | Canonical vertical slice | aimsun-psp | refactor-to-shared | Knowledge candidate | E0-WI-02,E1-WI-02 | none |
| E1-WI-02 | Canonical vertical slice | aimsun-psp | refactor-to-shared | Knowledge candidate | E1-WI-01 | none |
| E1-WI-03 | Canonical vertical slice | aimsun-psp | create-psp-module | DuckDB/canonical schema | E0-WI-02,E1-WI-04 | none |
| E1-WI-04 | Canonical vertical slice | aimsun-psp | create-script | DuckDB/canonical schema | E1-WI-03 | none |
| E1-WI-05 | Canonical vertical slice | aimsun-psp | pipeline-schema | DuckDB/canonical schema | E1-WI-04 | none |
| E1-WI-06 | Canonical vertical slice | aimsun-psp | test | DuckDB/canonical schema | E1-WI-01,E1-WI-02,E1-WI-05 | licensed live proof |
| E1-WI-07 | Canonical vertical slice | aimsun-psp | deploy | Knowledge candidate | E1-WI-01,E1-WI-06 | licensed live proof |
| E1-WI-08 | Canonical vertical slice | aimsun-psp | document | DuckDB/canonical schema | E1-WI-01,E1-WI-07 | none |
| E2-WI-01 | Delivery artifacts | aimsun-psp | create-script | DuckDB/canonical schema | E1-WI-03,E1-WI-05 | none |
| E2-WI-02 | Delivery artifacts | aimsun-psp | create-psp-module | DuckDB/canonical schema | E2-WI-01,E2-WI-04,E2-WI-05 | none |
| E2-WI-04 | Delivery artifacts | aimsun-psp | create-psp-module | GeoLibre package | E2-WI-02 | none |
| E2-WI-05 | Delivery artifacts | aimsun-psp | create-psp-module | Derived artifacts | E2-WI-01,E2-WI-02,E2-WI-04 | none |
| E2-WI-03 | Delivery artifacts | aimsun-psp | test | DuckDB/canonical schema | E2-WI-01,E2-WI-02,E2-WI-04,E2-WI-05 | none |
| E3-WI-01 | GeoLibre/Testudo | aimsun-psp | create-psp-module | DuckDB/canonical schema |  | none |
| E3-WI-02 | GeoLibre/Testudo | aimsun-psp | test | DuckDB/canonical schema | E3-WI-01 | GeoLibre UI |
| E3-WI-03 | GeoLibre/Testudo | aimsun-psp | create-psp-module | DuckDB/canonical schema | E1-WI-03,E3-WI-01 | Testudo write |
| E3-WI-04 | GeoLibre/Testudo | aimsun-psp | document | DuckDB/canonical schema | E1-WI-08,E3-WI-01,E3-WI-02,E3-WI-03 | none |
| E4-WI-01 | Paths/animation | aimsun-psp | create-psp-module | Parquet/trajectories | E0-WI-02,E4-WI-02,E4-WI-03 | none |
| E4-WI-02 | Paths/animation | aimsun-psp | create-psf-module | Knowledge candidate | E4-WI-01 | none |
| E4-WI-03 | Paths/animation | aimsun-psp | create-psp-module | Parquet/trajectories | E4-WI-01 | none |
| E4-WI-04 | Paths/animation | aimsun-psp | create-psp-module | Parquet/trajectories | E3-WI-01,E4-WI-02,E4-WI-03 | none |
| E4-WI-05 | Paths/animation | aimsun-psp | test | Parquet/trajectories | E1-WI-06,E2-WI-03,E4-WI-01,E4-WI-02,E4-WI-03,E4-WI-04 | GeoLibre UI |
| E5-WI-01 | Governed calibration | aimsun-psp | create-psp-module | DuckDB/canonical schema |  | none |
| E5-WI-02 | Governed calibration | aimsun-psp | create-psp-module | Knowledge candidate | E1-WI-03,E5-WI-01 | none |
| E5-WI-03 | Governed calibration | aimsun-psp | test | Knowledge candidate | E5-WI-01,E5-WI-02 | licensed live proof |
| E6-WI-01 | Knowledge loop | aimsun-psp | create-psp-module | Knowledge candidate | E1-WI-08,E5-WI-03,E6-WI-02 | none |
| E6-WI-02 | Knowledge loop | modelling-knowledge | memory-worker | Knowledge candidate | E1-WI-08,E5-WI-03,E6-WI-01 | none |
| E6-WI-03 | Knowledge loop | aimsun-psp | document | Knowledge candidate | E1-WI-08,E3-WI-04,E6-WI-01,E6-WI-02 | none |

## 4. Generic platform elements

- PipelineDefinition/profile/mode;
- machine-readable stage and dependency edges;
- capability receipts and gaps;
- baseline/rollback classes;
- source, dataset and artifact manifests;
- parity declarations;
- acceptance dimensions and residuals;
- Testudo registration/task contracts;
- learning-candidate boundary.

## 5. Pipeline-specific elements

- Aimsun/SQLite extraction details;
- table names and metric semantics;
- HTML/rendering implementation;
- screenshot catalog;
- Excel/report templates;
- GeoLibre layers/views;
- calibration rules;
- live commands/environment paths.

## 6. Plan-quality assessment

Strengths:

- complete seven-epic scope;
- corrected skill classifications;
- honest live-environment limits;
- additive migration/compatibility;
- baseline-relative rollback;
- explicit Testudo/GeoLibre boundaries;
- parity and knowledge governance.

Mechanical pre-execution checks:

- normalize free-text epic/dependency content into typed edges;
- fix or explicitly waive E6-WI-03's reference to plan v2;
- resolve capability substitutions through catalog additions;
- keep Testudo POST, GeoLibre UI and Aimsun live proof as independent acceptance dimensions;
- never report one undifferentiated completion percentage.

## 7. Orchestration treatment

Import this plan as migration evidence, not permanent runtime format. Normalize it into PipelinePlan objects before dispatch. Review and record every normalization difference while preserving the snapshot.
