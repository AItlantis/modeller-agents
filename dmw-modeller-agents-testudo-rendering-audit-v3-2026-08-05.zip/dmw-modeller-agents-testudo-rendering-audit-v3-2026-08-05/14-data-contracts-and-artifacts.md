# 14 — Data Contracts, Storage and Artifact Lineage

## 1. Authority

| Layer | Authority | Examples |
|---|---|---|
| Source/model | technical system + Data/Model Owner | Aimsun model, SQLite, APA, FZP |
| Canonical analytical | accepted pipeline version/data contract | DuckDB, Parquet |
| Semantic | metric/validation definitions | KPI, comparability, calibration |
| Presentation | derived/regenerable until frozen | HTML, PNG, XLSX, report, GeoLibre |
| Product | Testudo/PostgreSQL | project, task, registry, finding, publication |
| Knowledge | governed knowledge lifecycle | reviewed candidate/accepted note |

A screenshot cannot override DuckDB; DuckDB is not the Aimsun model; AI interpretation is not a human decision.

## 2. Storage

### PostgreSQL

Store product identities, permissions, pipeline/version projection, Task/PipelineRun/SimulationRun mapping, manifest references, approvals, residuals, findings, publications and future product events.

Do not store full interval/path/trajectory rows or bulk binary artifacts.

### DuckDB

Store normalized network/results, KPI/validation/comparison/calibration records and views/indexes over Parquet. Registered packages are immutable/versioned.

### Parquet

Use for high-volume trajectories and other partition-prunable data.

### File/object storage

Store baselines, receipts/logs, DuckDB/Parquet packages, HTML/PNG/XLSX/reports/GeoLibre and frozen publications.

## 3. CanonicalDatasetManifest

```text
manifest_id
schema_version
pipeline_definition_id
pipeline_version_id
pipeline_run_id
project_id
simulation_run_id
status: partial | valid | invalid | superseded
sources[]
files[] {uri, media_type, digest, bytes}
tables[] {name, grain, keys, columns_digest, row_count, quality}
views[] {name, purpose, sql_digest}
partitions[]
quality_summary
completeness
reference_queries[]
sensitivity
retention
supersedes
```

## 4. ArtifactManifest

```text
artifact_set_id
pipeline_run_id
canonical_dataset_manifest_id
canonical_dataset_digest
generator_version
artifacts[] {
  artifact_id, type, uri, digest, media_type,
  parameters, source_queries, metric_ids,
  render_evidence, quality_status, visibility
}
parity_assertions[]
publication_status
```

## 5. Metric parity

Each shared metric declares stable ID, definition version, reference query/view, aggregation, filters, period, unit, formatting/tolerance and surface selector.

| Surface | Assertion |
|---|---|
| DuckDB | reference SQL returns canonical value |
| HTML | displayed value equals canonical |
| Excel | cell/table equals canonical |
| Report | cited KPI equals canonical and has evidence |
| Screenshot | manifest points to correct metric/query/dataset; pixels are not KPI proof |
| GeoLibre | selected feature/interval query equals canonical |

## 6. Partial data

Declare available/missing/invalid elements, cause, recovery, authorized analyses/artifacts, prohibited comparisons/publications and resumability. Testudo may expose valid partial outputs but must not label them complete.

## 7. Lineage

```text
SourceReceipt
→ extraction batch
→ canonical table/partition
→ semantic metric/validation
→ artifact
→ finding claim
→ publication version
```

Each edge carries IDs and digests. Missing history is flagged, not falsified.

## 8. Retention/regeneration

- Retain canonical packages referenced by findings/publications.
- Unpublished derived artifacts may regenerate with auditable version history.
- Published artifacts are frozen/versioned.
- Trajectory retention may be shorter than aggregates.
- Learning candidates do not extend raw-data retention automatically.

## 9. Quality controls

Stable keys, row/partition counts, interval coverage, CRS/geometry, source coverage, unresolved paths, trajectory range/monotonicity, null/quality distributions, units/aggregation, comparability and runtime compatibility.

## 10. Security

Propagate source sensitivity; authorize external/browser flows; redact secrets/paths; separate private conversations; control download/publication separately; preserve Data/Model Owner and Publication Approver decisions.
