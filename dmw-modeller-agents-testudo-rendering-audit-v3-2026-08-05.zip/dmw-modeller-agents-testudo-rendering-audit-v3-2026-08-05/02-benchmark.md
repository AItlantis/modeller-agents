# 02 — Benchmark

## 1. Objective

Identify external patterns that improve Decider memory, Manager loop efficiency, Worker reuse, Recon evidence retrieval, provider portability, and architecture clarity without replacing the repository-owned governance model.

## 2. Evaluation criteria

| Criterion | Weight | Question |
|---|---:|---|
| Deterministic control | 20% | Can the pattern be bounded by typed gates and receipts? |
| Evidence and provenance | 15% | Can claims be traced to exact source, method, and freshness? |
| Runtime simplicity | 15% | Does it reduce rather than duplicate orchestration structure? |
| Provider portability | 10% | Can native/external agents be substituted without policy drift? |
| Context efficiency | 10% | Does it reduce repeated reading and context growth? |
| Human authority | 10% | Are approvals and promotion explicit and non-fabricable? |
| Reuse and maintainability | 10% | Does it discourage rebuilding and catalog duplication? |
| Licensing/deployment fit | 10% | Can it be used without unacceptable coupling or obligations? |

## 3. Internal benchmark

| Internal source | Pattern to preserve | Pattern to change |
|---|---|---|
| DMW | Explicit roles, immutable approvals, independent review, checkpoints, artifact ownership | Static tool grants, duplicate skills, policy-only runtime, template drift |
| modeller-agents | Python CLI/runtime, routing axes, backend registry, reference packs, V-cycle traces | No role dispatcher, weak result seam, catalog duplication, excessive module/catalog projections |
| Testudo workflow | Gated recon→plan→implement→verify, reuse ladder, literal evidence, bounded debug loops | Reduce from universal 15-step process to risk-based mission profiles |
| knowledge/memory decisions | Accepted knowledge authority, no-copy packs, digest parity, sensitivity | Keep inactive until end-to-end candidate and authority-context proof is complete |

## 4. External comparison matrix

| Solution | Relevant capability | Adopt/adapt | Avoid/reject | License note | Disposition |
|---|---|---|---|---|---|
| Codebase Memory MCP | Persistent code graph, fast semantic/code queries | Use as optional Recon provider; require source commit/index digest and freshness check | Do not make graph output authoritative or mandatory for bootstrap | MIT | Adopt |
| MemPalace | Verbatim conversation history and scoped retrieval | Borrow scoped retrieval and exact-source retention | Do not accept headline benchmarks or compression claims without independent reproduction; does not solve governance | Open source; verify current terms | Evaluate |
| Letta / Letta Code | Stateful identity, memory blocks, skills, hooks, permissions | Borrow memory inspection, explicit identity/context blocks, evaluation concepts | Reject autonomous self-rewriting of authoritative policy or approvals | Open source components; verify deployment terms | Adapt |
| gstack | Role-specific skills and workflow enforcement | Borrow Decider lenses (CEO/CTO/CFO/advisor) as stateless policy overlays and eval-driven skills | Do not encode host-specific tools without adapter validation | Open source; verify individual components | Adapt |
| claude-reflect | Automatic correction capture plus manual promotion | Adopt capture→queue→human review pattern for improvement events | Do not write corrections directly into authoritative rules | MIT | Adopt |
| loop-engineering | Loop budgets, state compaction, circuit breakers, worktrees, maturity levels | Adopt budget/circuit-breaker/decomposition and report-only-first rollout | Avoid autonomous merge or remediation until gates prove safe | MIT | Adopt |
| BMAD-METHOD | Explicit decisions, specialist agents, structured artifacts | Borrow facilitated decision workflows, project context, and staged planning | Avoid full document ceremony and duplicate personas for a lean runtime | MIT | Adapt |
| Caveman | Compact outputs and delegation summaries | Use a structured compact receipt format to reduce context injection | Do not compress code/evidence or remove uncertainty metadata | MIT | Configure |
| Ponytail | Reuse ladder, YAGNI, minimum necessary implementation | Adopt as Worker preflight and review checklist | Never remove validation, security, data-loss, or accessibility controls | MIT | Adopt |
| Repowise | Architecture context, code health, docs, dead-code signals via MCP | Optional Recon signal and technical-debt evidence | Do not let proprietary scores determine acceptance; note AGPL obligations | AGPL-3.0 | Evaluate |
| Archon | Provider adapters, knowledge/project/task surfaces, harness concepts | Borrow provider capability descriptors and UI separation concepts | Do not adopt as runtime dependency or duplicate project/knowledge authority | Open source; verify deployment stack | Adapt |

## 5. Pattern-level conclusions

### BMK-001 — Code graph as a Recon accelerator

A persistent code graph is valuable for semantic search, call-path tracing, and blast-radius analysis. It must remain an optional provider. Every response must include repository root, commit/index digest, query, returned symbols, and freshness. If stale or unavailable, Recon falls back to source inspection. This avoids making a cache a source of truth.

### BMK-002 — Decider memory must store verification, not only conversation

Verbatim history and stateful memory improve continuity, but the live-fire defect was verification-quality loss. The target memory record must distinguish `mechanical`, `executed-test`, `source-read`, `reported`, and `inferred`; it must carry evidence digests and expiry.

### BMK-003 — Personas are lenses, not identities

CEO, CTO, CFO, business advisor, technical advisor, and risk advisor should be selectable Decider lenses. They change evaluation criteria and questions; they do not create separate user memories or approval identities.

### BMK-004 — Loop engineering is a control pattern

Budget, circuit breaker, progress detection, state compaction, and decomposition are directly applicable. Start in report-only mode. Automatic retries or merges remain disabled until regression tests and mission pilots pass.

### BMK-005 — Improvement follows capture→review→promotion

Corrections and incidents should enter an improvement queue automatically, but policy/skill updates require review. Each promoted improvement must cite an incident, decision, contract diff, regression test, and released catalog version.

### BMK-006 — Worker optimization is reuse-first

The most useful Worker enhancement is not another coding agent; it is a mandatory reuse ladder: existing code → standard library/platform → installed dependency → minimal extension → new build. The Worker must show what it searched and why reuse was rejected.

### BMK-007 — Provider adapters are useful; platform replacement is not

Archon-like provider abstraction is worth borrowing. Adopting a second knowledge/project/task platform would recreate the duplication this audit aims to remove.

## 6. Licensing and operational constraints

- MIT-pattern sources are generally safe to study and reuse subject to attribution and file-level license review.
- Repowise is reported as AGPL-3.0; integrating or modifying it may trigger network-use obligations. Prefer an external optional provider unless legal review approves deeper integration.
- Letta and Archon have multiple components and deployment modes; verify the exact component license before embedding code.
- Benchmarks reported by repositories are not acceptance evidence for this project. Reproduce any performance claim against representative missions before using it as a KPI baseline.

## 7. Adopt, adapt, avoid, reject

| Decision | Items |
|---|---|
| **Adopt** | Code-graph-first Recon with freshness; loop budgets/circuit breakers; correction queue + human promotion; Worker reuse ladder. |
| **Adapt** | Letta memory blocks and inspectors; gstack role lenses; BMAD decision facilitation; Archon provider descriptors; Caveman compact receipts. |
| **Avoid** | Self-modifying authoritative memory; flat vector recall without authority context; host-specific tool names inside role policies; automatic merge from early pilots. |
| **Reject** | Replacing `modelling-knowledge` with an external memory store; running DMW and modeller-agents as independent workflow engines; trusting repository benchmark claims as release evidence. |

## 8. Benchmark conclusion

No external repository should become the orchestration core. The target should combine a small set of patterns around the existing authority model: provider-neutral dispatch, code/knowledge retrieval with freshness, verification-bearing memory, bounded loops, reuse-first Workers, and human-reviewed improvement promotion.

## 9. External sources

- **WEB-001 — [DeusData/codebase-memory-mcp](https://github.com/DeusData/codebase-memory-mcp)**: Persistent code knowledge graph; MCP code intelligence.
- **WEB-002 — [MemPalace/mempalace](https://github.com/MemPalace/mempalace)**: Verbatim conversation storage and scoped semantic retrieval; benchmark claims require independent verification.
- **WEB-003 — [letta-ai/letta](https://github.com/letta-ai/letta)**: Stateful agents with advanced memory.
- **WEB-004 — [letta-ai/letta-code](https://github.com/letta-ai/letta-code)**: Agent identity, memory blocks, skills, hooks, permissions, self-improvement.
- **WEB-005 — [garrytan/gstack](https://github.com/garrytan/gstack)**: Role-oriented workflow skills and workflow enforcement.
- **WEB-006 — [BayramAnnakov/claude-reflect](https://github.com/BayramAnnakov/claude-reflect)**: Capture corrections, then promote through manual review.
- **WEB-007 — [cobusgreyling/loop-engineering](https://github.com/cobusgreyling/loop-engineering)**: Loop budgets, state, circuit breakers, worktree isolation, maturity levels.
- **WEB-008 — [bmad-code-org/BMAD-METHOD](https://github.com/bmad-code-org/BMAD-METHOD)**: Explicit decisions, specialized agents, structured workflows, preserved context.
- **WEB-009 — [JuliusBrussee/caveman](https://github.com/JuliusBrussee/caveman)**: Response compression and compact delegation outputs.
- **WEB-010 — [DietrichGebert/ponytail](https://github.com/DietrichGebert/ponytail)**: Reuse ladder and anti-overengineering rules.
- **WEB-011 — [repowise-dev/repowise](https://github.com/repowise-dev/repowise)**: Codebase intelligence, health scoring, documentation and architecture context via MCP.
- **WEB-012 — [coleam00/Archon](https://github.com/coleam00/Archon)**: Provider-oriented harness, knowledge, project and task management.

## 8. Testudo as the internal product benchmark

The Testudo product documents are the controlling benchmark for how agent capabilities are exposed. External agent frameworks remain implementation-pattern sources only.

| Testudo product rule | Runtime implication | Adopt / adapt / reject |
|---|---|---|
| One visible contextual AI agent | Use one Interaction Gateway and conversation; hide DMW roles | Adopt |
| Project is persistent unit | Require `project_id` and active-context digest on all missions | Adopt |
| AI actions inherit user permissions | Capability grants generated server-side from project responsibility | Adopt |
| Risk-proportional control | Map action classes to approval policies and required actors | Adopt |
| Long tasks remain visible and recoverable | Publish structured task events and partial results | Adopt |
| Result, interpretation and decision are distinct | Require output classification in receipts and UI payloads | Adopt |
| Findings and publications are reviewed | Add product handoff objects after technical delivery | Adopt |
| Aimsun remains a system of authority | Use backend adapters; reject browser reimplementation of model editing | Adopt |
| One database for everything | Conflicts with product/analytics separation | Reject |
| Separate role conversations in the UI | Conflicts with one-agent experience | Reject |

## 9. Updated use of external patterns

DEC-012 is approved. Feature reuse may proceed as isolated subsystems inside `modeller-agents` where it improves the confirmed architecture. The implementation rule is:

```text
pattern or reusable component
  → exact version and license check
  → adapter/interface boundary
  → project-owned tests
  → no external runtime authority
```

Examples:

- Code-graph memory becomes a `recon.index` subsystem.
- Reflection becomes an `improvement.review` subsystem requiring human promotion.
- Loop engineering becomes `runtime.budgets` and `review.decomposition`.
- Reuse ladders become Worker policy.
- Provider descriptors become `providers.registry`.
- None of these projects becomes the Testudo visible agent or the mission-state authority.

## 10. Rendering-modelling as the internal pipeline benchmark

The supplied plan exposes real seams across contracts, extraction, storage, rendering, publication, human approval and licensed runtime execution.

| Pattern | Evidence in plan | Generic adoption |
|---|---|---|
| Contract-first | Schema frozen before DuckDB materialization | Require contracts before Build mode. |
| Additive vertical slice | `canonical_duckdb=false` default | Use feature flags and backward-compatible activation. |
| Reuse first | Rendering-GEH modules extracted with shims | Require reuse receipt and second-use evidence. |
| Canonical dataset | HTML/Excel/report/GeoLibre converge on DuckDB | Require dataset/query lineage. |
| Large-data specialization | FZP uses streaming + Parquet | Data-class profiles drive storage policy. |
| Honest environment boundary | Live aconsole proof is a residual | Separate build proof from live proof. |
| Product write boundary | Testudo payload generated; POST deferred | Make publish capability separately grantable. |
| Governed learning | Candidate only enters discovery-draft inbox | No automatic promotion. |
| Safe rollback | Baseline protects uncommitted work | Generalize baseline receipts. |

## 11. Pipeline-framework conclusion

Adopt the rigor, not the mission-specific encoding:

```text
PipelineDefinition
→ PipelinePlan
→ PipelineImplementationReceipt
→ PipelineVersion
→ PipelineRunRequest
→ PipelineRunReceipt
→ CanonicalDatasetManifest
→ ArtifactManifest
→ ProductRegistrationReceipt
→ LearningCandidate
```

Seven epics should not be mandatory for every pipeline. A rendering-modelling profile requires all relevant stages; smaller profiles may omit artifact or learning stages explicitly.
