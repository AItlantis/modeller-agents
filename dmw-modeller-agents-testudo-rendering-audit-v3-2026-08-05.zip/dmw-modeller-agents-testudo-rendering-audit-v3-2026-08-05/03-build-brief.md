# 03 — Build Brief v3

## 1. Problem

The ecosystem has strong governance concepts, a partially executable orchestration scaffold and a clear future product vision, but the three layers are not yet joined:

1. DMW-Orchestration defines roles, authority, receipts and review.
2. `modeller-agents` provides Python routing, contracts, work orders and backend integration.
3. Testudo requires one project-centred contextual agent, persistent tasks, explicit context, evidence-linked findings and approved publications.

Without a formal seam, the product risks exposing plugin mechanics, duplicating state, conflating simulation runs with agent runs, and allowing project permissions or context to drift during orchestration.

## 2. Confirmed direction

- `modeller-agents` is the sole executable orchestration runtime.
- DMW governance is implemented as canonical role policies, schemas and generated compatibility projections.
- Testudo is the product authority and user experience.
- One visible Testudo agent delegates internally to Decider, Manager, Recon, Worker and Reviewer subsystems.
- PostgreSQL owns product authority and project information.
- DuckDB owns simulation analytical datasets.
- Immutable mission evidence/checkpoints remain file or object artifacts.
- PostgreSQL may later become the product event store.
- Approved external features may be integrated as isolated subsystems.

## 3. Target vision

```text
Transport Modeller / Project Manager / Guest Client
                         ↓
               Testudo project workspace
  active context · one AI conversation · tasks · evidence · approvals
                         ↓
               Testudo Orchestration Gateway
  authorization · context digest · action classification · event projection
                         ↓
                 modeller-agents runtime
  Decider → Manager → Recon/Worker → Reviewer → deterministic gates
                         ↓
   Aimsun / pipelines / GeoLibre / data / documents / external agents
                         ↓
 DuckDB result datasets + immutable artifacts + PostgreSQL product records
```

## 4. Users and responsibility mapping

| Product responsibility | Runtime authority |
|---|---|
| Client / Data or Model Owner / Decider | Confirms business objective, use of owned assets and material direction where required |
| Transport Modeller / Technical Reviewer | Confirms simulation configuration, validates method and technical findings |
| Project Manager / Publication Approver | Approves client-facing publication |
| Administrator | Grants technical access; does not validate modelling conclusions by default |
| Visible Testudo agent | Prepares and explains; never becomes a human approver |
| Internal Reviewer subsystem | Independently verifies plan/results; does not replace the named human responsibility |

## 5. Primary use cases

1. Resume a project with the correct model/version/period/scenario/SimulationRun context.
2. Ask the visible agent to prepare a simulation or analysis workflow.
3. Review the prepared action, required data, effects and approval.
4. Launch and monitor a persistent task.
5. Recover from provider/backend interruption without losing evidence.
6. Explore results stored in DuckDB through controlled services.
7. Convert technical evidence into a finding candidate.
8. Obtain technical review and publication approval.
9. Preserve lineage from publication back to project, simulation run, datasets, receipts and reviewers.
10. Propose memory or knowledge candidates without automatic promotion.

## 6. Scope

### In scope

- Canonical DMW role and receipt model.
- Provider-neutral dispatch.
- Testudo interaction/orchestration API.
- Active-context envelope and authorization binding.
- Mission/task/simulation-run vocabulary and identifiers.
- PostgreSQL product schema boundaries.
- DuckDB simulation dataset contract.
- Event/task projection.
- Findings/publications handoff.
- Human approval mapping.
- Mission-local checkpoint recovery.
- Two end-to-end pilots, including one Testudo vertical slice.

### Non-goals

- Full Aimsun model editing in Testudo.
- Silent parameter mutation.
- Autonomous calibration or publication.
- Exposing multiple internal agent personas to users.
- Replacing accepted knowledge governance.
- Storing high-volume trajectories or full simulation result tables in PostgreSQL by default.
- Building a general enterprise event platform in v1.

## 7. Outcomes and KPIs

| Outcome | KPI |
|---|---|
| Coherent product experience | One visible agent conversation per Project × User; zero role-chat switching in reference journey |
| Correct context | 100% material missions bound to a valid `ActiveContextEnvelope` digest |
| Safe authorization | Zero sensitive action executed without the required project-responsibility receipt |
| Reliable execution | 100% accepted Worker results have orchestrator GateReceipts |
| Recovery | 100% resumed missions pass checkpoint verification |
| Product/task consistency | No task marked complete before runtime acceptance and result registration |
| Data separation | PostgreSQL contains no unbounded simulation trajectory/result payloads; DuckDB contains no user permission authority |
| Traceability | Publication lineage reaches project, SimulationRun, datasets, findings, technical review and approver |
| Usability | Reference workflow completed without exposing backend/provider terminology |
| Generality | Rendering mission plus Testudo vertical slice accepted using the same runtime kernel |

## 8. Delivery strategy

1. Align vocabulary and contracts.
2. Harden the runtime kernel and approved decisions.
3. Build the Testudo gateway, context and authorization seam.
4. Implement PostgreSQL, DuckDB and artifact ownership contracts.
5. Add task/event projection and one-agent interaction.
6. Integrate finding/publication lifecycle.
7. Run the full vertical slice.
8. Shadow, measure, then cut over.

## 9. Rendering-modelling opportunity

```text
Aimsun model + SQLite results + APA paths + FZP trajectories
  → source inventory and extraction receipts
  → DuckDB tables + Parquet partitions
  → KPI, validation and comparison
  → HTML dashboards
  → deterministic screenshots
  → Excel workbook
  → evidence-linked report pages
  → GeoLibre package/plugin
  → Testudo task, result, finding and publication
```

### Users

- Pipeline Architect: plans without production-code changes.
- Pipeline Maintainer: implements and versions pipeline code.
- Transport Modeller / Run Owner: executes registered pipelines.
- Technical Reviewer: reviews quality, parity and conclusions.
- Project Manager: approves publication.
- Data/Model Owner: authorizes source use.

### Scope

- Generic pipeline definition, plan, build and operation contracts.
- Source adapters and environment profiles.
- Canonical datasets and derived-artifact lineage.
- Artifact parity and deterministic regeneration.
- Testudo task, dataset/artifact and publication integration.
- GeoLibre as the first interactive viewer seam.
- Explicit live-runtime residual handling.

### Non-goals

- Moving backend implementation into `modeller-agents`.
- Bulk simulation data in PostgreSQL.
- Treating Excel, HTML or GeoLibre as analytical authorities.
- Allowing Operator agents to edit code.
- Claiming live/UI proof from package tests.

## 10. Pipeline KPIs

| KPI | Target |
|---|---|
| Machine-valid plan before implementation | 100% |
| Registered version with exact code/contract/test digest | 100% |
| Runs using active registered versions | 100% |
| Declared surfaces passing KPI parity | 100% |
| Results with complete lineage | 100% |
| Bulk simulation rows in PostgreSQL | 0% |
| Operator repository writes | 0 |
| Live-proof claims without execution evidence | 0 |
| Automatic knowledge promotion | 0 |
