# 12 — Rendering-Modelling Pipeline Reference Architecture

## 1. Purpose

`rendering-modelling` is the reference profile for converting simulation sources into structured analytical datasets, validated indicators and presentation artifacts for GeoLibre and Testudo.

It is both a concrete Aimsun-oriented vision and a reusable pipeline pattern. Not every future pipeline must implement every artifact type.

## 2. Business outcome

A Transport Modeller selects a simulation run and obtains one traceable package containing:

- network, result, validation and comparison data;
- optional paths and trajectories;
- interactive HTML;
- deterministic screenshots;
- an Excel workbook;
- evidence-linked report pages;
- a GeoLibre project/plugin package;
- Testudo Task, result, finding and publication references.

## 3. Flow

```mermaid
flowchart TB
 A[Aimsun model / geometry] --> I[Source inventory]
 S[SQLite outputs] --> I
 P[APA paths] --> I
 F[FZP trajectories] --> I
 I --> X[Extract adapters + receipts]
 X --> N[Normalize]
 N --> D[(project.duckdb)]
 X --> Q[(Parquet partitions)]
 Q --> D
 D --> V[Quality / KPI / validation / comparison]
 V --> H[HTML]
 V --> SS[PNG screenshots]
 V --> E[Excel]
 V --> R[Report pages]
 V --> G[GeoLibre]
 H --> AM[Artifact Manifest]
 SS --> AM
 E --> AM
 R --> AM
 G --> AM
 D --> DM[Dataset Manifest]
 DM --> T[Testudo PostgreSQL registry]
 AM --> T
 T --> UI[Testudo + GeoLibre]
 UI --> FIND[Reviewed finding]
 FIND --> PUB[Approved publication]
 FIND --> KC[Governed candidate]
```

## 4. Stages

| Stage | Purpose | Output | Gate |
|---|---|---|---|
| RM-00 Define | contracts, profile and plan | PipelineDefinition/Plan | plan approval |
| RM-01 Inventory | source/config/environment discovery | source inventory | authority confirmation |
| RM-02 Extract | geometry, SQLite, APA, FZP adapters | batches + SourceReceipts | coverage/adapter tests |
| RM-03 Canonicalize | stable DuckDB/Parquet semantics | canonical dataset | schema/quality/digest |
| RM-04 Analyze | KPI, validation, comparison | semantic views/records | metric/comparability review |
| RM-05 Render | interactive HTML/maps | dashboard | HTML parity/render |
| RM-06 Capture | screenshots | PNG + manifest | render-ready/error checks |
| RM-07 Exchange | Excel/report | XLSX/pages/manifests | KPI parity/cited claims |
| RM-08 GIS package | GeoLibre package | versioned package | query/degraded-mode |
| RM-09 Publish | Testudo registration | transaction receipt | permission/idempotency |
| RM-10 Review | finding/publication | reviewed objects | technical/PM approval |
| RM-11 Learn | learning candidate | governed draft | knowledge review |

## 5. Source adapters

### Model geometry

Required evidence:

- project/model/version and Aimsun environment;
- stable section/node/detector identifiers;
- CRS and WGS84 conversion;
- counts and unresolved geometry;
- source/code digests.

### SQLite results

The adapter identifies database, experiment/replication/run and interval semantics, preserves null/quality, records table-column mapping and supports incremental extraction where safe.

### APA paths

Prefer Aimsun API extraction over undocumented parsing. Record assignment identity, path/OD context, ordered section/turn sequence, cost/distance/time/flow, matching coverage and unresolved sections.

### FZP trajectories

Stream with bounded memory; partition Parquet by run/replication/time window; index in DuckDB; support decimation, retention and privacy policy; remain optional with explicit degraded mode.

## 6. Canonical model

### Minimum vertical slice

- `meta_run`
- `meta_source`
- `network_section`
- `result_section_interval`
- `kpi_record`

### Path/trajectory extension

- `path_catalog`
- `path_section_sequence`
- `path_flow_interval`
- `vehicle_trip`
- `vehicle_trajectory_index`
- views over Parquet

### Calibration/documentation extension

- `calibration_iteration`
- `parameter_change`
- `calibration_verdict`
- `commentary_record`
- candidate-event references

Every table/view declares version, keys, grain, unit, quality, null semantics, lineage and reference queries.

## 7. Artifact contracts

### HTML

Reads canonical queries, exposes run/interval/metric/legend/selection context and generator/data version. Independent calculations require explicit parity coverage.

### Screenshots

Generated from registered view definitions, wait for render-ready, detect empty/error/wrong-version states, and include camera/extent, metric, palette, resolution, timestamp and digest.

### Excel

Minimum sheets:

1. README
2. KPI Summary
3. Validation
4. Time Series
5. Comparison
6. Calibration Iterations
7. Data Quality
8. Screenshots
9. Traceability

Tables declare unit, period, aggregation, metric query and dataset version.

### Report pages

Each statement is classified as observed, computed, inferred or recommended and cites KPI, screenshot, query or evidence. Publication freezes context and digests.

### GeoLibre

Package contains/references `project.duckdb`, WGS84 geometry, documented views, optional trajectory Parquet, compatibility manifest, layer/metric configuration, degraded-mode state and stable IDs.

## 8. Testudo integration

Testudo stores project/context/task, pipeline version, SimulationRun correlation, dataset/artifact references, partial status/residuals, findings/reviews/publications and human identities. It does not store bulk result rows.

The visible agent may prepare and operate the pipeline and explain results. It may not silently change implementation or publish without approval.

## 9. Acceptance dimensions

| Dimension | Evidence | Real environment required? |
|---|---|---:|
| Source/schema implementation | diff/tests/static checks | No |
| Adapter contract | fixtures/probes | Sometimes |
| Canonicalization | DuckDB/Parquet tests | No |
| Artifact parity | generated fixture package | No |
| Headless screenshots | browser evidence | Browser runtime |
| Aimsun live run | logs/model/output paths | Yes |
| GeoLibre interaction | UI session/screenshots | Yes |
| Testudo registration | API transaction receipt | Yes for final proof |
| Technical finding | reviewer decision | Human |
| Publication | frozen version + PM approval | Human/product |

## 10. Recovery

- Persist inventory/baseline before extraction or build.
- Stage, validate and atomically publish canonical packages.
- Retain authorized partial partitions with explicit status.
- Regenerate derived artifacts from canonical data.
- Deactivate faulty versions rather than mutate.
- Reconcile Testudo state from receipts.

## 11. Completion status

Report separately:

- implementation accepted;
- canonical dataset accepted;
- artifact parity accepted;
- Aimsun live pilot accepted/pending;
- GeoLibre UI accepted/pending;
- Testudo registration accepted/pending;
- finding accepted/pending;
- publication approved/pending.
