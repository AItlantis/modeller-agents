# 10 — Executive Audit v3

## Executive summary

The correct target is now clear:

- **Testudo** is the project-centred product and the only user-facing AI experience.
- **`modeller-agents`** is the embedded executable orchestration subsystem.
- **DMW-Orchestration** supplies governance concepts and generated compatibility assets, not a competing runtime.
- **Aimsun and other services** remain technical authorities behind adapters.
- **PostgreSQL** owns users, projects, permissions, tasks, conversations, findings and publications.
- **DuckDB** owns high-volume simulation analytical datasets.
- **Immutable files/object artifacts** preserve checkpoint and evidence recovery.
- PostgreSQL can later host the product event store without replacing the v1 mission ledger prematurely.

All v1 open-decision recommendations are approved. Legal review permits approved external patterns/features to be integrated as isolated `modeller-agents` subsystems.

## What the Testudo documents add

The product documents introduce requirements that were not fully represented in audit v1:

1. The project is the persistent authority and navigation unit.
2. The user sees one contextual AI agent, not a collection of role agents.
3. Active model/version/period/scenario/SimulationRun context must be inspectable and correct.
4. AI and services inherit the triggering user's project permissions.
5. Long tasks, partial results, cancellation and recovery must be product-visible.
6. Computed results, AI interpretations, hypotheses, recommendations and human decisions must remain distinct.
7. Technical findings require human review.
8. Client publication requires separate Project Manager approval.
9. Evidence lineage must cross product records, simulation datasets and immutable artifacts.

## Current-state conclusion

DMW and `modeller-agents` contain the right governance and runtime ingredients, but not yet the correct product boundary. Directly placing either plugin in Testudo would expose provider and role mechanics, duplicate state and weaken project authority.

The missing capability is a versioned **Testudo Orchestration Gateway** that:

- validates the active-context and permission envelope;
- maintains one visible conversation;
- creates a mission and linked persistent task;
- translates product responsibilities into exact approval gates;
- publishes typed progress/partial-result/recovery events;
- registers DuckDB result manifests and artifact references;
- hands accepted technical evidence into finding and publication workflows.

## Target architecture

```text
Testudo web app and API
  PostgreSQL product authority
  one visible agent
  active context and project permissions
  task/finding/publication lifecycle
          ↓
Testudo Orchestration Gateway
          ↓
modeller-agents
  DMW role policies
  provider-neutral execution
  gates and independent review
  mission ledger/checkpoints
          ↓
Backends and data services
  Aimsun / pipelines / GIS / docs / external agents
  DuckDB/Parquet result datasets
  immutable evidence artifacts
```

## Priority changes

| Priority | Change |
|---|---|
| P0 | Align contract 1.2/N-1 and make `modeller-agents` the only mission state authority |
| P0 | Implement signed/versioned active-context envelope |
| P0 | Build Testudo Gateway and Mission↔Task binding |
| P0 | Map project responsibilities to simulation, finding, publication and asset-use gates |
| P0 | Implement PostgreSQL/DuckDB/artifact ownership boundaries |
| P0 | Publish idempotent task, result, intervention and recovery events |
| P0 | Separate technical mission acceptance from finding and publication approval |
| P0 | Execute project→simulation→finding→publication vertical slice |
| P1 | Package approved external features as disableable subsystems |
| P1 | Preserve PostgreSQL event-store compatibility without making it a v1 prerequisite |

## Immediate implementation sequence

1. Ratify vocabulary and cross-system IDs.
2. Implement the Testudo `ActiveContextEnvelope`.
3. Implement the Orchestration Gateway and authorization policy.
4. Implement PostgreSQL task/mission/result references.
5. Implement DuckDB `ResultDatasetManifest`.
6. Implement artifact catalog and checkpoint references.
7. Implement product event projection and replay.
8. Implement one-agent interaction and output classification.
9. Implement finding and publication handoffs.
10. Run the Testudo vertical slice in local and separated deployment modes.

## Major risks

- Wrong or stale product context reaches a valid technical mission.
- Internal agent roles leak into the user experience.
- PostgreSQL and DuckDB ownership is blurred.
- Task events diverge from the mission ledger.
- Providers exceed user/project permission.
- Technical completion is mistaken for business approval.
- DuckDB concurrency or storage assumptions fail at representative scale.
- Approved external features create hidden coupling.

Each is addressed by a specific ADR, plan item, requirement and test in the package.

## Acceptance definition

The v2 architecture is accepted only when a representative Transport Modeller can:

1. open a Testudo project and verify context;
2. use one visible agent to prepare a simulation;
3. explicitly approve the launch;
4. observe and recover the persistent task;
5. access a registered DuckDB result dataset;
6. create an evidence-linked finding;
7. obtain Technical Reviewer action;
8. prepare a frozen publication;
9. obtain Project Manager approval;
10. trace the publication back through SimulationRun, data, artifacts, mission and approvals.

No internal role chat, backend-specific manual context rebuild or ungoverned database access may be required.

## Final recommendation

Proceed with the runtime hardening and Testudo embedding as one coordinated programme, but deliver it in layers. Do not build a broad autonomous-agent platform first. Build the context, authorization, task, data and evidence seams, prove one vertical slice, then activate richer memory, knowledge and external subsystems.

The intended result is not “agents inside the UI.” It is a controlled product workflow in which agent capabilities remain internally specialized, externally coherent, project-authorized and evidence-backed.

## Rendering-modelling extension

The next architecture increment is a reusable pipeline control plane allowing governed agents to **plan**, **implement** and **use** technical pipelines without conflating authority.

`rendering-modelling` is the correct reference because it crosses licensed extraction, analytical data, large trajectories, reusable framework code, several presentation surfaces, GeoLibre/Testudo integration, findings, publication and knowledge candidates.

### Required changes

1. Add pipeline definitions, versions, plans, run receipts and data/artifact manifests.
2. Make `plan`, `build` and `operate` explicit.
3. Keep implementation in backend repositories.
4. Enforce DuckDB/Parquet canonical analytics.
5. Generate and parity-test every presentation surface.
6. Register metadata/references in PostgreSQL, not bulk rows.
7. Use GeoLibre as the first interactive adapter.
8. Separate implementation/contract/integration/live proof.

### Sequence

```text
contracts and modes
→ read-only planning pilot
→ exact capability additions
→ Builder baseline/scope/re-gate
→ canonical data and parity
→ immutable version
→ Operator/Testudo path
→ transactional registration
→ GeoLibre UI pilot
→ finding/publication slice
```

Approve ADR-023–ADR-034 and execute PLAN-046–PLAN-075. Normalize the supplied free-text epic/dependency content into typed platform objects while preserving the evidence snapshot unchanged.
