# DMW-Orchestration → modeller-agents → Testudo → rendering-modelling Audit-to-Build Package v3

**Package date:** 2026-08-05  
**Version:** 3.0  
**Status:** detailed architecture and implementation baseline  
**Target orchestration repository:** `modeller-agents`  
**Reference pipeline/backend repository:** `aimsun-psp`  
**Product host:** Testudo  
**Visualization starting point:** GeoLibre package/plugin  
**Governance source:** DMW-Orchestration

## Executive position

Audit v3 establishes four distinct authority layers:

```text
Testudo
  project, user, permission, task, finding, publication and visible-agent authority
        ↓ signed context / approval / task / lineage contracts
modeller-agents
  pipeline control plane: plan, implement and operate registered pipelines;
  role policies, provider dispatch, gates, checkpoints, evidence and recovery
        ↓ versioned pipeline definition / run / dataset / artifact contracts
Pipeline repositories and technical services
  Aimsun extraction, SQLite/APA/FZP adapters, DuckDB/Parquet normalization,
  KPI computation, HTML/screenshot/Excel/report generation and GeoLibre packaging
        ↓ registered datasets and artifact references
PostgreSQL + DuckDB/Parquet + file/object storage
  product metadata + analytical data + immutable evidence
```

`rendering-modelling` is the first complete pipeline-family reference implementation. It is not embedded as special-case logic in `modeller-agents`; it proves a generic lifecycle reusable by simulation, demand, calibration, validation and publication pipelines.

The agent subsystem must support three modes with different authorities:

1. **Plan a pipeline** — analyse needs, sources, contracts, stages, risks, tests, approvals and rollout without modifying production code.
2. **Implement a pipeline** — perform bounded repository changes against an approved plan, rerun deterministic gates, preserve rollback and return implementation receipts.
3. **Use a pipeline** — select a registered version, prepare a run, obtain approval, execute it, validate outputs, register datasets/artifacts and expose progress to Testudo without modifying pipeline code.

## Confirmed decisions

All v2 decisions remain approved. Audit v3 additionally records:

- `rendering-modelling` is a first-class reusable pipeline family and reference vertical slice.
- `modeller-agents` owns the pipeline control plane, but MUST NOT own backend extraction or rendering implementation.
- DuckDB is the canonical analytical package for structured simulation results; Parquet holds large trajectories and partitions.
- PostgreSQL stores project, user, task, run registry, permission, finding, publication and artifact-reference records—not bulk simulation results.
- HTML, screenshots, Excel, report pages and GeoLibre packages are derived from the same validated canonical dataset.
- GeoLibre is the first Testudo visualization adapter and UI starting point, not a second analytical authority.
- Live Aimsun/aconsole proof is separate from source implementation and contract testing.
- The capability catalog requires explicit additions for DuckDB/Parquet, screenshot automation, Excel/report generation and Testudo publication-client work.

## Governing source hierarchy

1. Confirmed user decisions and goals recorded in this package.
2. Testudo Business Need and Design Brief.
3. Testudo Product Requirements Document.
4. `rendering-modelling` implementation plan v3 and its explicit decisions/residuals.
5. Live-fire mission evidence and reproducible repository reconnaissance.
6. Accepted repository decisions and boundary documents.
7. Current implementation and test evidence.
8. External benchmark patterns.

A mechanically verified implementation may supersede a plan claim. A semantic review may not supersede a failed mechanical check.

## Target principles

| Principle | Consequence |
|---|---|
| Pipeline is a first-class governed object | Definition, implementation, version, run, dataset and artifact identities are explicit. |
| Plan/build/operate are different capabilities | Their write scopes, approvals and completion criteria differ. |
| Canonical data precedes presentation | HTML, screenshots, Excel, reports and GeoLibre consume validated DuckDB/Parquet contracts. |
| Source truth remains external | Aimsun models, SQLite outputs, APA assignments and FZP trajectories retain provenance. |
| Product and analytics remain separated | PostgreSQL stores authority/registry; DuckDB/Parquet stores analytics. |
| Derived outputs must agree | Cross-surface KPI parity is a blocking contract test. |
| One visible Testudo agent | Internal Planner/Manager/Recon/Worker/Reviewer complexity remains hidden. |
| Use mode cannot modify pipeline code | Operational agents execute only registered approved versions. |
| Recovery is checkpoint-first | Plans, baselines, receipts, datasets and artifacts persist before risky transitions. |
| Live proof is honest | Unavailable licensed execution becomes a residual with an exact operator command. |

## Deliverable map

| File | Purpose |
|---|---|
| `01-current-approach.md` | Existing runtime/product findings plus rendering and data-management gaps. |
| `02-benchmark.md` | Internal/external patterns and pipeline-level conclusions. |
| `03-build-brief.md` | Consolidated product, orchestration and pipeline brief. |
| `04-build-architecture.md` | Testudo + agent + pipeline + data architecture and ADRs. |
| `05-build-plan.md` | Runtime, Testudo and pipeline-control-plane implementation plan. |
| `06-build-specification.md` | Testable requirements for plan/build/operate and data/artifact contracts. |
| `07-build-vigilance.md` | Human controls, data risks, stop conditions and rollback. |
| `08-skill.md` | Reusable audit skill with pipeline lifecycle extension. |
| `09-open-decisions-and-risk.md` | Approved decisions, implementation choices and risks. |
| `10-executive-audit.md` | Executive synthesis and implementation order. |
| `11-testudo-agent-embedding.md` | Visible-agent, context, task and persistence integration. |
| `12-rendering-modelling-pipeline.md` | Detailed extraction, canonicalization and presentation architecture. |
| `13-pipeline-agent-capabilities.md` | Planner, Builder and Operator behavior and contracts. |
| `14-data-contracts-and-artifacts.md` | Storage, manifests, lineage, parity and retention. |
| `15-rendering-modelling-implementation-map.md` | Mapping from the attached 31-item plan to the reusable architecture. |
| `contracts/` | Draft machine-readable pipeline contracts. |
| `evidence/rendering-modelling-implementation-plan.v3.json` | Supplied plan snapshot used as evidence. |
| `pipeline-capability-matrix.csv` | Work-item and capability mapping. |
| `data-lineage-matrix.csv` | Source→canonical→artifact→Testudo lineage. |
| `traceability-matrix.csv` | End-to-end traceability. |
| `PACKAGE_VALIDATION.md` | Structural and identifier validation. |

## Recommendation register

| ID | Recommendation | Classification | Priority |
|---|---|---|---|
| REC-001–REC-020 | Retain approved v1/v2 runtime and Testudo recommendations | Approved baseline | P0/P1 |
| REC-021 | Introduce a generic pipeline control plane in `modeller-agents` | Build New | P0 |
| REC-022 | Define separate pipeline plan, implementation and operation modes | Refactor | P0 |
| REC-023 | Register versioned pipeline definitions and capability profiles | Build New | P0 |
| REC-024 | Make DuckDB/Parquet the canonical simulation analytical seam | Integrate | P0 |
| REC-025 | Generate presentation artifacts from validated canonical data | Refactor | P0 |
| REC-026 | Enforce KPI and lineage parity across all declared surfaces | Extend | P0 |
| REC-027 | Treat GeoLibre as the first Testudo visualization adapter | Integrate | P1 |
| REC-028 | Add explicit source adapters for SQLite, geometry, APA and FZP | Extend | P0 |
| REC-029 | Add pipeline-specific capabilities to the catalog | Configure/Build | P1 |
| REC-030 | Prevent pipeline-use agents from changing implementation | Configure | P0 |
| REC-031 | Separate source/contract tests from licensed live-model proof | Refactor | P0 |
| REC-032 | Use `rendering-modelling` as the pipeline-control-plane acceptance pilot | Build New | P0 |

## Package status and limitations

This package is a build baseline, not a claim that the 31 supplied work items are delivered. The plan contains explicit residuals: Testudo registration is deferred by write-scope decision, GeoLibre UI code is outside that mission's repository scope, and live Aimsun/aconsole execution is unavailable in the referenced sandbox.

## Usage

Start with `10-executive-audit.md`. Use `12-rendering-modelling-pipeline.md` for the end-to-end vision, `13-pipeline-agent-capabilities.md` for agent behavior, `14-data-contracts-and-artifacts.md` for data ownership, and `15-rendering-modelling-implementation-map.md` to connect the attached plan to the reusable architecture.
